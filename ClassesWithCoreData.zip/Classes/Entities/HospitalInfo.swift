//  HospitalInfo.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON
//enum HospitalInfoKey:String {
//    case Abbreviation               = "abbreviation"
//    case AddressLine1               = "addressLine1"
//    case AddressLine2               = "addressLine2"
//    case AvailableCapacity          = "availableCapacity"
//    case City                       = "city"
//    case Country                    = "country"
//    case CountryCode                = "countryCode"
//    case HospitalID                 = "hospitalID"
//    case HospitalName               = "hospitalName"
//    case HospitalType               = "hospitalType"
//    case Lattitude                  = "lattitude"
//    case Longitude                  = "longitude"
//    case PhoneNumber                = "phoneNumber"
//    case ReasonForDelay             = "reasonForDelay"
//    case State                      = "state"
//}
class HospitalInfo: NSManagedObject {
// Insert code here to add functionality to your managed object subclass
}
