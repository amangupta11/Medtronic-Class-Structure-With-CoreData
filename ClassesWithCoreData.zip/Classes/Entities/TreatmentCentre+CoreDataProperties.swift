//  TreatmentCentre+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
extension TreatmentCentre {
    @NSManaged var abbreviation: String?
    @NSManaged var addressLine1: String?
    @NSManaged var addressLine2: String?
    @NSManaged var availableCapacity: NSNumber?
    @NSManaged var city: String?
    @NSManaged var country: String?
    @NSManaged var countryCode: String?
    @NSManaged var hospitalID: String?
    @NSManaged var hospitalName: String?
    @NSManaged var hospitalType: String?
    @NSManaged var lattitude: String?
    @NSManaged var longitude: String?
    @NSManaged var phoneNumber: String?
    @NSManaged var reasonForDelay: String?
    @NSManaged var state: String?
    @NSManaged var zipCode: String?
    @NSManaged var consultant: String?
    @NSManaged var patientInfo: PatientInfo?

}
