//  PatientInfo.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON
enum PatientInfoKey: String {
    case Age               =    "age"
    case CaseID            =   "caseID"
    case TempCaseID        = "tempCaseID"
    case CaseStatus        =    "caseStatus"
    case CountryCode       =    "countryCode"
    case FirstName         =    "firstName"
    case MiddleName        =    "middleName"
    case Gender            =    "gender"
    case LastName          =    "lastName"
    case MobileNumber      =    "mobileNumber"
    case ICOrPassport      =    "icNoOrPassport"
    case PaymentType       =    "paymentType"
    case SyncStatus        =    "syncStatus"
    case PatientID         =    "patientID"
    case CitizenshipType   =    "citizenship"
    case Value  = "value"
    case CitizenshipKey    = "key"
    case ID = "id"
    case HospitalCaseID    = "hospitalCaseID"
    case CathLabReady    = "isCathLabReadyToAcceptCase"
    case RsaPublicKey    = "rsaPublicKey"
    //case PaymentTypeValue  = "value"
    case CaseKey           = "caseKey"
    case PatientInfo       = "PatientInfo"
}
class PatientInfo: NSManagedObject {
    // Insert code here to add functionality to your managed object subclass
    var json: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.Age.rawValue] = self.age
            dictionary[PatientInfoKey.CaseID.rawValue] = self.caseID
            dictionary[PatientInfoKey.TempCaseID.rawValue] = self.tempCaseID
            dictionary[PatientInfoKey.CaseStatus.rawValue] = self.caseStatus
            if(self.mobileNumber != "") {
            dictionary[PatientInfoKey.CountryCode.rawValue] = self.countryCode
            dictionary[PatientInfoKey.MobileNumber.rawValue] = self.mobileNumber
            }
            dictionary[PatientInfoKey.FirstName.rawValue] = self.firstName
            dictionary[PatientInfoKey.Gender.rawValue] = self.gender
            dictionary[PatientInfoKey.LastName.rawValue] = self.lastName
            dictionary[PatientInfoKey.MiddleName.rawValue] = self.middleName
            dictionary[PatientInfoKey.ICOrPassport.rawValue] = self.icOrPassport
            if (self.citizenshipType != nil) {
                var citizenship: [String:AnyObject] = [:]
                citizenship[PatientInfoKey.Value.rawValue] = self.citizenshipType
                citizenship[PatientInfoKey.ID.rawValue] = self.citizenshipTypeID
                dictionary[PatientInfoKey.CitizenshipType.rawValue] = citizenship
            }
            if (self.paymentType != nil) {
                var paymentType: [String:AnyObject] = [:]
                paymentType[PatientInfoKey.Value.rawValue] = self.paymentType
                paymentType[PatientInfoKey.ID.rawValue] = self.paymentTypeID
                dictionary[PatientInfoKey.PaymentType.rawValue] = paymentType
            }
            var timeLine: [String:AnyObject] = [:]
            timeLine[TimeLineKey.Comment.rawValue] = nil
            timeLine[TimeLineKey.Location.rawValue] = nil

            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.onsetTime?.stringValue
            if self.timeLine?.onsetTime != 0 {
            dictionary[TimeLineKey.OnsetTime.rawValue] = timeLine
            }

            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.triageTime?.stringValue
            if self.timeLine?.triageTime != 0 {
            dictionary[TimeLineKey.TriageTime.rawValue] = timeLine
            }


            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.addNewCaseTime?.stringValue
            if self.timeLine?.addNewCaseTime != nil {
            dictionary[TimeLineKey.AddNewCaseTime.rawValue] = timeLine
            }

            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.fmcDoorInTime?.stringValue
            dictionary[TimeLineKey.FmcDoorInTime.rawValue] = timeLine


            let json = JSON(dictionary)
            return json
        }
    }
    class func getPatientForCaseID(caseID: String) -> PatientInfo? {
        let predicate: NSPredicate = NSPredicate(format: "caseID == %@", argumentArray: [caseID])
        let patient: PatientInfo? = DataOperation.sharedDataOperation.fetchObjectForEntity(PatientInfoKey.PatientInfo.rawValue, predicate: predicate) as? PatientInfo
        return patient
    }
    class func getPatientForTempCaseID(tempCaseID: String) -> PatientInfo? {
        let predicate: NSPredicate = NSPredicate(format: "tempCaseID == %@", argumentArray: [tempCaseID])
        let patient: PatientInfo? = DataOperation.sharedDataOperation.fetchObjectForEntity(PatientInfoKey.PatientInfo.rawValue, predicate: predicate) as? PatientInfo
        return patient
    }

    // MARK: - Insert / Update the PatientInfo
    class func insertPatientInfo(json: JSON) -> PatientInfo? {
        let caseID = json[PatientInfoKey.CaseID.rawValue].stringValue
        var patientInfo: PatientInfo? = PatientInfo.getPatientForCaseID(caseID)
        if patientInfo == nil {
            patientInfo = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientInfoKey.PatientInfo.rawValue) as? PatientInfo
            patientInfo?.tempCaseID = StringUtility.uniqueId()
        }
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patientInfo
        /*
         if let patient = patientInfo {
         let u = updatePatient(patient, json:json)
         do {
         if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
         try DataOperation.sharedDataOperation.mainThreadContext.save()
         }
         }
         catch {
         let saveError = error as NSError
         print("\(saveError), \(saveError.userInfo)")
         }
         return u
         } else {
         return nil
         }
         */
    }
    
    // MARK: - Insert / Update the PatientInfo
    class func insertNewPatientInfo(json: JSON, completion:(successful: Bool, patientInfo: PatientInfo) -> Void) {
        let caseID = json[PatientInfoKey.CaseID.rawValue].stringValue
        var patientInfo: PatientInfo? = PatientInfo.getPatientForCaseID(caseID)
        var ecg: ECGInfo? = patientInfo?.ecgInfo
        var treatment: TreatmentCentre? = patientInfo?.treatmentInfo
        var fmc: FMCCentre? = patientInfo?.fmcInfo
        var  timeline: TimeLine? = patientInfo?.timeLine
        var patientHistory: PatientHistory? = patientInfo?.patientHistory
        
        if patientInfo == nil {
            patientInfo = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientInfoKey.PatientInfo.rawValue) as? PatientInfo
            timeline = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TimeLineKey.TimeLine.rawValue) as? TimeLine
            fmc = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(FMCCentreInfoKey.FmcCentreTable.rawValue) as? FMCCentre
            ecg = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(ECGInfoKey.ECGInfo.rawValue) as? ECGInfo
            treatment = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TreatmentCentreInfoKey.TreatmentCentreTable.rawValue) as? TreatmentCentre
            
            patientHistory = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientHistoryInfoKey.PatientHistoryTable.rawValue) as? PatientHistory
            
            patientInfo!.timeLine = timeline
            patientInfo!.ecgInfo = ecg
            patientInfo!.fmcInfo = fmc
            patientInfo!.treatmentInfo = treatment
            patientInfo!.patientHistory = patientHistory
            
            
        }
        if let patient = patientInfo {
            onlyUppdatePatient(patient, json:json)
            timeline = TimeLine.updateTimeLine(timeline!, patient:patientInfo!, json:json)
            fmc = FMCCentre.updateFMCHospitalInfo(fmc!, patient:patientInfo!, json:json)
            ecg = ECGInfo.updateECGInfo(ecg!, patient: patientInfo!, json: json)
            treatment = TreatmentCentre.updateTreatmentHospitalInfo(treatment!, patient:patientInfo!, json: json)
            patientHistory = PatientHistory.updatePatientHistory(patientHistory!, patient:patientInfo!, json: json)
            
            patient.timeLine = timeline
            patient.ecgInfo = ecg
            patient.fmcInfo = fmc
            patient.treatmentInfo = treatment
            patient.patientHistory = patientHistory
            
            DataOperation.sharedDataOperation.mainThreadContext.performBlockAndWait { () -> Void in
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    do {
                        try DataOperation.sharedDataOperation.mainThreadContext.save()
                        completion(successful: true, patientInfo: patientInfo!)
                    } catch {
                        let saveError = error as NSError
                        print("\(saveError), \(saveError.userInfo)")
                        completion(successful: false, patientInfo: patientInfo!)
                    }
                }
            }
        }
    }
    

//    // MARK: - Insert / Update the PatientInfo
//    class func insertNewPatientInfo(json: JSON) {
//        let caseID = json[PatientInfoKey.CaseID.rawValue].stringValue
//        var patientInfo: PatientInfo? = PatientInfo.getPatientForCaseID(caseID)
//        var ecg: ECGInfo? = patientInfo?.ecgInfo
//        var treatment: TreatmentCentre? = patientInfo?.treatmentInfo
//        var fmc: FMCCentre? = patientInfo?.fmcInfo
//        var  timeline: TimeLine? = patientInfo?.timeLine
//        var patientHistory: PatientHistory? = patientInfo?.patientHistory
//        
//        if patientInfo == nil {
//            patientInfo = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientInfoKey.PatientInfo.rawValue) as? PatientInfo
//            timeline = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TimeLineKey.TimeLine.rawValue) as? TimeLine
//            fmc = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(FMCCentreInfoKey.FmcCentreTable.rawValue) as? FMCCentre
//            ecg = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(ECGInfoKey.ECGInfo.rawValue) as? ECGInfo
//            treatment = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TreatmentCentreInfoKey.TreatmentCentreTable.rawValue) as? TreatmentCentre
//            
//            patientHistory = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientHistoryInfoKey.PatientHistoryTable.rawValue) as? PatientHistory
//            
//            patientInfo!.timeLine = timeline
//            patientInfo!.ecgInfo = ecg
//            patientInfo!.fmcInfo = fmc
//            patientInfo!.treatmentInfo = treatment
//            patientInfo!.patientHistory = patientHistory
//            
//            
//        }
//        if let patient = patientInfo {
//            onlyUppdatePatient(patient, json:json)
//            timeline = TimeLine.updateTimeLine(timeline!, patient:patientInfo!, json:json)
//            fmc = FMCCentre.updateFMCHospitalInfo(fmc!, patient:patientInfo!, json:json)
//            ecg = ECGInfo.updateECGInfo(ecg!, patient: patientInfo!, json: json)
//            treatment = TreatmentCentre.updateTreatmentHospitalInfo(treatment!, patient:patientInfo!, json: json)
//            patientHistory = PatientHistory.updatePatientHistory(patientHistory!, patient:patientInfo!, json: json)
//            
//            patient.timeLine = timeline
//            patient.ecgInfo = ecg
//            patient.fmcInfo = fmc
//            patient.treatmentInfo = treatment
//            patient.patientHistory = patientHistory
//        }
//    }
   
    class func updateStemiTime(patient: PatientInfo) -> PatientInfo? {
        patient.timeLine?.stemiTime  =  DateUtility.getCurrentTimeInGMT()
        patient.timeLine?.notAStemiTime  =  nil
        patient.timeLine?.diagnoseECGTime  =  nil
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }
    class func updateNotAStemiTime(patient: PatientInfo) -> PatientInfo? {
        patient.timeLine?.notAStemiTime  =  DateUtility.getCurrentTimeInGMT()
        patient.timeLine?.stemiTime  =  nil
        patient.timeLine?.diagnoseECGTime  =  nil

        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }
    class func updateDiagnoseECGTime(patient: PatientInfo) -> PatientInfo? {
        patient.timeLine?.diagnoseECGTime  =  DateUtility.getCurrentTimeInGMT()
        patient.timeLine?.notAStemiTime  =  nil
        patient.timeLine?.stemiTime  =  nil
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }
    class func updateECGCaptureTime(patient: PatientInfo) -> PatientInfo? {
        patient.timeLine?.firstECGTime  =  DateUtility.getCurrentTimeInGMT()
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }
    class func updateAllInfo(patient: PatientInfo) -> PatientInfo {
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }
    class func onlyUppdatePatient(patient: PatientInfo, json: JSON) -> PatientInfo {
        onlyUpdatePatientInfo(patient, json: json )
        updatePatientPaymentTypeInfo(patient, json: json)
        if(json[PatientInfoKey.CathLabReady.rawValue].stringValue != ""){
            patient.isCathLabReady  = json[PatientInfoKey.CathLabReady.rawValue].bool!
        }
        if (json[PatientInfoKey.HospitalCaseID.rawValue].stringValue != "") {
            patient.hospitalCaseID  = json[PatientInfoKey.HospitalCaseID.rawValue].stringValue}

        if (json [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }
        if (json [TimeLineKey.AddNewCaseTime.rawValue].dictionary  != nil) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }
        if (json[TimeLineKey.CaseTimeLines.rawValue].dictionary != nil) {
            updateTimelineField(patient, json: json)
        }
        if(patient.fmcInfo != nil) {
            if (json[FMCCentreInfoKey.FmcCentre.rawValue].dictionary != nil) {
                var  fmcHospitalInfo: FMCCentre? = nil
                fmcHospitalInfo = FMCCentre.updateFMCHospitalInfo(patient.fmcInfo!, patient: patient, json: json)
                patient.fmcInfo?=fmcHospitalInfo!
            }}
        if(patient.treatmentInfo != nil) {
            if (json[TreatmentCentreInfoKey.TreatmentCentre.rawValue].stringValue != "") {
                var  treatmentInfo: TreatmentCentre? = nil
                treatmentInfo = TreatmentCentre.updateTreatmentHospitalInfo(patient.treatmentInfo!, patient: patient, json: json)
                patient.treatmentInfo?=treatmentInfo!
            }
            if(patient.patientHistory != nil) {
                if (json[PatientHistoryInfoKey.PatientHistoryTable.rawValue] != nil) {
                    var  patientHistory: PatientHistory? = nil
                    patientHistory = PatientHistory.updatePatientHistory(patient.patientHistory!, patient: patient, json: json)
                    patient.patientHistory?=patientHistory!
                }
            }
        }
        return patient
    }
    class func onlyUpdatePatientInfo(patient: PatientInfo, json: JSON) {

        if (json[PatientInfoKey.CaseID.rawValue].stringValue != "") {
            patient.caseID  = json[PatientInfoKey.CaseID.rawValue].stringValue}
        if (json[PatientInfoKey.CaseStatus.rawValue].stringValue != "") {
            patient.caseStatus  = json[PatientInfoKey.CaseStatus.rawValue].stringValue}

            updateGeneralInfo(patient, json: json)

    }
    class func updateTimelineField(patient: PatientInfo, json: JSON) {
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil
        || (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) || (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.AddNewCaseTime.rawValue].dictionary  != nil) ||
            (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.SpokeTransferTime.rawValue].dictionary  != nil)) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }

        /*
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.AddNewCaseTime.rawValue].dictionary  != nil) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }*/

    }
    class func updatePatient(patient: PatientInfo, json: JSON) -> PatientInfo {
        updatePatientInfo(patient, json: json)
        if (json[PatientInfoKey.HospitalCaseID.rawValue].stringValue != "") {
            patient.hospitalCaseID  = json[PatientInfoKey.HospitalCaseID.rawValue].stringValue}
        if(json[PatientInfoKey.CathLabReady.rawValue].stringValue != ""){
            patient.isCathLabReady  = json[PatientInfoKey.CathLabReady.rawValue].bool!
        }
        if (json[TimeLineKey.CaseTimeLines.rawValue].dictionary != nil ) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLineWithCaseTimeline(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }
        else{
            var  timeline: TimeLine? = nil
            timeline = TimeLine.updateTimeLine(patient.timeLine!, patient: patient, json: json)
            patient.timeLine?=timeline!
        }
        if(patient.fmcInfo != nil) {
            if (json[FMCCentreInfoKey.FmcCentre.rawValue].dictionary != nil) {
                var  fmcHospitalInfo: FMCCentre? = nil
                fmcHospitalInfo = FMCCentre.updateFMCHospitalInfo(patient.fmcInfo!, patient: patient, json: json)
                patient.fmcInfo?=fmcHospitalInfo!
            }}
        if(patient.treatmentInfo != nil) {
            if (json[TreatmentCentreInfoKey.TreatmentCentre.rawValue] != nil) {
                var  treatmentInfo: TreatmentCentre? = nil
                treatmentInfo = TreatmentCentre.updateTreatmentHospitalInfo(patient.treatmentInfo!, patient: patient, json: json)
                patient.treatmentInfo?=treatmentInfo!
            }
        }
        if(patient.patientHistory != nil) {
            if (json[PatientHistoryInfoKey.InfarctArea.rawValue] != nil || json[PatientHistoryInfoKey.VitalSigns.rawValue] != nil  ) {
                var  patientHistory: PatientHistory? = nil
                patientHistory = PatientHistory.updatePatientHistory(patient.patientHistory!, patient: patient, json: json)
                patient.patientHistory?=patientHistory!
                var ecgInfo: ECGInfo? = nil
                ecgInfo = ECGInfo.updateECGInfoFromjSon(patient, json:json)
                patient.ecgInfo?=ecgInfo!
            }
        }
        do {
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return patient
    }

    class func updatePatientInfo(patient: PatientInfo, json: JSON) {
        updateGeneralInfo(patient, json: json)
        if (json[PatientInfoKey.CaseID.rawValue].stringValue != "") {
            patient.caseID  = json[PatientInfoKey.CaseID.rawValue].stringValue}
        if (json[PatientInfoKey.CaseStatus.rawValue].stringValue != "") {
            patient.caseStatus  = json[PatientInfoKey.CaseStatus.rawValue].stringValue}

        updatePatientPaymentTypeInfo(patient, json: json)
    }
    class func updatePatientPaymentTypeInfo(patient: PatientInfo, json: JSON) {
        updateCitizenshipTypeInfo(patient, json: json)
        updatePatientPaymentTypeIDInfo(patient, json: json)
    }
    class func updateCitizenshipTypeInfo(patient: PatientInfo, json: JSON) {
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != ""){
        let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
        if (caseKey != "") {
            if (json[PatientInfoKey.CitizenshipType.rawValue].dictionary !=  nil) {
                patient.citizenshipType  = AESWrapper.decryptTheText(json[PatientInfoKey.CitizenshipType.rawValue][PatientInfoKey.Value.rawValue].stringValue, key: caseKey)
                patient.citizenshipTypeID  = AESWrapper.decryptTheText(json[PatientInfoKey.CitizenshipType.rawValue][PatientInfoKey.ID.rawValue].stringValue, key: caseKey)
            }
            }
        } else {
            if (json[PatientInfoKey.CitizenshipType.rawValue].dictionary !=  nil) {
                patient.citizenshipType  = json[PatientInfoKey.CitizenshipType.rawValue][PatientInfoKey.Value.rawValue].stringValue
                patient.citizenshipTypeID = json[PatientInfoKey.CitizenshipType.rawValue][PatientInfoKey.ID.rawValue].stringValue
            }
        }
    }

    class func updateGeneralInfo(patient: PatientInfo, json: JSON) {
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != "") {
        let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
        if (caseKey != "") {

            if (json[TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.UnclearECGTime.rawValue].dictionary  != nil) {
                var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.UnclearECGTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
                var  timeDict =  array![0].dictionary
                let comment = timeDict![TimeLineKey.Comment.rawValue]?.stringValue
                patient.patientHistory!.uncleatECGComments = comment
            }
            //            if (json [TimeLineKey.UnclearECGComments.rawValue] != nil) {
            //                patient.patientHistory!.uncleatECGComments = json [TimeLineKey.UnclearECGComments.rawValue].stringValue
            //            }

            
            patient.caseKey = caseKey
            patient.timeLine?.isStemi = false

                let isStemi = json[TimeLineKey.DiagnosedAsStemi.rawValue].boolValue
                patient.timeLine?.isStemi = isStemi


            if (json[PatientInfoKey.Age.rawValue].stringValue != "") {
                patient.age  = AESWrapper.decryptTheText(json[PatientInfoKey.Age.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.FirstName.rawValue].stringValue != "") {
                patient.firstName  = AESWrapper.decryptTheText(json[PatientInfoKey.FirstName.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.CountryCode.rawValue].stringValue != "") {
                patient.countryCode  = AESWrapper.decryptTheText(json[PatientInfoKey.CountryCode.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.Gender.rawValue].stringValue != "") {
                patient.gender  = AESWrapper.decryptTheText(json[PatientInfoKey.Gender.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.LastName.rawValue].stringValue != "") {
                patient.lastName  = AESWrapper.decryptTheText(json[PatientInfoKey.LastName.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.MobileNumber.rawValue].stringValue != "") {
                patient.mobileNumber  = AESWrapper.decryptTheText(json[PatientInfoKey.MobileNumber.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.MiddleName.rawValue].stringValue != "") {
                patient.middleName  = AESWrapper.decryptTheText(json[PatientInfoKey.MiddleName.rawValue].stringValue, key: caseKey)
            }
            if (json[PatientInfoKey.ICOrPassport.rawValue].stringValue != "") {
                patient.icOrPassport  = AESWrapper.decryptTheText(json[PatientInfoKey.ICOrPassport.rawValue].stringValue, key: caseKey)
            }
            }
        } else {
            if (json[PatientInfoKey.Age.rawValue].stringValue != "") {
                patient.age = json[PatientInfoKey.Age.rawValue].stringValue
            }
            if (json[PatientInfoKey.FirstName.rawValue].stringValue != "") {

                patient.firstName = json[PatientInfoKey.FirstName.rawValue].stringValue
            }
            if (json[PatientInfoKey.LastName.rawValue].stringValue != "") {

                patient.lastName = json[PatientInfoKey.LastName.rawValue].stringValue
            }
            if (json[PatientInfoKey.CountryCode.rawValue].stringValue != "") {

                patient.countryCode  = json[PatientInfoKey.CountryCode.rawValue].stringValue
            }
            if (json[PatientInfoKey.MiddleName.rawValue].stringValue != "") {

                patient.middleName  = json[PatientInfoKey.MiddleName.rawValue].stringValue
            }
            if (json[PatientInfoKey.ICOrPassport.rawValue].stringValue != "") {

                patient.icOrPassport  = json[PatientInfoKey.ICOrPassport.rawValue].stringValue
            }
            if (json[PatientInfoKey.MobileNumber.rawValue].stringValue != "") {

                patient.mobileNumber  = json[PatientInfoKey.MobileNumber.rawValue].stringValue
            }
            if (json[PatientInfoKey.Gender.rawValue].stringValue != "") {

                patient.gender  = json[PatientInfoKey.Gender.rawValue].stringValue
            }
        }
    }
        class func updatePatientPaymentTypeIDInfo(patient: PatientInfo, json: JSON) {
            let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
            if (encryptedCaseKey != ""){
            let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
            if (caseKey != "") {
                if (json[PatientInfoKey.PaymentType.rawValue].dictionary !=  nil) {
                    patient.paymentType  = AESWrapper.decryptTheText(json[PatientInfoKey.PaymentType.rawValue][PatientInfoKey.Value.rawValue].stringValue, key: caseKey)
                    patient.paymentTypeID  = AESWrapper.decryptTheText(json[PatientInfoKey.PaymentType.rawValue][PatientInfoKey.ID.rawValue].stringValue, key: caseKey)

                }
                }
            } else {
                if (json[PatientInfoKey.PaymentType.rawValue].dictionary !=  nil) {
                    patient.paymentType  = json[PatientInfoKey.PaymentType.rawValue][PatientInfoKey.Value.rawValue].stringValue
                    patient.paymentTypeID  = json[PatientInfoKey.PaymentType.rawValue][PatientInfoKey.ID.rawValue].stringValue

                }
            }
        }
}
