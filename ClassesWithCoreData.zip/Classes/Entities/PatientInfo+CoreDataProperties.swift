//  PatientInfo+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
extension PatientInfo {
    @NSManaged var age: NSObject?
    @NSManaged var caseKey: NSObject?
    @NSManaged var caseID: String?
    @NSManaged var tempCaseID: String?
    @NSManaged var caseStatus: String?
    @NSManaged var countryCode: String?
    @NSManaged var firstName: NSObject?
    @NSManaged var middleName: NSObject?
    @NSManaged var gender: NSObject?
    @NSManaged var lastName: NSObject?
    @NSManaged var mobileNumber: NSObject?
    @NSManaged var icOrPassport: NSObject?
    @NSManaged var citizenshipType: NSObject?
    @NSManaged var citizenshipTypeID: NSObject?
    @NSManaged var paymentType: NSObject?
    @NSManaged var paymentTypeID: NSObject?
    @NSManaged var syncStatus: NSNumber?
    @NSManaged var patientID: String?
    @NSManaged var hospitalCaseID: String?
    @NSManaged var ecgInfo: ECGInfo?
    @NSManaged var timeLine: TimeLine?
    @NSManaged var fmcInfo: FMCCentre?
    @NSManaged var treatmentInfo: TreatmentCentre?
    @NSManaged var patientHistory: PatientHistory?
    @NSManaged var editInfarctArea: Bool
    @NSManaged var isCathLabReady: Bool
}
