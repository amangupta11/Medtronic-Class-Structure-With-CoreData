//  ECGInfo+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
extension ECGInfo {
    @NSManaged var ecgURL: String?
    @NSManaged var localPath: String?
    @NSManaged var ecgFileName: String?
    @NSManaged var patientInfo: PatientInfo?
}
