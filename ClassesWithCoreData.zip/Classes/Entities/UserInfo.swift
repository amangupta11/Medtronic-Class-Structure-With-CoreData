//  UserInfo.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON
enum UserInfoKey: String {
    case EmailAddress               = "emailAddress"
    case FirstName                  = "firstName"
    case HospitalName               = "hospitalName"
    case HospitalTypeID             = "hospitalTypeID"
    case HospitalID                 = "hospitalID"
    case LastName                   = "lastName"
    case Passcode                   = "passcode"
    case Password                   = "password"
    case PhoneNumber                = "mobileNumber"
    case Title                      = "title"
    case UserID                     = "userID"
    case RoleID                     = "roleID"
    case CountryCode                = "countryCode"
    case ProfilePicURL              = "profilePicURL"
    case Gender                     = "gender"
    case Token                      = "token"
    case ExpiresIn                  = "expiresIn"
    case UserName                   = "username"
    case UserInfo                   = "UserInfo"
    case refreshToken = "refreshToken"
    case UUID = "uuID"
    case Designation = "designation"
}
class UserInfo: NSManagedObject {
    // Insert code here to add functionality to your managed object subclass
    var json: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[UserInfoKey.EmailAddress.rawValue] = self.emailAddress
            dictionary[UserInfoKey.FirstName.rawValue] = self.firstName
            dictionary[UserInfoKey.HospitalName.rawValue] = self.hospitalName
            dictionary[UserInfoKey.HospitalID.rawValue] = self.hospitalID
            dictionary[UserInfoKey.LastName.rawValue] = self.lastName
            dictionary[UserInfoKey.Passcode.rawValue] = self.passcode
            dictionary[UserInfoKey.Password.rawValue] = self.password
            dictionary[UserInfoKey.PhoneNumber.rawValue] = self.phoneNumber
            dictionary[UserInfoKey.Title.rawValue] = self.title
            dictionary[UserInfoKey.UserID.rawValue] = self.userID
            dictionary[UserInfoKey.UserName.rawValue] = self.username
            dictionary[UserInfoKey.RoleID.rawValue] = self.roleID
            dictionary[UserInfoKey.Gender.rawValue] = self.gender
            dictionary[UserInfoKey.ProfilePicURL.rawValue] = self.profilePicURL
            dictionary[UserInfoKey.CountryCode.rawValue] = self.countryCode
            dictionary[UserInfoKey.Token.rawValue] = self.token
            dictionary[UserInfoKey.ExpiresIn.rawValue] = self.expiresIn
            dictionary[UserInfoKey.HospitalTypeID.rawValue] = self.hospitalTypeID
            dictionary[UserInfoKey.Designation.rawValue] = self.designation
            let json = JSON(dictionary)
            return json
        }
    }
    // MARK: - Get user info by passing the userID
    class func getUserForUserId(userId: String) -> UserInfo? {
        let predicate: NSPredicate = NSPredicate(format: "userID == %@", argumentArray: [userId])
        let user: UserInfo? = DataOperation.sharedDataOperation.fetchObjectForEntity(UserInfoKey.UserInfo.rawValue, predicate: predicate) as? UserInfo
        return user
    }
    class func getUserForUsername(username: String) -> UserInfo? {
        let predicate: NSPredicate = NSPredicate(format: "username == %@", argumentArray: [username])
        let user: UserInfo? = DataOperation.sharedDataOperation.fetchObjectForEntity(UserInfoKey.UserInfo.rawValue, predicate: predicate) as? UserInfo
        return user
    }
    // MARK: - Insert / Update the UserInfo
    class func insertUserProfile(json: JSON) -> UserInfo? {
        let userId = json[UserInfoKey.UserID.rawValue].stringValue
        var user: UserInfo? = UserInfo.getUserForUserId(userId)
        if user == nil {
            user = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(UserInfoKey.UserInfo.rawValue) as? UserInfo
        }
        if let user = user {
            let u = updateProfile(user, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateProfile(user: UserInfo, json: JSON) -> UserInfo {
        user.emailAddress  =  json[UserInfoKey.EmailAddress.rawValue].stringValue
        user.firstName  =  json[UserInfoKey.FirstName.rawValue].stringValue
        user.hospitalName  =  json[UserInfoKey.HospitalName.rawValue].stringValue
        user.hospitalID  =  json[UserInfoKey.HospitalID.rawValue].stringValue
        user.hospitalTypeID  =  json[UserInfoKey.HospitalTypeID.rawValue].stringValue
        user.lastName  =  json[UserInfoKey.LastName.rawValue].stringValue
        user.phoneNumber  =  json[UserInfoKey.PhoneNumber.rawValue].stringValue
        user.title  =  json[UserInfoKey.Title.rawValue].stringValue
        user.gender  =  json[UserInfoKey.Gender.rawValue].stringValue
        user.profilePicURL  =  json[UserInfoKey.ProfilePicURL.rawValue].stringValue
        user.countryCode  =  json[UserInfoKey.CountryCode.rawValue].stringValue
        user.token  =  json[UserInfoKey.Token.rawValue].stringValue
        user.expiresIn = json[UserInfoKey.ExpiresIn.rawValue].stringValue
        user.userID  =  json[UserInfoKey.UserID.rawValue].stringValue
        user.roleID  =  json[UserInfoKey.RoleID.rawValue].stringValue
        user.passcode =  json[UserInfoKey.Passcode.rawValue].numberValue
        user.password  =  json[UserInfoKey.Password.rawValue].stringValue
        user.username  =  json[UserInfoKey.UserName.rawValue].stringValue
        user.designation = json[UserInfoKey.Designation.rawValue].stringValue
        return user
    }
    // MARK: - Insert / Update the UserInfo
    class func updateUserProfile(json: JSON) -> UserInfo? {
        let userId = json[UserInfoKey.UserID.rawValue].stringValue
        var user: UserInfo? = UserInfo.getUserForUserId(userId)
        if user == nil {
            user = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(UserInfoKey.UserInfo.rawValue) as? UserInfo
        }
        if let user = user {
            let u = updateDetailProfile(user, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateDetailProfile(user: UserInfo, json: JSON) -> UserInfo {
        user.emailAddress  =  json[UserInfoKey.EmailAddress.rawValue].stringValue
        user.firstName  =  json[UserInfoKey.FirstName.rawValue].stringValue
        user.hospitalName  =  json[UserInfoKey.HospitalName.rawValue].stringValue
        user.hospitalID  =  json[UserInfoKey.HospitalID.rawValue].stringValue
        user.hospitalTypeID  =  json[UserInfoKey.HospitalTypeID.rawValue].stringValue
        user.lastName  =  json[UserInfoKey.LastName.rawValue].stringValue
        user.phoneNumber  =  json[UserInfoKey.PhoneNumber.rawValue].stringValue
        user.title  =  json[UserInfoKey.Title.rawValue].stringValue
        user.gender  =  json[UserInfoKey.Gender.rawValue].stringValue
        user.profilePicURL  =  json[UserInfoKey.ProfilePicURL.rawValue].stringValue
        user.countryCode  =  json[UserInfoKey.CountryCode.rawValue].stringValue
        user.designation  =  json[UserInfoKey.Designation.rawValue].stringValue
        if json[UserInfoKey.Token.rawValue].stringValue != "" {
            user.token  =  json[UserInfoKey.Token.rawValue].stringValue
        }
        return user
    }
    // MARK: - Insert / Update the UserInfo
    class func updateUserName(json: JSON) -> UserInfo? {
        let userId = json[UserInfoKey.UserID.rawValue].stringValue
        var user: UserInfo? = UserInfo.getUserForUserId(userId)
        if user == nil {
            user = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(UserInfoKey.UserInfo.rawValue) as? UserInfo
        }
        if let user = user {
            let u = updateName(user, username: json[UserInfoKey.UserName.rawValue].stringValue)
            return u
        } else {
            return nil
        }
    }
    class func updateName(user: UserInfo, username: String) -> UserInfo? {
        user.username  =  username
        return user
    }

    class func updateToken(user: UserInfo, token: String) -> UserInfo? {
        user.token  =  token
        return user
    }
    class func updateAccessTokenExpiryTime(user: UserInfo, expiryTime: String) -> UserInfo? {
        user.expiresIn = expiryTime
        return user
    }
    class func udpateRefreshToken(user: UserInfo, refreshToken: String) -> UserInfo? {
        
        user.refreshToken  =  refreshToken
        return user
    }

    class func udpateUUID(user: UserInfo, UUID: String) -> UserInfo? {
        user.uuID  =  UUID
        return user
    }


}
