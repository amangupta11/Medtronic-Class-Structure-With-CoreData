//  PatientHistory.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON

enum PatientHistoryInfoKey: String {
    case PatientHistoryTable       = "PatientHistory"
    case PatientHistory            = "patientHistory"
    case Systolic                  = "patientSystolic"
    case Diastolic                 = "patientDiastolic"
    case Pulse                     = "patientPulse"
    case Temperature               = "patientBodyTemperature"
    case Spo2                      = "patientSpO2"
    case PrimaryComplaint          = "presentingComplaint"
    
    case KillipScore                      = "killipScore"
    
    case Id                        =    "id"
    case Value                     =    "value"
    
    case Time               =    "presentingComplaintTime"
    case Description               =    "presentingDescription"
    
    case CaseID               =    "caseID"

    case Anteroseptal                      = "anteroseptal"
    case Anterior                      = "anterior"
    case Lateral                      = "lateral"
    case ExtensiveAnterolateral                      = "extensiveAnterolateral"
    case Inferior                      = "inferior"
    case Posterior                      = "posterior"
    case RightSided                      = "rightSided"
    case LeftMainStem                      = "leftMainStem"
    case Others                      = "others"
    case Comments                      = "comment"
    case VitalSigns                      = "vitalSigns"
    case InfarctArea                      = "infarctAreas"
    case InfarctAreas                      = "infarctArea"
    case patientEstimatedWeight     =   "patientEstimatedWeight"
    case patientTroponin     =   "patientTroponin"
    case patientPointOfFMC     =   "patientPointOfFMC"



}

class PatientHistory: NSManagedObject {

    var vitalSignsJson: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.CaseID.rawValue] = self.patientInfo?.caseID
            dictionary[PatientInfoKey.CaseStatus.rawValue] = self.patientInfo?.caseStatus
            if (self.systolic != nil) {
                var vitalSigns: [String:AnyObject] = [:]
                vitalSigns[PatientHistoryInfoKey.Systolic.rawValue] = self.systolic
                vitalSigns[PatientHistoryInfoKey.Diastolic.rawValue] = self.diastolic
                vitalSigns[PatientHistoryInfoKey.Pulse.rawValue] = self.pulse
                vitalSigns[PatientHistoryInfoKey.Temperature.rawValue] = self.temperature
                vitalSigns[PatientHistoryInfoKey.Spo2.rawValue] = self.spo2
                vitalSigns[PatientHistoryInfoKey.KillipScore.rawValue] = self.killipScore
                dictionary[PatientHistoryInfoKey.VitalSigns.rawValue] = vitalSigns
                dictionary["versioningNeeded"] = self.patientInfo?.editInfarctArea.boolValue
            }
            let json = JSON(dictionary)
            return json
        }
    }

    var infactAreaJson: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.CaseID.rawValue] = self.patientInfo?.caseID
            dictionary[PatientInfoKey.CaseStatus.rawValue] = self.patientInfo?.caseStatus

            var timeLine: [String:AnyObject] = [:]
            timeLine[TimeLineKey.Comment.rawValue] = nil
            timeLine[TimeLineKey.Location.rawValue] = nil
            timeLine[TimeLineKey.Time.rawValue] = self.patientInfo?.timeLine?.stemiTime
            dictionary[TimeLineKey.StemiTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.patientInfo?.timeLine?.notAStemiTime
            dictionary[TimeLineKey.NotAStemiTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.patientInfo?.timeLine?.diagnoseECGTime
            dictionary[TimeLineKey.DiagnoseECGTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.patientInfo?.timeLine?.diagnoseTime
            dictionary[TimeLineKey.DaignoseTime.rawValue] = timeLine

            timeLine[TimeLineKey.Comment.rawValue] = self.patientInfo?.patientHistory?.uncleatECGComments
            timeLine[TimeLineKey.Time.rawValue] = self.patientInfo?.timeLine?.unclearECGTime
            dictionary[TimeLineKey.UnclearECGTime.rawValue] = timeLine

            timeLine[TimeLineKey.Comment.rawValue] = nil
            dictionary[TimeLineKey.FreshUpload.rawValue] = self.patientInfo?.patientHistory?.isFreshUpload
            dictionary["versioningNeeded"] = self.patientInfo?.editInfarctArea.boolValue

            if  self.patientInfo?.timeLine?.diagnoseTime != 0 {
                dictionary[TimeLineKey.DiagnoseAsStemi.rawValue] = self.patientInfo?.timeLine?.isStemi?.boolValue
            }

            var infarctArea: [String:AnyObject] = [:]
            infarctArea[ECGInfoKey.EcgURL.rawValue] = self.patientInfo?.ecgInfo?.ecgURL
            infarctArea[ECGInfoKey.EcgName.rawValue] = self.patientInfo?.ecgInfo?.ecgFileName
            infarctArea[PatientHistoryInfoKey.Anteroseptal.rawValue] = self.anteroseptal?.boolValue
            infarctArea[PatientHistoryInfoKey.Anterior.rawValue] = self.anterior?.boolValue
            infarctArea[PatientHistoryInfoKey.Lateral.rawValue] = self.lateral?.boolValue
            infarctArea[PatientHistoryInfoKey.ExtensiveAnterolateral.rawValue] = self.extensiveanterolateral?.boolValue
            infarctArea[PatientHistoryInfoKey.Inferior.rawValue] = self.inferior?.boolValue
            infarctArea[PatientHistoryInfoKey.Posterior.rawValue] = self.posterior?.boolValue
            infarctArea[PatientHistoryInfoKey.RightSided.rawValue] = self.rightsided?.boolValue
            infarctArea[PatientHistoryInfoKey.Others.rawValue] = self.others?.boolValue
            infarctArea[PatientHistoryInfoKey.LeftMainStem.rawValue] = self.leftmainstem?.boolValue
            infarctArea[PatientHistoryInfoKey.Comments.rawValue] = self.otherscomments != nil ? self.otherscomments : ""
            dictionary[PatientHistoryInfoKey.InfarctAreas.rawValue] = infarctArea

            let json = JSON(dictionary)
            return json
        }
    }
    // Insert code here to add functionality to your managed object subclass
    // MARK: - Insert / Update the patientHistory
    class func insertPatientHistory(patient: PatientInfo, json: JSON) -> PatientHistory? {
        var patientHistory: PatientHistory? = patient.patientHistory
        if patientHistory == nil {
            patientHistory = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(PatientHistoryInfoKey.PatientHistoryTable.rawValue) as? PatientHistory
            patient.patientHistory = patientHistory
        }
        if let patientHistory = patientHistory {
            let u = updatePatientHistory(patientHistory, patient:patient, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }

    class func updatePatientHistory(patientHistory: PatientHistory, patient: PatientInfo, json: JSON) -> PatientHistory? {
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != "") {
            let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
            if (caseKey != "") {
                if (json[PatientHistoryInfoKey.VitalSigns.rawValue].array != nil) {
                    
                    let dictJson = json[PatientHistoryInfoKey.VitalSigns.rawValue].array?.first
                    patientHistory.systolic = AESWrapper.decryptTheText(String(dictJson! [PatientHistoryInfoKey.Systolic.rawValue].stringValue), key: caseKey)
                    patientHistory.diastolic = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Diastolic.rawValue].stringValue), key: caseKey)
                    patientHistory.pulse = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Pulse.rawValue].stringValue), key: caseKey)
                    patientHistory.temperature = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Temperature.rawValue].stringValue), key: caseKey)
                    patientHistory.spo2 = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Spo2.rawValue].stringValue), key: caseKey)
                    
                    let killip  = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.KillipScore.rawValue].stringValue), key: caseKey)
                    patientHistory.killipScore = Int(killip)
                    
                }
        if (json[PatientHistoryInfoKey.InfarctArea.rawValue].array != nil) {

            let dictJson = json[PatientHistoryInfoKey.InfarctArea.rawValue].array?.first
            let anteroseptal = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Anteroseptal.rawValue].stringValue, key: caseKey)
            patientHistory.anteroseptal = false
            if (anteroseptal == "true") {
                patientHistory.anteroseptal = true
            }
            let anterior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Anterior.rawValue].stringValue, key: caseKey)
            patientHistory.anterior = false
            if (anterior == "true") {
                patientHistory.anterior = true
            }

            let lateral = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Lateral.rawValue].stringValue, key: caseKey)
            patientHistory.lateral = false
            if (lateral == "true") {
                patientHistory.lateral = true
            }

            let extensiveanterolateral = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.ExtensiveAnterolateral.rawValue].stringValue, key: caseKey)
            patientHistory.extensiveanterolateral = false
            if (extensiveanterolateral == "true") {
                patientHistory.extensiveanterolateral = true
            }

            let inferior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Inferior.rawValue].stringValue, key: caseKey)
            patientHistory.inferior = false
            if (inferior == "true") {
                patientHistory.inferior = true
            }

            let posterior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Posterior.rawValue].stringValue, key: caseKey)
            patientHistory.posterior = false
            if (posterior == "true") {
                patientHistory.posterior = true
            }
            let rightsided = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.RightSided.rawValue].stringValue, key: caseKey)
            patientHistory.rightsided = false
            if (rightsided == "true") {
                patientHistory.rightsided = true
            }

            let leftMainStem = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.LeftMainStem.rawValue].stringValue, key: caseKey)
            patientHistory.leftmainstem = false
            if (leftMainStem == "true") {
                patientHistory.leftmainstem = true
            }

            let others = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Others.rawValue].stringValue, key: caseKey)
            patientHistory.others = false
            if (others == "true") {
                patientHistory.others = true
            }
            if (dictJson![PatientHistoryInfoKey.Comments.rawValue].stringValue != "") {
            patientHistory.otherscomments = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Comments.rawValue].stringValue, key: caseKey)
            }
        }
        }
    }
        return patientHistory
    }
}
