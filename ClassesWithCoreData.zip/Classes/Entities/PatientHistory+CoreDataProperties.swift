//  PatientHistory+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
extension PatientHistory {
    @NSManaged var systolic: String?
    @NSManaged var diastolic: String?
    @NSManaged var pulse: String?
    @NSManaged var temperature: String?
    @NSManaged var uncleatECGComments: String?
    @NSManaged var isFreshUpload: NSNumber?

    @NSManaged var spo2: String?
    @NSManaged var killipScore: NSNumber?

    @NSManaged var anteroseptal: NSNumber?
    @NSManaged var anterior: NSNumber?
    @NSManaged var lateral: NSNumber?
    @NSManaged var extensiveanterolateral: NSNumber?
    @NSManaged var inferior: NSNumber?
    @NSManaged var posterior: NSNumber?
    @NSManaged var rightsided: NSNumber?
    @NSManaged var leftmainstem: NSNumber?
    @NSManaged var others: NSNumber?
    @NSManaged var otherscomments: String?

    @NSManaged var patientInfo: PatientInfo?

}
