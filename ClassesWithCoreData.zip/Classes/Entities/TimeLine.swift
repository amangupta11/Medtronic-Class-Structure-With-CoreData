//  TimeLine.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import Foundation
import CoreData
import SwiftyJSON
enum TimeLineKey: String {
    case FirstECGTime   = "firstEcgCaptureTime"
    case FmcDoorInTime  = "fmcDoorInTime"
    case OnsetTime  = "onSetTime"
    case TriageTime  = "triageTime"
    case FmcDoorOutTime = "fmcDoorOutTime"
    case HubDoorInTime  = "hubDoorInTime"
    case HubDoorOutTime  = "hubDoorOutTime"
    case StemiTime      = "activateStemiTime"
    case NotAStemiTime = "notStemiTime"
    case DiagnoseECGTime = "diagnoseECGTime"
    case AddNewCaseTime = "addNewCaseTime"
    case SpokeTransferTime = "caseTransferTime"
    case HubInternalTransferTime = "internalTransferTime"
    case CathLabAcceptedTime = "cathlabAcceptedTime"
    case DeviceCrossTime = "deviceCrossTime"
    case StoppedTime = "timerStopTime"
    case CathLabExitTime = "cathlabExitTime"
    case TreatmentCompletedTime  = "caseCompleteTime"
    case CaseTimeLines = "caseTimeLines"
    case EditCount = "editCount"
    case Actual = "actual"
    case FirstEdit = "firstEdit"
    case SecondEdit = "secondEdit"
    case ThirdEdit = "thirdEdit"
    case CathLabReadyToAcceptCaseTime = "cathLabReadyToAcceptCaseTime"
    case UnclearECGTime   = "unclearECGTime"
    case DaignoseTime   = "diagnoseTime"
    case DiagnoseAsStemi   = "diagnoseAsStemi"
    case DiagnosedAsStemi   = "diagnosedAsStemi"
    case CancelTreatmentTime = "cancelTreatmentTime"
    case UnclearECGComments   = "unclearEcgComment"
    case FreshUpload   = "newEcgUploaded"

    case TimeLine = "TimeLine"
    case Time  = "time"
    case Comment  = "comment"
    case Location  = "location"
    case TimeLineDetailList  = "timeLineDetailList"


}
class TimeLine: NSManagedObject {
    // Insert code here to add functionality to your managed object subclass
    var json: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            var timeLine: [String:AnyObject] = [:]
            timeLine[TimeLineKey.Comment.rawValue] = nil
            timeLine[TimeLineKey.Location.rawValue] = nil

            timeLine[TimeLineKey.Time.rawValue] = self.firstECGTime?.stringValue
            dictionary[TimeLineKey.FirstECGTime.rawValue] = timeLine

            let count = self.fmcDoorInEditCount
            let numberFromString = Int(count!)
            if numberFromString < 4 {
                timeLine[TimeLineKey.Time.rawValue] = self.fmcDoorInTime?.stringValue
                dictionary[TimeLineKey.FmcDoorInTime.rawValue] = timeLine
            }
            timeLine[TimeLineKey.Time.rawValue] = self.onsetTime?.stringValue
            dictionary[TimeLineKey.OnsetTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.triageTime?.stringValue
            dictionary[TimeLineKey.TriageTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.fmcDoorOutTime?.stringValue
            dictionary[TimeLineKey.FmcDoorOutTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.hubDoorInTime?.stringValue
            dictionary[TimeLineKey.HubDoorInTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.hubDoorOutTime?.stringValue
            dictionary[TimeLineKey.HubDoorOutTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.stemiTime?.stringValue
            dictionary[TimeLineKey.StemiTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.addNewCaseTime?.stringValue
            dictionary[TimeLineKey.AddNewCaseTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.spokeTransferTime?.stringValue
            dictionary[TimeLineKey.SpokeTransferTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.hubInternalTransferTime?.stringValue
            dictionary[TimeLineKey.HubInternalTransferTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.cathLabAcceptedTime?.stringValue
            dictionary[TimeLineKey.CathLabAcceptedTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.deviceCrossTime?.stringValue
            dictionary[TimeLineKey.DeviceCrossTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.cathLabExitTime?.stringValue
            dictionary[TimeLineKey.CathLabExitTime.rawValue] = timeLine

            timeLine[TimeLineKey.Time.rawValue] = self.treatmentCompletedTime?.stringValue
            dictionary[TimeLineKey.TreatmentCompletedTime.rawValue] = timeLine


            let json = JSON(dictionary)
            return json
        }
    }
    // MARK: - Insert / Update the TimeLine
    class func insertTimeLine(patient: PatientInfo, json: JSON) -> TimeLine? {
        var timeline: TimeLine? = patient.timeLine
        if timeline == nil {
            timeline = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TimeLineKey.TimeLine.rawValue) as? TimeLine
            patient.timeLine = timeline
        }
        if let timeline = timeline {
            let u = updateTimeLine(timeline, patient:patient, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateTimeLineWithCaseTimeline(timeline: TimeLine, patient: PatientInfo, json: JSON) -> TimeLine {
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorInTime = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.AddNewCaseTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.AddNewCaseTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.addNewCaseTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StoppedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StoppedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.stoppedTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorOutTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.onsetTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TriageTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TriageTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.triageTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubDoorOutTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubDoorOutTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabAcceptedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabAcceptedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabAcceptedTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DeviceCrossTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DeviceCrossTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.deviceCrossTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabExitTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabExitTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabExitTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubInternalTransferTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubInternalTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubInternalTransferTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TreatmentCompletedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TreatmentCompletedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.treatmentCompletedTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CancelTreatmentTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CancelTreatmentTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cancelTreatmentTime  = time
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.SpokeTransferTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.SpokeTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.spokeTransferTime  = time
        }
        if (json[TimeLineKey.CaseTimeLines.rawValue].dictionary != nil) {
            updateCaseTimeline(timeline, patient: patient, json: json)
        }
        return timeline
    }
    class func updateTimeLine(timeline: TimeLine, patient: PatientInfo, json: JSON) -> TimeLine {
        if (json [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorInTime = time
        }
        if (json [TimeLineKey.AddNewCaseTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.AddNewCaseTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
           timeline.addNewCaseTime  = time
        }
        if (json [TimeLineKey.StoppedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StoppedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.stoppedTime  = time
        }
        if (json [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorOutTime  = time
        }
        if (json [TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.onsetTime  = time
        }
        if (json [TimeLineKey.TriageTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.TriageTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.triageTime  = time
        }
        if (json [TimeLineKey.HubDoorOutTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.HubDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubDoorOutTime  = time
        }
        if (json [TimeLineKey.CathLabAcceptedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CathLabAcceptedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabAcceptedTime  = time
        }
        if (json [TimeLineKey.DeviceCrossTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.DeviceCrossTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.deviceCrossTime  = time
        }
        if (json [TimeLineKey.CathLabExitTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CathLabExitTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabExitTime  = time
        }
        if (json [TimeLineKey.HubInternalTransferTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.HubInternalTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubInternalTransferTime  = time
        }
        if (json [TimeLineKey.TreatmentCompletedTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.TreatmentCompletedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.treatmentCompletedTime  = time
        }
        if (json [TimeLineKey.CancelTreatmentTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.CancelTreatmentTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cancelTreatmentTime  = time
        }

        if (json[TimeLineKey.SpokeTransferTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.SpokeTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.spokeTransferTime  = time
        }

        if (json [TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var editedText: String?
            var  timeDict:[String:JSON]?
            if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.onsetEditCount = String(format:"%@",
                                             "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.onsetEditCount = String(format:"%@",
                                                 "1")
                }
            }
            if array?.count > 2 {
                timeDict =  array![(array?.count)!-2].dictionary
                let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double

                if secondEdit != nil {
                    editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                    timeline.onsetEditCount = String(format:"%@",
                                                     "2")
                }
                if array?.count > 3 {
                    timeDict =  array![(array?.count)!-3].dictionary
                    let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double

                    if thirdEdit != nil {
                        editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                        timeline.onsetEditCount = String(format:"%@",
                                                         "3")
                    }
                }
            }
            timeline.onsetEditedText  = editedText
            timeDict =  array![0].dictionary
            timeline.onsetTime = timeDict![TimeLineKey.Time.rawValue]?.double
        }
        if (json [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil){
            var array = json [TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var editedText: String?
            var  timeDict:[String:JSON]?
            if array?.count > 1 {
                timeDict =  array![(array?.count)!-1].dictionary
                let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                timeline.fmcDoorInEditCount = String(format:"%@",
                                                     "0")
                if firstEdit != nil {
                    editedText = String(format:"%@",
                                        DateUtility.convertGMTtoShortTime(firstEdit!))
                    timeline.fmcDoorInEditCount = String(format:"%@",
                                                         "1")
                }
            }
            if array?.count > 2 {
                timeDict =  array![(array?.count)!-2].dictionary
                let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if secondEdit != nil {
                    editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                    timeline.fmcDoorInEditCount = String(format:"%@",
                                                         "2")
                }
                if array?.count > 3 {
                    timeDict =  array![(array?.count)!-3].dictionary
                    let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                    
                    if thirdEdit != nil {
                        editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                        timeline.fmcDoorInEditCount = String(format:"%@",
                                                             "3")
                    }
                }
            }
            timeline.fmcDoorInEditedText  = editedText
            timeDict =  array![0].dictionary
            timeline.fmcDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
        }
        return timeline
    }
    class func updateCaseTimeline(timeline: TimeLine, patient: PatientInfo, json: JSON) {
        updateCaseTimelineDetails(timeline, patient: patient, json: json)
    }
    class func updateCaseTimelineDetails(timeline: TimeLine, patient: PatientInfo, json: JSON) {
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            updateFmcDoorOut(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.HubDoorOutTime.rawValue].dictionary  != nil) {
            updateHubDoorOut(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.CathLabAcceptedTime.rawValue].dictionary  != nil) {
            updateCathLabAccepted(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.DeviceCrossTime.rawValue].dictionary  != nil) {
            updateDeviceCrossTime(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.CathLabExitTime.rawValue].dictionary  != nil) {
            updateCathLabExit(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            updateFmcDoorIn(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.HubDoorInTime.rawValue].dictionary  != nil) {
            updateHubDoorInTime(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            updateOnsetTime(timeline, patient: patient, json: json)
        }
        if (json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.TriageTime.rawValue].dictionary  != nil) {
            updateTriageTime(timeline, patient: patient, json: json)
        }
    }

    class func updateOnsetTime(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.onsetEditCount = String(format:"%@",
                                             "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.onsetEditCount = String(format:"%@",
                                                 "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.onsetEditCount = String(format:"%@",
                                                 "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.onsetEditCount = String(format:"%@",
                                                     "3")
                }
            }
        }
        timeline.onsetEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.onsetTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateTriageTime(timeline: TimeLine, patient: PatientInfo, json: JSON) {
        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.TriageTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.triageEditCount = String(format:"%@",
                                             "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.triageEditCount = String(format:"%@",
                                                 "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.triageEditCount = String(format:"%@",
                                                 "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.triageEditCount = String(format:"%@",
                                                     "3")
                }
            }
        }
        timeline.triageEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.triageTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateHubDoorInTime(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.HubDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubDoorInEditCount = String(format:"%@",
                                              "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.hubDoorInEditCount = String(format:"%@",
                                                  "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.hubDoorInEditCount = String(format:"%@",
                                                  "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.hubDoorInEditCount = String(format:"%@",
                                                      "3")
                }
            }
        }
        timeline.hubDoorInEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.hubDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }

    class func updateFmcDoorIn(timeline: TimeLine, patient: PatientInfo, json: JSON) {
        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorInEditCount = String(format:"%@",
                                                 "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.fmcDoorInEditCount = String(format:"%@",
                                                     "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.fmcDoorInEditCount = String(format:"%@",
                                                     "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.fmcDoorInEditCount = String(format:"%@",
                                                         "3")
                }
            }
        }
        timeline.fmcDoorInEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.fmcDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateFmcDoorOut(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.fmcDoorOutEditCount = String(format:"%@",
                                                 "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.fmcDoorOutEditCount = String(format:"%@",
                                                     "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.fmcDoorOutEditCount = String(format:"%@",
                                                     "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.fmcDoorOutEditCount = String(format:"%@",
                                                         "3")
                }
            }
        }
        timeline.fmcDoorOutEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.fmcDoorOutTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateHubDoorOut(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.HubDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubDoorOutEditCount = String(format:"%@",
                                                  "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.hubDoorOutEditCount = String(format:"%@",
                                                      "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.hubDoorOutEditCount = String(format:"%@",
                                                      "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.hubDoorOutEditCount = String(format:"%@",
                                                          "3")
                }
            }
        }
        timeline.hubDoorOutEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.hubDoorOutTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateHubDoorIn(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.HubDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.hubDoorInEditCount = String(format:"%@",
                                                  "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.hubDoorInEditCount = String(format:"%@",
                                                      "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.hubDoorInEditCount = String(format:"%@",
                                                      "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.hubDoorInEditCount = String(format:"%@",
                                                          "3")
                }
            }
        }
        timeline.hubDoorInEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.hubDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }

    class func updateCathLabAccepted(timeline: TimeLine, patient: PatientInfo, json: JSON) {


        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.CathLabAcceptedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabAcceptedEditCount = String(format:"%@",
                                                 "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.cathLabAcceptedEditCount = String(format:"%@",
                                                     "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.cathLabAcceptedEditCount = String(format:"%@",
                                                     "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.cathLabAcceptedEditCount = String(format:"%@",
                                                         "3")
                }
            }
        }
        timeline.cathLabAcceptedEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.cathLabAcceptedTime = timeDict![TimeLineKey.Time.rawValue]?.double

    }
    class func updateDeviceCrossTime(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.DeviceCrossTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.deviceCrossTimeEditCount = String(format:"%@",
                                                       "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.deviceCrossTimeEditCount = String(format:"%@",
                                                           "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.deviceCrossTimeEditCount = String(format:"%@",
                                                           "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.deviceCrossTimeEditCount = String(format:"%@",
                                                               "3")
                }
            }
        }
        timeline.deviceCrossTimeEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.deviceCrossTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateCathLabExit(timeline: TimeLine, patient: PatientInfo, json: JSON) {

        var array = json [TimeLineKey.CaseTimeLines.rawValue] [TimeLineKey.CathLabExitTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            timeline.cathLabExitEditCount = String(format:"%@",
                                                       "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                timeline.cathLabExitEditCount = String(format:"%@",
                                                           "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                timeline.cathLabExitEditCount = String(format:"%@",
                                                           "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    timeline.cathLabExitEditCount = String(format:"%@",
                                                               "3")
                }
            }
        }
        timeline.cathLabExitEditedText  = editedText
        timeDict =  array![0].dictionary
        timeline.cathLabExitTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
}
