//  ECGInfo.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON

enum ECGInfoKey: String {
    case EcgURL               = "ecgUrl"
    case EcgName               = "ecgName"
    case ECGInfo               = "ECGInfo"
}
class ECGInfo: NSManagedObject {
    // Insert code here to add functionality to your managed object subclass
    var json: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[ECGInfoKey.EcgURL.rawValue] = self.ecgURL
            let json = JSON(dictionary)
            return json
        }
    }
    // MARK: - Insert / Update the ECGInfo
    class func insertECGInfo(patient: PatientInfo, json: JSON) -> ECGInfo? {
        var ecg: ECGInfo? = patient.ecgInfo
        if ecg == nil {
            ecg = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(ECGInfoKey.ECGInfo.rawValue) as? ECGInfo
            patient.ecgInfo = ecg
        }
        if let ecg = ecg {
            let u = updateECGInfo(ecg, patient:patient, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateECGInfo(ecg: ECGInfo, patient: PatientInfo, json: JSON) -> ECGInfo {
        if patient.ecgInfo?.ecgURL != nil {
            ecg.ecgURL    =  patient.ecgInfo?.ecgURL
            ecg.ecgFileName    =  patient.ecgInfo?.ecgFileName
    }
        return ecg
    }

    class func updateECGInfoFromjSon(patient: PatientInfo, json: JSON) -> ECGInfo {
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != "") {
        let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
        if (caseKey != "") {
            if (json[PatientHistoryInfoKey.InfarctArea.rawValue].array != nil) {
            let dictJson = json[PatientHistoryInfoKey.InfarctArea.rawValue].array?.first
            patient.ecgInfo?.ecgFileName =  AESWrapper.decryptTheText(dictJson![ECGInfoKey.EcgName.rawValue].stringValue, key: caseKey)
            patient.ecgInfo?.ecgURL =  AESWrapper.decryptTheText(dictJson![ECGInfoKey.EcgURL.rawValue].stringValue, key: caseKey)
        }
            }
        }
        return patient.ecgInfo!

    }

}
