//  UserInfo+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import Foundation
import CoreData
extension UserInfo {
    @NSManaged var countryCode: NSObject?
    @NSManaged var emailAddress: NSObject?
    @NSManaged var firstName: NSObject?
    @NSManaged var gender: String?
    @NSManaged var hospitalID: String?
    @NSManaged var hospitalName: String?
    @NSManaged var hospitalTypeID: String?
    @NSManaged var lastName: NSObject?
    @NSManaged var passcode: NSObject?
    @NSManaged var password: NSObject?
    @NSManaged var phoneNumber: NSObject?
    @NSManaged var profilePicURL: String?
    @NSManaged var roleID: String?
    @NSManaged var title: String?
    @NSManaged var token: NSObject?
    @NSManaged var expiresIn: NSObject?
    @NSManaged var userID: NSObject?
    @NSManaged var username: NSObject?
    @NSManaged var refreshToken: NSObject?
    @NSManaged var uuID: NSObject?
    @NSManaged var designation: String?
}
