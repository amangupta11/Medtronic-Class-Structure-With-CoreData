//
//  MEDNotification.swift
//  Medtronic
//
//  Created by Saurav Satpathy on 16/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import UIKit

class Notification: NSObject {
    var notificationId = String()
    var caseID = String()
    var hospitalCaseID = String()
    var message = String()
    var sentTime : NSTimeInterval = 0
    var timeAgo = String()
    var isRead : Bool
    var badge : Int = 0
    init(notificationId: String, caseID: String, hospitalCaseID: String, message: String, sentTime: NSTimeInterval, isRead: Bool) {
        self.caseID = caseID
        self.hospitalCaseID = hospitalCaseID
        self.message = message
        self.sentTime = sentTime
        self.timeAgo = DateUtility.timeAgo(fromSeconds: sentTime)
        self.isRead = isRead
        self.notificationId = notificationId
    }
}
