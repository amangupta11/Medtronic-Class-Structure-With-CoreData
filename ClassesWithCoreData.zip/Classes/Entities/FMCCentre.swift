//  FMCCentre.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON
enum FMCCentreInfoKey: String {
    case Abbreviation               = "abbreviation"
    case AddressLine1               = "addressLine1"
    case AddressLine2               = "addressLine2"
    case AvailableCapacity          = "availableCapacity"
    case City                       = "city"
    case Country                    = "country"
    case CountryCode                = "countryCode"
    case HospitalID                 = "hospitalID"
    case HospitalName               = "hospitalName"
    case HospitalType               = "hospitalType"
    case HospitalTypeID             = "hospitalTypeID"
    case Lattitude                  = "lattitude"
    case Longitude                  = "longitude"
    case PhoneNumber                = "phoneNumber"
    case ReasonForDelay             = "reasonForDelay"
    case State                      = "state"
    case FmcCentre                  = "fmcCenter"
    case FmcCentreTable                = "FMCCentre"
    case Consultant                 = "consultant"
    case CaseCreatedUserName        = "caseCreatedUserName"
}
class FMCCentre: NSManagedObject {
// Insert code here to add functionality to your managed object subclass
    // MARK: - Insert / Update the fmcHospitalInfo
    class func insertFMCHospital(patient: PatientInfo, json: JSON) -> FMCCentre? {
        var fmcHospitalInfo: FMCCentre? = patient.fmcInfo
        if fmcHospitalInfo == nil {
            fmcHospitalInfo = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(FMCCentreInfoKey.FmcCentreTable.rawValue) as? FMCCentre
            patient.fmcInfo = fmcHospitalInfo
        }
        if let fmcHospitalInfo = fmcHospitalInfo {
            let u = updateFMCHospitalInfo(fmcHospitalInfo, patient:patient, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateFMCHospitalInfo(fmcHospitalInfo: FMCCentre, patient: PatientInfo, json: JSON) -> FMCCentre? {
        if (json[FMCCentreInfoKey.FmcCentre.rawValue].dictionary != nil) {
        fmcHospitalInfo.hospitalID = json[FMCCentreInfoKey.FmcCentre.rawValue] [FMCCentreInfoKey.HospitalID.rawValue].string
        fmcHospitalInfo.hospitalType = json[FMCCentreInfoKey.FmcCentre.rawValue][FMCCentreInfoKey.HospitalTypeID.rawValue].string
        fmcHospitalInfo.hospitalName = json[FMCCentreInfoKey.FmcCentre.rawValue][FMCCentreInfoKey.HospitalName.rawValue].string
        fmcHospitalInfo.abbreviation = json[FMCCentreInfoKey.FmcCentre.rawValue][FMCCentreInfoKey.Abbreviation.rawValue].string
        fmcHospitalInfo.consultant = json[FMCCentreInfoKey.CaseCreatedUserName.rawValue].string
        }
        return fmcHospitalInfo
    }
}
