//  TimeLine+CoreDataProperties.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
extension TimeLine {
    @NSManaged var unclearECGTime: NSNumber?
    @NSManaged var diagnoseTime: NSNumber?
    @NSManaged var isStemi: NSNumber?

    @NSManaged var firstECGTime: NSNumber?
    @NSManaged var addNewCaseTime: NSNumber?
    @NSManaged var stemiTime: NSNumber?
    @NSManaged var notAStemiTime: NSNumber?
    @NSManaged var diagnoseECGTime: NSNumber?
    @NSManaged var spokeTransferTime: NSNumber?
    @NSManaged var hubInternalTransferTime: NSNumber?
    @NSManaged var fmcDoorOutEditedText: String?
    @NSManaged var fmcDoorOutTime: NSNumber?
    @NSManaged var fmcDoorOutEditCount: String?
    @NSManaged var fmcDoorInTime: NSNumber?
    @NSManaged var fmcDoorInEditedText: String?
    @NSManaged var fmcDoorInEditCount: String?
    @NSManaged var hubDoorInTime: NSNumber?
    @NSManaged var hubDoorInEditedText: String?
    @NSManaged var hubDoorInEditCount: String?
    @NSManaged var hubDoorOutTime: NSNumber?
    @NSManaged var hubDoorOutEditedText: String?
    @NSManaged var hubDoorOutEditCount: String?
    @NSManaged var cathLabAcceptedEditCount: String?
    @NSManaged var cathLabAcceptedEditedText: String?
    @NSManaged var cathLabAcceptedTime: NSNumber?
    @NSManaged var deviceCrossTimeEditedText: String?
    @NSManaged var deviceCrossTimeEditCount: String?
    @NSManaged var deviceCrossTime: NSNumber?
    @NSManaged var cathLabExitTime: NSNumber?
    @NSManaged var cathLabExitEditedText: String?
    @NSManaged var cathLabExitEditCount: String?
    @NSManaged var treatmentCompletedTime: NSNumber?
    @NSManaged var timerStoppedTime: NSNumber?
    @NSManaged var onsetTime: NSNumber?
    @NSManaged var onsetEditedText: String?
    @NSManaged var onsetEditCount: String?
    @NSManaged var triageTime: NSNumber?
    @NSManaged var triageEditedText: String?
    @NSManaged var triageEditCount: String?
    @NSManaged var stoppedTime: NSNumber?
    @NSManaged var cancelTreatmentTime: NSNumber?
    @NSManaged var patientInfo: PatientInfo?
}
