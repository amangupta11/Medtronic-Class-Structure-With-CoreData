//  TreatmentCentre.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
import SwiftyJSON
enum TreatmentCentreInfoKey: String {
    case Abbreviation               = "abbreviation"
    case AddressLine1               = "addressLine1"
    case AddressLine2               = "addressLine2"
    case AvailableCapacity          = "availableCapacity"
    case City                       = "city"
    case Country                    = "country"
    case CountryCode                = "countryCode"
    case HospitalID                 = "hospitalID"
    case HospitalName               = "hospitalName"
    case TreatmentCentreName        = "name"
    case HospitalType               = "hospitalType"
    case HospitalTypeID             = "hospitalTypeID"
    case Lattitude                  = "lattitude"
    case Longitude                  = "longitude"
    case PhoneNumber                = "phoneNumber"
    case ReasonForDelay             = "reasonForDelay"
    case State                      = "state"
    case TreatmentCentre            = "treatmentCenter"
    case Consultant                 = "consultant"
    case CathLabNumber              = "cathlabNumber"
    case TreatmentCentreTable       = "TreatmentCentre"
}
class TreatmentCentre: NSManagedObject {
// Insert code here to add functionality to your managed object subclass
    // MARK: - Insert / Update the treatmentInfo
    class func insertTreatmentHospital(patient: PatientInfo, json: JSON) -> TreatmentCentre? {
        var treatmentInfo: TreatmentCentre? = patient.treatmentInfo
        if treatmentInfo == nil {
            treatmentInfo = DataOperation.sharedDataOperation.insertNewObjectForEntityForName(TreatmentCentreInfoKey.TreatmentCentreTable.rawValue) as? TreatmentCentre
            patient.treatmentInfo = treatmentInfo
        }
        if let treatmentInfo = treatmentInfo {
            let u = updateTreatmentHospitalInfo(treatmentInfo, patient:patient, json:json)
            do {
                if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                    try DataOperation.sharedDataOperation.mainThreadContext.save()
                }
            } catch {
                let saveError = error as NSError
                print("\(saveError), \(saveError.userInfo)")
            }
            return u
        } else {
            return nil
        }
    }
    class func updateTreatmentHospitalInfo(treatmentInfo: TreatmentCentre, patient: PatientInfo, json: JSON) -> TreatmentCentre? {
        if (json[TreatmentCentreInfoKey.TreatmentCentre.rawValue].dictionary != nil) {
        treatmentInfo.hospitalID = String(json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.HospitalID.rawValue].intValue)
        treatmentInfo.hospitalType = String(json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.HospitalTypeID.rawValue].intValue)
        treatmentInfo.hospitalName = json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.TreatmentCentreName.rawValue].string
        treatmentInfo.abbreviation = json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.Abbreviation.rawValue].string
        treatmentInfo.phoneNumber = json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.CathLabNumber.rawValue].string
        treatmentInfo.countryCode = json[TreatmentCentreInfoKey.TreatmentCentre.rawValue][TreatmentCentreInfoKey.CountryCode.rawValue].string
        treatmentInfo.consultant = json[FMCCentreInfoKey.FmcCentre.rawValue][FMCCentreInfoKey.CaseCreatedUserName.rawValue].string
        }
        return treatmentInfo
    }
}
