//  ConfigConstants.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation

#if MED_TARGET_PRODUCTION
let baseURL = "https://MedtronicACS-2108116118.us-east-1.elb.amazonaws.com/macs-communication/services/"
#elseif MED_TARGET_STAGING
let baseURL = "http://203.123.181.194:8072/macs-communication/services/"
#elseif MED_TARGET_UAT
let baseURL = "http://34.196.66.192:8081/macs-communication/services/"
#elseif MED_TARGET_TESTING
let baseURL = "http://203.123.181.194:8070/macs-communication/services/"
#elseif MED_TARGET_DEVLOPMENT
let baseURL = "http://203.123.181.194:8071/macs-communication/services/"
//let baseURL = "http://172.16.21.168:8080/macs-communication/services/" /*Praveen's DEV Box*/
//let baseURL = "http://172.16.18.39:8080/macs-communication/services/" /*zia's Machine*/
#else
let baseURL = "http://203.123.181.194:8070/macs-communication/services/"
#endif

//Sprint 1
let userLogin = "auth/app/public/login"
let userDetails = "rest/all/user/profile/getUserDetails"

//Sprint 2
let postCaseDetails = "rest/app/case/push/updateCaseDetails"
let activateStemi = "rest/app/case/push/createCase"
let getCaseList = "rest/app/case/fetch/getCaseList"
let getCaseDetails = "rest/app/case/fetch/getCaseDetails"

//Sprint 3
let getHospitals = "rest/app/hospital/fetch/getTransferHospitalList"
let performSpokeInternalTransfer = "rest/app/case/push/transferCase"
let checkStatus = "rest/app/case/fetch/getCaseStatus"
let performHubInternalTransfer = "rest/app/case/push/internalTransferCase"
let getFMCDoorOut = "rest/app/case/fetch/getFmcDoorOutTime"
let pushFMCDoorOut = "rest/app/case/push/editFmcDoorOutTime"

//Sprint 4
let updateHubDooInTime = "rest/app/case/push/updateHubDoorInTime"
let cathLabAccepted = "rest/app/case/push/editCathlabAcceptedTime"
let deviceCrossTime = "rest/app/case/push/editDeviceCrossTime"
let cathLabExit = "rest/app/case/push/editCathlabExitTime"
let treatmentCompleted = "rest/app/case/push/editCaseCompleteTime"

//Sprint 5
let getCredential = "rest/app/content/getCredential"
let updatePatientGeneralInfo = "rest/app/patient/push/updatePatientGeneralInfo"
let updatePatientVitalSignInfo = "rest/app/patient/push/updatePatientVitalSignInfo"
let updatePatientInfarctArea = "rest/app/patient/push/updatePatientInfarctArea"

//Sprint 6
let updateInfractAreaDetailsFromCardio = "rest/app/patient/push/updatePatientInfarctAreaInfoFromCardiologist"
let getUndiagnoseCaseDetails = "rest/app/case/fetch/getUndiagnosedCaseDetails"

//Sprint 7
//We resued the existing services

//Sprint 8
let userLogout = "rest/all/app/logout"
let getTimeLine = "rest/app/case/fetch/getCaseDetails"
let getECGTabInfo = "rest/app/case/fetch/getEcgInfarctAreaDetails"
let getNotifications = "rest/app/notification/getNotificationDetails"
let readNotification = "/rest/app/notification/updateNotificationStatus"
let unreadCount = "/rest/app/notification/getNotificationCountByUserID"
let getCaseTimelines = "rest/app/case/fetch/getCaseTimeLines"

//Patient History
let getConditionsInfo = "rest/app/patient/fetch/getPatientConditionsAndMedications"
let getMedicalHistoryInfo = "rest/app/patient/fetch/getPatientMedicalHistory"
let getClinicalExaminationInfo = "rest/app/case/fetch/getClinicalExaminationDetails"
let setMedicalHistoryInfo = "rest/app/patient/push/updatePatientMedicalHistory"
let setClinicalExaminationInfo = "rest/app/case/push/updatePatientClinicalExaminationInfo"
//Sprint 9
let getNewAccessToken = "auth/public/accessToken"

//Sprint 12                                              
let cathLabReady = "rest/app/case/push/markAsCathLabReady"

let cancelTreatments = "rest/app/case/push/cancelTreatment"
