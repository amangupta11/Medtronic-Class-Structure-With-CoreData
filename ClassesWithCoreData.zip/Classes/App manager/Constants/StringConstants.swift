//  StringConstants.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
enum UserRoles: String {
    case GeneralPractitioner = "1"
    case CATHLABPractitioner = "2"
    case Cardiologist        = "3"
    case OnCallCardiologist  = "7"
    /*case HospitalAdmin = 4
    case MedtronicAdmin = 5
    case SuperAdmin = 6*/
}
struct StroryBoardViewConstants {
    static var bottomTabBarSBID = "BottomTabBarViewController"
    static var loginSBID = "LoginViewController"
    static var splashSBID = "SplashViewController"
    static var viewSummaryScreenSBID = "ViewSummaryScreen"
    static var internalTransferScreenSBID = "HubNurseInternalTransfer"
    static var spokeNurseTimelineScreenSBID  = "SpokeNurseTimelineScreen"
    static var hubNurseTimeLineScreenSBID  = "HubNurseTimelineScreen"
    static var generalInfoViewControllerScreenSBID  = "GeneralInfoViewController"
    static var ecgViewControllerSBID  = "ECGViewController"
    static var patientHistoryScreenSBID  = "PatientHistoryViewController"
    static var ecgPreviewScreenSBID  = "ECGPreviewScreen"
    static var patientBaseViewControllerSBID  = "PatientBaseViewController"
    static var EditCaseViewControllerSBID  = "EditCaseViewController"
    static var cardiologistDignoseViewControllerSBID = "CardilogistVC"
    static var cardiologistInfarctAreaControllerSBID = "CardiologistInfarctAreaController"
    static var TimelineViewControllerSBID  = "TimelineScreen"
    static var ECGHistoryControllerSBID = "ECGHistoryController"
    static var HomeViewControllerSBID =  "HomeViewController"
    static var StopTreatmentScreenSBID = "StopTreatmentScreen"
    static var OnCallCardiologistSBID = "OnCallCardioVC"
    static var MethodsSBID = "MethodsVC"
}
struct SegueIdentifierConstants {
    static var loginToPreviewSegueIdentifier = "HomeToPreviewScreen"
    static var previewToAddNewCaseSegueIdentifier = "PreviewToAddNewCaseSegue"
    static var EditCaseToViewSummarySegueIdentifier = "EditCaseToViewSummary"
    static var ViewSummaryToEditCaseSegueIdentifier = "ViewSummaryToEditCase"
    static var ViewSummaryToTransferSegueIdentifier = "ViewSummaryToTransfer"
    static var loginToHomeSegue = "LoginToHome"
    static var ViewSummaryToTreatmentSegueIdentifier = "ViewSummaryToTreatment"
    static var ViewSummaryToPatientHistorySegueIdentifier = "ViewSummaryToPatientHistory"
}
struct StroryBoardNameConstants {
    static var SBNameLogin = "Login"
    static var SBNameSplash = "Splash"
    static var SBNameECGCapture = "ECGCapture"
    static var SBTimeline = "Timeline"
    static var SBCreateCase = "CreateCase"
    static var SBCardiologist = "Cardiologist"
    static var SBECGHistory = "ECGHistory"
    static var SBMedicalHistory = "MedicalHistory"
}
struct Path {
    static let Documents = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] as String
    static let Tmp = NSTemporaryDirectory()
}
struct StringConstants {
    static var Username = "username"
    static var Password = "password"
    static var Passcode = "passcode"
    static var ChannelID = "channelID"
    static var AuthDetail = "authDetail"
    static var HospitalIDs = "hospitalIDs"
    static var HospitalCaseID   = "hospitalCaseID"
    static var UserType = "userType"
    static var UserID   = "userID"
    static var Message   = "message"
    static var SentTime   = "notificationSentTime"
    static var ReadStatus   = "readStatus"
    static var AuthenticatonToken = "authenticatonToken"
    static var ErrorTitle = "Attention"
    static var oAuthResponse = "oAuthResponse"
    static var AccessToken = "access_token"
    static var ExpiresIn = "expires_in"
    static var refreshToken = "refresh_token"
    static var UUID = "uuID"
    static var TokenType = "token_type"
    static var ecgAnimationImagesStringExtenstion = "ECG_"
    static var backImageTitle = "Back_Icon"
    static var  Age   =    "age"
    static var  CaseID     =   "caseID"
    static var  NotificationId     =   "notificationID"
    static var  Badge     =   "badge"
    static var  Apps     =   "aps"
    static var  AppState     =   "AppState"
    static var  CaseStatus   =    "caseStatus"
    static var  CountryCode   =    "countryCode"
    static var  FirstName   =    "firstName"
    static var  Gender   =    "gender"
    static var  LastName   =    "lastName"
    static var  MobileNumber   =    "mobileNumber"
    static var  PaymentID   =    "paymentID"
    static var  PaymentType   =    "paymentType"
    static var  SyncStatus   =    "syncStatus"
    static var  PatientID   =    "patientID"

    static var   FirstECGTime   = "firstEcgCaptureTime"
    static var   FmcDoorInTime  = "fmcDoorInTime"
    static var   FmcDoorOutTime = "fmcDoorOutTime"
    static var   HubDoorInTime  = "hubDoorInTime"
    static var   StemiTime      = "activateStemiTime"
    static var   publicKey = "publicKey"

    static  var CellIdentifier = "InfractAreaCell"
    static var CellIdentifierForOtherComments = "InfractAreaCellWithTextView"
    static var TextViewDefaultString = "Type here"
    static var InfractAreaNameKey = "InfractAreaName"
    static var StElevationNameKey = "STElevationName"
    static var OtherCommentsText = "OtherCommentsText"
    static var otherCommentsCellBGImageKey = "OtherCommentsCellBgImage"
    static var IsChecked = "IsChecked"
    static var isChecked = "isChecked"
    static let RemoteNotification = "RemoteNotification"
    
    static var ConfirmationTitle = "Confirmation"
    static var CancelTreatmentTime = "cancelTreatmentTime"
    
    static var Comment  = "comment"
    static var Location  = "location"
    static var Time  = "time"
    static var StoppedTime  = "timerStopTime"
    
    static var PatientMedications  = "patientMedications"
    static var MedicalHistoryConditions  = "medicalHistoryConditions"
    static var MedicineDose  = "medicineDose"
    static var MedicineKey  = "medicineKey"
    static var MedicineDescription = "medicineDescription"
    static var Medications = "medications"
    static var Conditions = "Conditions"
    static var SelectedDosage = "selectedDosage"

}
struct NetworkStringConstants {
    static var NetworkConnectionAlertTitle = "No Internet Connection"
    static var NetworkConnectionAlertMsg = "Your request could not be completed. Verify your data connection and try again."
    static var NoServerConnectAlertMsg = "Your request could not be completed."
    static var NoServerConnectAlertTitle = "Could not connect to the server."
    static var NetworkConnectionAttentionTitle = "Attention"
    static var NetworkConnectionSlowIntMsg = "Your network speed is low. Please check your network connection and try again."


}
struct ErrorDomain {
    static var APIError = "APIError"
    static var DBError = "MedtronicDBError"
}
struct AlertViewTitles {
    static var InvalidFieldTitle = "Alert"
    static var SuccessTitle = "Success"
}
struct AlertViewMessages {
    static var NoSpecialCharacters = "No Special Characters allowed"
    static var EnterMandatoryFields = "Please enter mandatory fields"
    static var NoSelectedImage = "Please select the ecg report"
}
struct AlertViewButtonTitle {
    static var NoButtonTitle = "NO"
    static var YesButtonTitle = "YES"
}
struct ButtonTitles {
    static var pickerViewCancelButtonTitle = "Cancel"
    static var pickerViewDoneButtonTitle = "Done"
    static var attemptsRemainingString = " Attempts Remaining"
    static var attemptRemainingString = " 1 Attempt Remaining"
    static var BackIcon = "Back_Icon"
}

struct ImageConstants {
    
    static var UndiagnosedStatusImage = "UndiagnosedStatusImage"
    static var StemiStatusImage = "StemiStatusImage"
    static var InTransitStatusImage = "InTransitStatusImage"
    static var CompletedStatusImage = "CompletedStatusImage"
    static var kDefaultECGImage = "defaultECGImage"
    static var kNotesShadowImage = "notesShadowImage"
    static var CancelledStatusImage = "cancelledStatusImage"
}

struct LoginStringConstants {
    static  var logInBackgroundImage = "loginBackgroundImage"
    static var InvalidInputAlertTitle = "Invalid Username or Password"
    static var InvalidInputAlertMsg   =  "The username or password you entered is incorrect. Please try again."
}
struct bundleConstants {
   static  var BundleVersion = "CFBundleVersion"

}
struct StatusConstants {
    static var Undiagnosed = "Un-diagnosed"
    static var STEMI = "STEMI"
    static var New = "New"
    static var InTransit = "In Transit"
    static var InternalTransfer = "Internal Transfer"
    static var CathLabAccepted = "Arrived at Cath Lab"
    static var DeviceCrossTime = "Device Cross Time"
    static var Completed = "Completed"
    static var CathLabExit = "Cath Lab Exit"
    static var NotAStemi = "Not a STEMI"
    static var Diagnosed = "Diagnosed"
    static var UnderObservation = "Under Observation"
    static var Cancelled = "Cancelled"
}

struct NotificationConstants {
    static var NoRecords = "NoRecords"
    static var AlreadyReviewed = "AlreadyReviewed"

    
}
struct stopTreatmentDictKey {
    static var others = "ISOTHERSELECTED"
    static var valueKey = "VALUE"
    static var selectedKey = "SELECTED"
}
