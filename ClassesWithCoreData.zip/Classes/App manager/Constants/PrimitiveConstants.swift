//
//  PrimitiveConstants.swift
//  Medtronic
//
//  Created by Aniket Kulkarni on 05/12/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation

enum MHImageTransferType: Int {
    case capture = 0
    case upload = 1
    case download = 2
}


struct MedicalHistoryConstants {
    static let kMAXIMUM_COUNT_MH_IMAGES_SUPPORTED = 4
}

struct ColorConstants {
    
    static let whiteColorNormal = UIColor.init(colorLiteralRed: 255, green: 255, blue: 255, alpha: 1)
    static let whiteColorFade = UIColor.init(colorLiteralRed: 255, green: 255, blue: 255, alpha: 0.4)

}


