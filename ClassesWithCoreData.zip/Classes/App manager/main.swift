//  main.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import Foundation
import UIKit

UIApplicationMain(Process.argc, Process.unsafeArgv,
                  NSStringFromClass(SessionManager),
                  NSStringFromClass(AppDelegate))
