//  FileUtility.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
let ecgFolderPath  = "/ECG/CASES"
let imageNamePath = "ECG_%@.jpeg"
let ecgPath  = "ECG/CASES"

class FileUtility: NSObject {
    //MARK: - File Operations
    class  func saveFileToPath(path: String!, file: NSData?) {
        if file!.writeToFile(path, atomically: true) {
             print("File saved successfully.")
        } else {
            // Error occured in saving file to given path
            print("Some error occured in saving file")
        }
    }

    class func createECGFolder() {
    let path = FileUtility.getDocumentsDirectoryPath()!.stringByAppendingString(ecgFolderPath)
    if !NSFileManager.defaultManager().fileExistsAtPath(path) {
    FileUtility.createDirectoryAtPath(ecgFolderPath, basePath: FileUtility.getDocumentsDirectoryPath()!)
    } else {
        print("Directory Already Exist.")
    }
    }
    class func moveFromPathToPath(fromPath: NSURL, toPath: String) {
        do {
            try NSFileManager.defaultManager().moveItemAtURL(fromPath, toURL: NSURL.fileURLWithPath(toPath))
        } catch {

            print(error)
        }


    }

    class func getECGFolder(caseID: String) -> String {
        let path = FileUtility.getDocumentsDirectoryPath()!.stringByAppendingString(ecgFolderPath + "/" + caseID)
        return path
    }

    class func getImageName() -> String {
        let imageName = String(format:imageNamePath, DateUtility.getCurrentShortTimeInGMT())
        return imageName
    }
    class  func deleteFileFromPath(path: String!) {
        let fileManager = NSFileManager.defaultManager()
        if NSFileManager.defaultManager().fileExistsAtPath(path) {
            do {
            try fileManager.removeItemAtPath(path)
        } catch let error as NSError {
            print(error.debugDescription)
        }
        } else {
            print("Directory Not Exist.")
        }
    }

    class func createCaseIDFolder(caseIDPath: String, caseID: String) {
        if !NSFileManager.defaultManager().fileExistsAtPath(caseIDPath) {
            FileUtility.createDirectoryAtPath(ecgFolderPath + "/" + caseID, basePath: FileUtility.getDocumentsDirectoryPath()!)
        } else {
            print("Directory Already Exist.")
        }
    }

    class func getDocumentsDirectoryPath() -> String? {
            let paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        guard let _ = paths.first else {
            return nil
        }
        return paths[0]
        }
    class func createDirectoryAtPath(directoryName: String, basePath: String) -> Bool {
            // creating directory at the specified path
        let manager = NSFileManager.defaultManager()
        do {
            try manager.createDirectoryAtPath(basePath.stringByAppendingString(directoryName), withIntermediateDirectories: true, attributes: nil)
                } catch let error as NSError {
            print(error)
            return false
        }
            return true
    }
    class func checkIfFileExists(path: String?) -> Bool {
        let fileManager = NSFileManager.defaultManager()
        var isDir: ObjCBool = false
        if fileManager.fileExistsAtPath(path!, isDirectory:&isDir) {
            if isDir {
                // file exists and is a directory
                return true
            } else {
                // file exists and is not a directory
                return true
            }
        } else {
            // file does not exist
            return false
        }
    }
    class  func getPlistPath() -> String? {
        let path = NSBundle.mainBundle().pathForResource("MEDMetaData", ofType: "plist")
        return path
    }
    class func removeCasesCache() {
        let fileManager = NSFileManager.defaultManager()
        let documentsUrl =  NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first! as NSURL
        let documentsPath = documentsUrl.path
        do {
            if let documentPath = documentsPath {
                let fileNames = try fileManager.contentsOfDirectoryAtPath("\(documentPath)")
                for fileName in fileNames {
                    if (fileName.hasPrefix("Cases")) {
                        let filePathName = "\(documentPath)/\(fileName)"
                        try fileManager.removeItemAtPath(filePathName)
                    }
                }
                //let files = try fileManager.contentsOfDirectoryAtPath("\(documentPath)")
                //print("all files in cache after deleting images: \(files)")
            }
        } catch {
            print("Could not clear folder: \(error)")
        }
    }
    class func removeCache() {
            let fileManager = NSFileManager.defaultManager()
        let documentsUrl =  NSFileManager.defaultManager().URLsForDirectory(.CachesDirectory, inDomains: .UserDomainMask).first! as NSURL
        let documentsPath = documentsUrl.path
        do {
            if let documentPath = documentsPath {
                let fileNames = try fileManager.contentsOfDirectoryAtPath("\(documentPath)")
                //                print("all files in cache: \(fileNames)")
                for fileName in fileNames {
                                    if (fileName.hasPrefix("Snapshots")) {
                        let filePathName = "\(documentPath)/\(fileName)"
                        try fileManager.removeItemAtPath(filePathName)
                    }
                }
                //                let files = try fileManager.contentsOfDirectoryAtPath("\(documentPath)")
                //                print("all files in cache after deleting images: \(files)")
            }
                } catch {
            print("Could not clear temp folder: \(error)")
        }
    }
}
