//  MEDDashboardCustomButton.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDDashboardCustomButton: UIButton {
    override var highlighted: Bool {
        didSet {
            if (highlighted) {
                self.backgroundColor = UIColor.init(red: 184.0/255.0, green: 217.0/255.0, blue: 235.0/255.0, alpha: 1.0)
            } else {
                self.backgroundColor = UIColor.init(red: 244/255, green: 244/255, blue: 244/255, alpha: 0.0)
            }
        }
    }
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
}
