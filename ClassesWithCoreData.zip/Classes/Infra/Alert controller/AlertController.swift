//  MEDAlertController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
 protocol AlertViewControllerProtocol {
   func OKButtonAction(alertController: UIAlertController)
   func cancelButtonAction(alertController: UIAlertController)
   func defaultButtonAction(alertController: UIAlertController)
}
class AlertController: UIViewController {
    var delegate: AlertViewControllerProtocol? = nil
    var customTextView: UITextView? = nil
    var customAlertTextViewController: UIAlertController? = nil
}
// MARK: - Custom Actions
extension AlertController {
    func showSimpleAlert(title: String, message: String, preferredStyle: UIAlertControllerStyle) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
        let defaultAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .Default) {
            UIAlertAction in
            self.delegate?.defaultButtonAction(alertController)
        }
        alertController.addAction(defaultAction)
        return alertController
    }
    func showCustomAlertWithTwoActions(title: String, message: String, okTitle: String, cancelTitle: String, prefereredStyle: UIAlertControllerStyle, tag: NSInteger) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        // Create the actions
        let cancelAction = UIAlertAction(title: cancelTitle, style: UIAlertActionStyle.Default) {
            UIAlertAction in
            self.delegate!.cancelButtonAction(alertController)
        }
        let OKAction = UIAlertAction(title: okTitle, style: UIAlertActionStyle.Cancel) {
            UIAlertAction in
            self.delegate!.OKButtonAction(alertController)
        }
        // Add the actions
        alertController.addAction(cancelAction)
        alertController.addAction(OKAction)
        alertController.view.tag = tag
        return alertController
    }

    func showAlertViewWithTextView(title: String, message: String, okTitle: String, cancelTitle: String, prefereredStyle: UIAlertControllerStyle, tag: NSInteger, target: AnyObject) -> UIAlertController {

        let alert=UIAlertController(title: title, message:"", preferredStyle: prefereredStyle)
        let height: NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutAttribute.Height, relatedBy: NSLayoutRelation.Equal, toItem: nil, attribute: NSLayoutAttribute.NotAnAttribute, multiplier: 1, constant: 205)
        alert.view.addConstraint(height)
        let width: NSLayoutConstraint = NSLayoutConstraint(item: alert.view, attribute: NSLayoutAttribute.Width, relatedBy: NSLayoutRelation.Equal, toItem: nil, attribute: NSLayoutAttribute.NotAnAttribute, multiplier: 1, constant: 270)
        alert.view.addConstraint(width)
             let rect = CGRect(x: 16.5, y: 54.5, width: 237, height: 82)
        customTextView = UITextView(frame: rect)

        customTextView!.font = UIFont(name: "Helvetica", size: 13)
        customTextView!.textColor = UIColor(red:136/255.0, green: 139/255.0, blue:141/255.0, alpha: 1)
        customTextView!.layer.borderColor=UIColor(red:77/255.0, green: 77/255.0, blue:77/255.0, alpha: 0.3).CGColor
        customTextView!.layer.borderWidth=1
        customTextView!.text="Please provide the reason for not being able to diagnose. e.g Atypical case capture ECG again and send, Capture vitals again etc."
        customTextView!.font = UIFont(name: "Effra", size: 13)
        customTextView?.textColor = ColorPicker.steelGreyColor()
        customTextView?.keyboardType = .ASCIICapable
        alert.view.addSubview(customTextView!)
        let firstLbl: UILabel = UILabel()
        firstLbl.frame = CGRect(x: 0, y: 163, width: 270, height: 0.5)
        firstLbl.backgroundColor=UIColor(red:77/255.0, green: 77/255.0, blue:77/255.0, alpha: 0.78)
        alert.view.addSubview(firstLbl)

        let secondLbl: UILabel = UILabel()
        secondLbl.frame = CGRect(x: 135, y: 163, width: 0.5, height: 43.5)
        secondLbl.backgroundColor=UIColor(red:77/255.0, green: 77/255.0, blue:77/255.0, alpha: 0.78)
        alert.view.addSubview(secondLbl)

        let cancelButton = UIButton()
        cancelButton.frame = CGRect(x: 5, y: 165, width: 120, height: 35)

        cancelButton.setTitle("Cancel", forState:  UIControlState.Normal)
        cancelButton.setTitleColor(UIColor(red:0/255.0, green: 118/255.0, blue:255/255.0, alpha: 0.78), forState: .Normal)
        cancelButton.addTarget(target, action:#selector(textViewCancelButtonTapped), forControlEvents: UIControlEvents.TouchUpInside)
        alert.view.addSubview(cancelButton)

        let okButton = UIButton()
        okButton.frame = CGRect(x: 140, y: 165, width: 120, height: 35)

        okButton.setTitle("OK", forState:  UIControlState.Normal)
        okButton.setTitleColor(UIColor(red:0/255.0, green: 118/255.0, blue:255/255.0, alpha: 0.78), forState: .Normal)
        okButton.addTarget(target, action: #selector(textViewOkButtonTapped), forControlEvents: UIControlEvents.TouchUpInside)
        alert.view.addSubview(okButton)
        return alert

    }
    func textViewCancelButtonTapped() {

    }
    func textViewOkButtonTapped() {
    }
   }
extension AlertViewControllerProtocol {
    func defaultButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func cancelAction(alertController: UIAlertController) {
    }
    func OKAction(alertController: UIAlertController) {
    }
}
