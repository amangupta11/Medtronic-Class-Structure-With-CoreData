//  DateUtility.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
//http://www.knowstack.com/swift-nsdateformatter/
class DateUtility: NSObject {
    class func convertGMTtoShortTime(timeInterval: NSTimeInterval) -> String // "HH:mm" 10:10
    {
        //TimeStamp
        //Convert to Date
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "h:mma"
        dateFormatter.timeZone = NSTimeZone()
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to Short String =  \(dateString)")
        return dateString
    }
    class func convertGMTto24HrFormatTime(timeInterval: NSTimeInterval) -> String // "HH:mm" 10:10
    {
        //TimeStamp
        //Convert to Date
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        dateFormatter.timeZone = NSTimeZone()
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to Short String =  \(dateString)")
        return dateString
    }
    class func convertGMTtoTime(timeInterval: NSTimeInterval) -> String // "HH:mm:a" 10:10am
    {
        //TimeStamp
        // let timeInterval  = 1471458141.00
        //Convert to Date
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "h:mma"
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to String =  \(dateString)")
        return dateString
    }
    class func convertGMTtoShortDate(timeInterval: NSTimeInterval) -> String // "dd-MMM-yyyy"20-Jul-2016
    {
        //TimeStamp
        // let timeInterval  = 1471458141.00
        //Convert to Date
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to Short Date string =  \(dateString)")
        return dateString
    }
    class func convertGMTtoLongDate(timeInterval: NSTimeInterval) -> String // "dd-MMM-yyyy HH:mm:a" //20-Jul-2016 10:10am
    {
        //TimeStamp
        //let timeInterval  = 1471458141.00
        //Convert to Date
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy h:mma"
//        dateFormatter.AMSymbol = "am"
//        dateFormatter.PMSymbol = "pm"
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to Long Date string =  \(dateString)")
        return dateString
    }
    class func getCurrentShortTimeInGMT() -> String {
        var date = NSDate()
        let dateFormatter = NSDateFormatter()
        let timeZone = NSTimeZone(name: "GMT")
        dateFormatter.timeZone = timeZone
        dateFormatter.dateFormat = "HH:mm:ss"
        let gmtTimeZoneStr = dateFormatter.stringFromDate(date)
        date = dateFormatter.dateFromString(gmtTimeZoneStr)!
        let seconds = date.timeIntervalSince1970
        print("GMT TimeZone Str is =  \(gmtTimeZoneStr)")
        print("Seconds Str is =  \(seconds)")
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to short  string =  \(dateString)")
        
        return dateString
    }

    class func getCurrentTimeInGMT() -> NSTimeInterval {
        var date = NSDate()
        let dateFormatter = NSDateFormatter()
        let timeZone = NSTimeZone(name: "GMT")
        dateFormatter.timeZone = timeZone
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
         let gmtTimeZoneStr = dateFormatter.stringFromDate(date)
         date = dateFormatter.dateFromString(gmtTimeZoneStr)!
         let seconds = date.timeIntervalSince1970
        print("GMT TimeZone Str is =  \(gmtTimeZoneStr)")
        print("Seconds Str is =  \(seconds)")

        return seconds
    }
    class  func convertStringToDate(dateString: String) -> NSTimeInterval {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy h:mma"//this your string date format
        //dateFormatter.locale = NSLocale(localeIdentifier: "en")
        let date = dateFormatter.dateFromString(dateString)
        let timeZone = NSTimeZone(name: "GMT")
        dateFormatter.timeZone = timeZone
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        let seconds = date!.timeIntervalSince1970
        print("String Date GMT TimeZone in Seconds =  \(seconds)")

        return seconds
    }

    class func toUTC(date: NSDate) -> NSDate {
        let formatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
        formatter.timeZone = NSTimeZone(abbreviation: "UTC")
        let dateStr = formatter.stringFromDate(date)
        return formatter.dateFromString(dateStr)!
    }

    class func timeAgo (toDate: NSDate = NSDate(), fromDate: NSDate) -> String {
        let kDays = "Days"
        let kHours = "Hours"
        let kMins = "Minutes"
        let kSecs = "Seconds"
        let secondsInMinute = 60
        let minuteInHour = 60
        let hourInDay = 24
        var ago: String = String()
        let fromDateUTC = toUTC(fromDate)
        let toDateUTC = toUTC(toDate)
        if(fromDateUTC.compare(toDateUTC) == .OrderedDescending) {
            return ago
        }
        let secsAgo = abs(Int(toDateUTC.timeIntervalSinceDate(fromDateUTC)))
        let daysAgo = secsAgo/(secondsInMinute*minuteInHour*hourInDay)
        let hoursAgo = secsAgo/(secondsInMinute*minuteInHour)
        let minsAgo = secsAgo/(secondsInMinute)
        if (daysAgo >= 1) {
            ago = String.localizedStringWithFormat(NSLocalizedString(kDays, comment: ""), daysAgo)
        } else if (hoursAgo >= 1) {
            ago = String.localizedStringWithFormat(NSLocalizedString(kHours, comment: ""), hoursAgo)
        } else if (minsAgo >= 1) {
            ago = String.localizedStringWithFormat(NSLocalizedString(kMins, comment: ""), minsAgo)
        } else {
            ago = String.localizedStringWithFormat(NSLocalizedString(kSecs, comment: ""), secsAgo)
        }
        return ago
    }

    class func timeAgo (toDate: NSDate = NSDate(), fromSeconds: NSTimeInterval) -> String {
        let formatter = NSDateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss ZZZ"
        let fromDate = NSDate.init(timeIntervalSince1970: fromSeconds)
        return timeAgo(fromDate: fromDate)
    }

}
