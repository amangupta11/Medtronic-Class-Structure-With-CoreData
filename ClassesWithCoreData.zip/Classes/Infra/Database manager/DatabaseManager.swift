//  DatabaseManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class DatabaseManager: NSObject {
}
