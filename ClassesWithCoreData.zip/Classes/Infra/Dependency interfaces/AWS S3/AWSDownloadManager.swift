//  AWSDownloadManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import AWSMobileAnalytics
import AWSCognito
import AWSS3
import AWSCore
import SwiftyJSON
import ReachabilitySwift
class AWSDownloadManager: NSObject {

    private var reachability: Reachability!
    private var actionForNetworkChange: () -> () = {

    }
    func actionForNetworkChangeFunc() {
        actionForNetworkChange()
    }

    class var sharedDownloadManager: AWSDownloadManager {
        struct Singleton {
            static let instance = AWSDownloadManager()
        }
        return Singleton.instance
    }

    func registerNetworkChangeNotification() {
        do {
            self.reachability =  try Reachability.reachabilityForInternetConnection()

            // Tell the reachability that we DON'T want to be reachable on 3G/EDGE/CDMA
            self.reachability!.reachableOnWWAN = false

            // Here we set up a NSNotification observer. The Reachability that caused the notification
            // is passed in the object parameter
            NSNotificationCenter.defaultCenter().addObserver(self,
                                                             selector: #selector(self.actionForNetworkChangeFunc),
                                                             name: ReachabilityChangedNotification,
                                                             object: nil)

            try self.reachability!.startNotifier()
        } catch {
            print("Error")
        }

    }
    
    func handleNetworkFailures(){
        unRegisterNotification()
        // Cancelling all the tasks
        AWSTransferManager.sharedTransferManager.cancelAllTask()
    }
    func unRegisterNotification() {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    let imageURL: NSURL? = nil
    func downloadImage(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {

      weak var patientInformation=patientInfo

        var completionHandler: AWSS3TransferUtilityDownloadCompletionHandlerBlock?
        if (CustomAWSCredentialProvider.sharedInstance.bucketName != nil) {
            registerNetworkChangeNotification()
            let s3BucketName: String = CustomAWSCredentialProvider.sharedInstance.bucketName
            let expression = AWSS3TransferUtilityDownloadExpression()
            let transferUtility = AWSS3TransferUtility.defaultS3TransferUtility()

            let progressBlock: AWSS3TransferUtilityProgressBlock?
            progressBlock = {(task, progress) in
                dispatch_async(dispatch_get_main_queue(), {
                    print("Download Progress: \(Float(progress.fractionCompleted))")
                    self.actionForNetworkChange = {
                        if self.reachability.isReachableViaWiFi() || self.reachability.isReachableViaWWAN() {
                            print("Service avalaible!!!")
                        } else {
                            completion(jsonString:nil, successful:false, error:nil, response: nil )
                            self.handleNetworkFailures()
                            print("No service avalaible!!!")
                            task.cancel()
                        }
                    }


                    ActivityIndicatorView.sharedActivityView.loadingLabel.text = String(format: "Loading...\(Float(progress.fractionCompleted))")
                })
            }
            expression.progressBlock = progressBlock
            completionHandler = { (task, location, data, error) -> Void in
                expression.progressBlock = progressBlock
                self.unRegisterNotification()

                dispatch_async(dispatch_get_main_queue(), {
                    if ((error) != nil) {
                        print("Failed with error")
                        print("Error: \(error!)")
                        ActivityIndicatorView.sharedActivityView.hideOverlayView()
                        completion(jsonString:nil, successful:false, error:error, response: nil )

                    } else {
                        //Set your image
                        let ecgFileName = imageURL.lastPathComponent
                        let caseID = patientInformation!.caseID
                        if caseID != nil {
                        let filePath = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), ecgFileName!)
                        patientInfo.ecgInfo?.localPath = filePath
                        FileUtility.deleteFileFromPath(filePath)
                        FileUtility.createCaseIDFolder(FileUtility.getECGFolder(caseID!), caseID: caseID!)
                        FileUtility.moveFromPathToPath(imageURL, toPath:filePath)
                        //Decrypt the File
                        CryptoUtility.decryptTheFile(filePath, key: (patientInformation?.caseKey)! as! String, patient: patientInformation!)
                        completion(jsonString:nil, successful:true, error:nil, response: task.response)
                        print("Download Success")
                        let date = NSDate()
                        print("Download Stop Date & Time : \(date)")
                        }

                    }
                })
            }
            transferUtility.downloadToURL(imageURL, bucket: s3BucketName, key: s3DownloadKeyName, expression: expression, completionHander: completionHandler).continueWithBlock { (task) -> AnyObject! in
                if let error = task.error {
                    print("Error: \(error.localizedDescription)")
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    completion(jsonString:nil, successful:false, error:error, response: nil )

                }
                if let exception = task.exception {
                    print("Exception: \(exception.description)")
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    completion(jsonString:nil, successful:false, error:nil, response: nil )
                }
                if let _ = task.result {
                    print("Download Starting!")
                    let date = NSDate()
                    print("Download Start Date & Time : \(date)")

                    self.actionForNetworkChange = {
                        if self.reachability.isReachableViaWiFi() || self.reachability.isReachableViaWWAN() {
                            print("Service avalaible!!!")
                        } else {
                            completion(jsonString:nil, successful:false, error:nil, response: nil )
                            (task.result as! AWSS3TransferUtilityTask).cancel()
                            self.handleNetworkFailures()
                            print("No service avalaible!!!")
                        }
                    }

                }
                return nil
            }
        } else {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
        }


    }
}
