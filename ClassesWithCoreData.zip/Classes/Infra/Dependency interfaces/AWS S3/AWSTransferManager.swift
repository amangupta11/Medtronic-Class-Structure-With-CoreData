//  AWSTransferManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import SwiftyJSON
import AWSS3
class AWSTransferManager: NSObject {

    // MARK: - Shared Instance
    class var sharedTransferManager: AWSTransferManager {
        struct Singleton {
            static let instance = AWSTransferManager()
        }
        return Singleton.instance
    }

    func uploadImageRequest(patientInfo: PatientInfo, imageURL: NSURL, s3UploadKeyName: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        
        AWSUploadManager.sharedUploadManager.uploadImage(patientInfo, imageURL: imageURL, s3UploadKeyName: s3UploadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
            if successful {
                completion(jsonString:nil, successful:true, error:nil, response: response )
            } else {
                print(jsonString)
                completion(jsonString:nil, successful:false, error:error, response: nil )
            }
            })
        })
    }

    func downloadImageRequest(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        AWSDownloadManager.sharedDownloadManager.downloadImage(patientInfo, imageURL: imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    completion(jsonString:nil, successful:true, error:error, response: nil )
                } else {
                    completion(jsonString:nil, successful:false, error:error, response: nil )
                }
            })
        })
    }
    
    
    func cancelAllTask() {
    
        AWSS3TransferUtility.defaultS3TransferUtility().getAllTasks().continueWithBlock({
            (task) in
            print("getUploadTasks ContinueBlock")
            if (task.result as? [AWSS3TransferUtilityTask]) != nil {
                for utilityTask  in (task.result as? [AWSS3TransferUtilityTask])!{
                    utilityTask.cancel()
                }
            }
            else
            {
                
            }
            return nil
        })
    }


}
