//  AWSUploadManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import AWSMobileAnalytics
import AWSCognito
import AWSS3
import AWSCore
import SwiftyJSON
import ReachabilitySwift

class AWSUploadManager: NSObject {
    class var sharedUploadManager: AWSUploadManager {
        struct Singleton {
            static let instance = AWSUploadManager()
        }
        return Singleton.instance
    }

    private var reachability: Reachability!
    private var actionForNetworkChange: () -> () = {

    }
    func actionForNetworkChangeFunc() {
        actionForNetworkChange()
    }


    func registerNetworkChangeNotification() {
        do {
            self.reachability =  try Reachability.reachabilityForInternetConnection()

            // Tell the reachability that we DON'T want to be reachable on 3G/EDGE/CDMA
            self.reachability!.reachableOnWWAN = false

            // Here we set up a NSNotification observer. The Reachability that caused the notification
            // is passed in the object parameter
            NSNotificationCenter.defaultCenter().addObserver(self,
                                                             selector: #selector(self.actionForNetworkChangeFunc),
                                                             name: ReachabilityChangedNotification,
                                                             object: nil)

            try self.reachability!.startNotifier()
        } catch {
            print("Error")
        }

    }
    func unRegisterNotification() {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    var uploadCompletionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
    func uploadImage(patientInfo: PatientInfo, imageURL: NSURL, s3UploadKeyName: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        registerNetworkChangeNotification()
        if (CustomAWSCredentialProvider.sharedInstance.bucketName != nil) {
            //defining bucket and upload file name
            let s3BucketName: String = CustomAWSCredentialProvider.sharedInstance.bucketName
            let expression = AWSS3TransferUtilityUploadExpression()
            let progressBlock: AWSS3TransferUtilityProgressBlock?

            progressBlock = {(task, progress) in
                dispatch_async(dispatch_get_main_queue(), {


                    self.actionForNetworkChange = {
                        if self.reachability.isReachableViaWiFi() || self.reachability.isReachableViaWWAN() {
                            print("Service avalaible!!!")
                        } else {
                            let newError = NSError(domain: ErrorDomain.APIError, code: -1004, userInfo: [NSLocalizedDescriptionKey: NetworkStringConstants.NoServerConnectAlertTitle, NSLocalizedFailureReasonErrorKey: NetworkStringConstants.NoServerConnectAlertTitle])

                            completion(jsonString:nil, successful:false, error:newError, response: nil )
                            self.unRegisterNotification()
                            print("No service avalaible!!!")
                            task.cancel()
                        }
                    }
                    print("Upload Progress: \(Float(progress.fractionCompleted))")
                    ActivityIndicatorView.sharedActivityView.loadingLabel.text = String(format: "Loading...\(Float(progress.fractionCompleted))")
                })
            }
            expression.progressBlock = progressBlock
            self.uploadCompletionHandler = { (task, error) -> Void in
                expression.progressBlock = progressBlock
                self.unRegisterNotification()

                dispatch_async(dispatch_get_main_queue(), {
                    if ((error) != nil) {
                        print("Failed with error")
                        print("Error: \(error!)")
                        ActivityIndicatorView.sharedActivityView.hideOverlayView()
                        completion(jsonString:nil, successful:false, error:error, response: nil )

                    } else {
                        let ecgImageURL     = (task.response?.URL?.relativeString)!.componentsSeparatedByString("?")
                        print(ecgImageURL[0])
                        patientInfo.ecgInfo?.ecgURL = ecgImageURL[0]
                        print("Upload Success")
                        let date = NSDate()
                        print("Upload Stop Date & Time : \(date)")

                        completion(jsonString:nil, successful:true, error:nil, response: task.response)
                    }
                })
            }

            let transferUtility = AWSS3TransferUtility.defaultS3TransferUtility()
            transferUtility.uploadFile(imageURL, bucket: s3BucketName, key: s3UploadKeyName, contentType: "image/jpeg", expression: expression, completionHander: uploadCompletionHandler).continueWithBlock { (task) -> AnyObject! in


                if let error = task.error {
                    print("Error: \(error.localizedDescription)")
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    completion(jsonString:nil, successful:false, error:error, response:nil)
                }
                if let exception = task.exception {
                    print("Exception: \(exception.description)")
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    completion(jsonString:nil, successful:false, error:nil, response:nil)
                }
                if let _ = task.result {
                    self.actionForNetworkChange = {
                        if self.reachability.isReachableViaWiFi() || self.reachability.isReachableViaWWAN() {
                            print("Service avalaible!!!")
                        } else {
                           let newError = NSError(domain: ErrorDomain.APIError, code: -1004, userInfo: [NSLocalizedDescriptionKey: NetworkStringConstants.NoServerConnectAlertTitle, NSLocalizedFailureReasonErrorKey: NetworkStringConstants.NoServerConnectAlertTitle])
                            completion(jsonString:nil, successful:false, error:newError, response: nil )
                            (task.result as! AWSS3TransferUtilityTask).cancel()
                            self.unRegisterNotification()
                            print("No service avalaible!!!")
                        }
                    }
                    print("request: \(task.result?.request)")
                    print("Upload Starting!")
                    let date = NSDate()
                    print("Upload Start Date & Time : \(date)")
                }
                return nil
            }
        } else {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
        }
    }
}
