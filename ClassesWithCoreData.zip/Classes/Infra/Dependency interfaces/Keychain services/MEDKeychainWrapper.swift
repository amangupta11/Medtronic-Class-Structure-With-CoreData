//  MEDKeychainWrapper.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDKeychainWrapper {
    class func setValueInKeychain(key: String, value: String) -> Bool {
//        let saveSuccessful: Bool = KeychainWrapper.setString(value, forKey: key)
        let saveSuccessful: Bool = KeychainWrapper.defaultKeychainWrapper().setString(value, forKey: key)
        
        return saveSuccessful
    }
    class func retrieveFromKeychain(key: String) -> String? {
       //let retrievedString: String? = KeychainWrapper.stringForKey(key)
        let retrievedString: String? = KeychainWrapper.defaultKeychainWrapper().stringForKey(key)
        return retrievedString
    }
    class func removeFromKeychain(key: String) -> Bool {
//       let removeSuccessful: Bool = KeychainWrapper.removeObjectForKey(key)
       let removeSuccessful: Bool = KeychainWrapper.defaultKeychainWrapper().removeObjectForKey(key)
        return removeSuccessful
    }
}
