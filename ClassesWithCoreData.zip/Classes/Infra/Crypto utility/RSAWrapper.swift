//  MEDRSAWrapper.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
private let kAsymmetricCryptoManagerApplicationTag = "com.AsymmetricCrypto.keypir"
private let kAsymmetricCryptoManagerKeyType = kSecAttrKeyTypeRSA
private let kAsymmetricCryptoManagerKeySize = 2048
private let kAsymmetricCryptoManagerCypheredBufferSize = 1024
// private key parameters
let privateKeyParams: [String: AnyObject] = [
    kSecAttrIsPermanent as String: true,
    kSecAttrApplicationTag as String: kAsymmetricCryptoManagerApplicationTag
]

// private key parameters
let publicKeyParams: [String: AnyObject] = [
    kSecAttrIsPermanent as String: true,
    kSecAttrApplicationTag as String: kAsymmetricCryptoManagerApplicationTag
]

// global parameters for our key generation
let parameters: [String: AnyObject] = [
    kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
    kSecAttrKeySizeInBits as String: 1024,
    kSecPublicKeyAttrs as String: publicKeyParams,
    kSecPrivateKeyAttrs as String: privateKeyParams,
]
enum AsymmetricCryptoException: ErrorType {
    case UnknownError
    case DuplicateFoundWhileTryingToCreateKey
    case KeyNotFound
    case AuthFailed
    case UnableToAddPublicKeyToKeyChain
    case WrongInputDataFormat
    case UnableToEncrypt
    case UnableToDecrypt
    case UnableToSignData
    case UnableToVerifySignedData
    case UnableToPerformHashOfData
    case UnableToGenerateAccessControlWithGivenSecurity
    case OutOfMemory
}

class RSAWrapper {

    //Generation of RSA private and public keys
    class func createSecureKeyPair(completion: ((success: Bool, error: AsymmetricCryptoException?) -> Void)? = nil) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in
            var pubKey, privKey: SecKeyRef?
            let status = SecKeyGeneratePair(parameters, &pubKey, &privKey)
            if status == errSecSuccess {
                dispatch_async(dispatch_get_main_queue(), { completion?(success: true, error: nil)
                    }
                )
            } else {
                var error = AsymmetricCryptoException.UnknownError
                switch (status) {
                case errSecDuplicateItem: error = .DuplicateFoundWhileTryingToCreateKey
                case errSecItemNotFound: error = .KeyNotFound
                case errSecAuthFailed: error = .AuthFailed
                default: break
                }
                dispatch_async(dispatch_get_main_queue(), { completion?(success: false, error: error) })
            }
        }
    }
    // Fetching string from key
    class func getPublicKey() -> String {
        var dataPtr: AnyObject?
        let query: [NSString:AnyObject] = [
            kSecClass: kSecClassKey,
            kSecAttrApplicationTag: kAsymmetricCryptoManagerApplicationTag.dataUsingEncoding(NSUTF8StringEncoding)!,
            kSecReturnData: true
        ]
        let qResult = SecItemCopyMatching(query, &dataPtr)
        var base64Encoded: String? = nil
        if (qResult == errSecSuccess) {
            let PublicKeyText = dataPtr as? NSData
            base64Encoded = PublicKeyText!.base64EncodedStringWithOptions(NSDataBase64EncodingOptions(rawValue: 0))

            print("PublicKeyText \(base64Encoded)")
        }
        return base64Encoded!
    }
    // Getting private key reference
    class func getPrivateKeyReference() -> SecKeyRef? {
        let parameters = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate,
            kSecAttrApplicationTag as String: kAsymmetricCryptoManagerApplicationTag,
            kSecReturnRef as String: true,
            ]
        var ref: AnyObject?
        let status = SecItemCopyMatching(parameters, &ref)
        if status == errSecSuccess { return ref as! SecKeyRef? } else { return nil }
    }
    // Getting public key reference
    class func getPublicKeyReference() -> SecKeyRef? {
        let parameters = [
            kSecClass as String: kSecClassKey,
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrApplicationTag as String: kAsymmetricCryptoManagerApplicationTag,
            kSecAttrKeyClass as String: kSecAttrKeyClassPublic,
            kSecReturnRef as String: true,
            ]
        var ref: AnyObject?
        let status = SecItemCopyMatching(parameters, &ref)
        if status == errSecSuccess { return ref as! SecKeyRef? } else {
            return nil
        }
    }
    // Deleting the existing secure public - private key pairs
    class func deleteSecureKeyPair() {
        // private query dictionary
        let deleteQuery = [
            kSecClass as String: kSecClassKey,
            kSecAttrApplicationTag as String: kAsymmetricCryptoManagerApplicationTag,
            ]
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in
            let status = SecItemDelete(deleteQuery) // delete private key
            dispatch_async(dispatch_get_main_queue(), {
            })
        }
    }

    //Encrypt a string with the public key
    class func encryptString(message: String, completion: (success: Bool, encryptedString: String?, error: AsymmetricCryptoException?) -> Void) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in

            if let publicKeyRef = self.getPublicKeyReference() {
                // prepare input input plain text
                guard let messageData = message.dataUsingEncoding(NSUTF8StringEncoding) else {
                    completion(success: false, encryptedString: nil, error: .WrongInputDataFormat)
                    return
                }
                let plainText = UnsafePointer<UInt8>(messageData.bytes)
                let plainTextLen = messageData.length

                // prepare output data buffer
                guard let cipherData = NSMutableData(length: SecKeyGetBlockSize(publicKeyRef)) else {
                    completion(success: false, encryptedString: nil, error: .OutOfMemory)
                    return
                }
                let cipherText = UnsafeMutablePointer<UInt8>(cipherData.mutableBytes)
                var cipherTextLen = cipherData.length

                let status = SecKeyEncrypt(publicKeyRef, .PKCS1, plainText, plainTextLen, cipherText, &cipherTextLen)

                // analyze results and call the completion in main thread
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    let encryptedStr = String(data: cipherData, encoding: NSUTF8StringEncoding)
                    completion(success: status == errSecSuccess, encryptedString: encryptedStr, error: status == errSecSuccess ? nil : .UnableToEncrypt)
                    cipherText.destroy()
                })
                return
            } else { dispatch_async(dispatch_get_main_queue(), { completion(success: false, encryptedString: nil, error: .KeyNotFound) }) }
        }
    }

    //Decrypt the entrypted string with the private key
   class func decryptData(encryptedData: NSData, completion: (success: Bool, result: String?, error: AsymmetricCryptoException?) -> Void) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { () -> Void in

            if let privateKeyRef = self.getPrivateKeyReference() {
                // prepare input input plain text
                let encryptedText = UnsafePointer<UInt8>(encryptedData.bytes)
                let encryptedTextLen = encryptedData.length

                // prepare output data buffer
                guard let plainData = NSMutableData(length: kAsymmetricCryptoManagerCypheredBufferSize) else {
                    completion(success: false, result: nil, error: .OutOfMemory)
                    return
                }
                let plainText = UnsafeMutablePointer<UInt8>(plainData.mutableBytes)
                var plainTextLen = plainData.length

                let status = SecKeyDecrypt(privateKeyRef, .PKCS1, encryptedText, encryptedTextLen, plainText, &plainTextLen)

                // analyze results and call the completion in main thread
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    if status == errSecSuccess {
                        // adjust NSData length
                        plainData.length = plainTextLen
                        // Generate and return result string
                        if let string = NSString(data: plainData, encoding: NSUTF8StringEncoding) as? String {
                            completion(success: true, result: string, error: nil)
                        } else { completion(success: false, result: nil, error: .UnableToDecrypt) }
                    } else { completion(success: false, result: nil, error: .UnableToDecrypt) }
                    plainText.destroy()
                })
                return
            } else { dispatch_async(dispatch_get_main_queue(), { completion(success: false, result: nil, error: .KeyNotFound) }) }
        }
    }


//    class func getnerateKeyPair() -> Bool {
//        //Generation of RSA private and public keys
//        let parameters: [String: AnyObject] = [
//            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
//            kSecAttrKeySizeInBits as String: 256
//        ]
//        var publicKey, privateKey: SecKeyRef?
//        var status: OSStatus!
//        status =  SecKeyGeneratePair(parameters, &publicKey, &privateKey)
//        if status != noErr {
//            print("Keys Generated")
//            //            MEDKeychainWrapper.setk
//            //            MEDKeychainWrapper.setValueInKeychain("PriKey", value:privateKey! as! String)
//            return true
//        }
//        return false
//
//    }
//
//    //Encrypt a string with the public key
//    class func encryptTheString(message: String) -> String {
//        let publicKey =  MEDKeychainWrapper.retrieveFromKeychain("PubKey")
//        let blockSize = SecKeyGetBlockSize(publicKey as! SecKey)
//        var messageEncrypted = [UInt8](count: blockSize, repeatedValue: 0)
//        var messageEncryptedSize = blockSize
//
//        var status: OSStatus!
//
//        status = SecKeyEncrypt(publicKey as! SecKey, SecPadding.PKCS1, message, message.characters.count, &messageEncrypted, &messageEncryptedSize)
//
//        if status != noErr {
//            print("Encryption Error!")
//            return messageEncrypted as! String
//        }
//        return ""
//    }
//
//    //Decrypt the entrypted string with the private key
//    class func decryptTheString(message: String) -> String {
//        let publicKey =  MEDKeychainWrapper.retrieveFromKeychain("PubKey")
//        let privateKey =  MEDKeychainWrapper.retrieveFromKeychain("PriKey")
//
//        let blockSize = SecKeyGetBlockSize(publicKey as! SecKey)
//        let messageEncryptedSize = blockSize
//        var messageEncrypted = [UInt8](count: blockSize, repeatedValue: 0)
//        var messageDecrypted = [UInt8](count: blockSize, repeatedValue: 0)
//        var messageDecryptedSize = messageEncryptedSize
//
//        var status: OSStatus!
//
//        status = SecKeyDecrypt(privateKey as! SecKey, SecPadding.PKCS1, &messageEncrypted, messageEncryptedSize, &messageDecrypted, &messageDecryptedSize)
//
//        if status != noErr {
//            print("Decryption Error!")
//            return ""
//        }
//
//        print(NSString(bytes: &messageDecrypted, length: messageDecryptedSize, encoding: NSUTF8StringEncoding)!)
//        return messageDecrypted as! String
//    }
//
//
//

}
