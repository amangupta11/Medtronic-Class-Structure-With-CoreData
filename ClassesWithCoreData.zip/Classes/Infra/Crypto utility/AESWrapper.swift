//  MEDAESWrapper.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// This is 128 bit

class AESWrapper {

    class func encryptTheData(data: NSData, key: String) -> NSData {
        let keyString        = key
        let keyData: NSData! = (keyString as NSString).dataUsingEncoding(NSUTF8StringEncoding) as NSData!
        let keyBytes         = UnsafeMutablePointer<Void>(keyData.bytes)
//        print("keyLength   = \(keyData.length), keyData   = \(keyData)")
        let dataLength    = size_t(data.length)
        let dataBytes     = UnsafeMutablePointer<Void>(data.bytes)
//        print("dataLength  = \(dataLength), data      = \(data)")
        let cryptData    = NSMutableData(length: Int(dataLength) + kCCBlockSizeAES128)
        let cryptPointer = UnsafeMutablePointer<Void>(cryptData!.mutableBytes)
        let cryptLength  = size_t(cryptData!.length)
        let keyLength              = size_t(kCCKeySizeAES128)
        let algoritm: CCAlgorithm = UInt32(kCCAlgorithmAES128)
        let options: CCOptions   = UInt32(kCCOptionPKCS7Padding + kCCOptionECBMode)
        let operation: CCOperation = UInt32(kCCEncrypt)
        var numBytesEncrypted: size_t = 0
        let cryptStatus = CCCrypt(operation,
                                  algoritm,
                                  options,
                                  keyBytes, keyLength,
                                  nil,
                                  dataBytes, dataLength,
                                  cryptPointer, cryptLength,
                                  &numBytesEncrypted)

        if UInt32(cryptStatus) == UInt32(kCCSuccess) {
            cryptData!.length = Int(numBytesEncrypted)
            //print("cryptLength = \(numBytesEncrypted), cryptData = \(cryptData)")
            return  cryptData!
        } else {
            print("Error: \(cryptStatus)")
        }
        return data
    }

    class func decryptTheData(data: NSData, key: String) -> NSData //data = cryptData
    {
        let keyString        = key
        let keyData: NSData! = (keyString as NSString).dataUsingEncoding(NSUTF8StringEncoding) as NSData!
        let keyBytes         = UnsafeMutablePointer<Void>(keyData.bytes)
//        print("keyLength   = \(keyData.length), keyData   = \(keyData)")
        let dataLength    = size_t(data.length)
        let dataBytes     = UnsafeMutablePointer<Void>(data.bytes)
//        print("dataLength  = \(dataLength), data      = \(data)")
        let cryptData    = NSMutableData(length: Int(dataLength) + kCCBlockSizeAES128)
        let cryptPointer = UnsafeMutablePointer<Void>(cryptData!.mutableBytes)
        let cryptLength  = size_t(cryptData!.length)
        let keyLength              = size_t(kCCKeySizeAES128)
        let operation: CCOperation = UInt32(kCCDecrypt)
        let algoritm: CCAlgorithm = UInt32(kCCAlgorithmAES128)
        let options: CCOptions   = UInt32(kCCOptionPKCS7Padding + kCCOptionECBMode)
        var numBytesEncrypted: size_t = 0
        let cryptStatus = CCCrypt(operation,
                                  algoritm,
                                  options,
                                  keyBytes, keyLength,
                                  nil,
                                  dataBytes, dataLength,
                                  cryptPointer, cryptLength,
                                  &numBytesEncrypted)

        if UInt32(cryptStatus) == UInt32(kCCSuccess) {
            cryptData!.length = Int(numBytesEncrypted)
//            print("DecryptcryptLength = \(numBytesEncrypted), Decrypt = \(cryptData)")
          return cryptData!
        } else {
            print("Error: \(cryptStatus)")
        }
        return data

    }

    class func encryptTheText(string: String, key: String) -> String {
        let keyString        = key
        let keyData: NSData! = (keyString as NSString).dataUsingEncoding(NSUTF8StringEncoding) as NSData!
        let keyBytes         = UnsafeMutablePointer<Void>(keyData.bytes)
//        print("keyLength   = \(keyData.length), keyData   = \(keyData)")
        let message       = string
        let data: NSData! = (message as NSString).dataUsingEncoding(NSUTF8StringEncoding) as NSData!
        let dataLength    = size_t(data.length)
        let dataBytes     = UnsafeMutablePointer<Void>(data.bytes)
//        print("dataLength  = \(dataLength), data      = \(data)")
        let cryptData    = NSMutableData(length: Int(dataLength) + kCCBlockSizeAES128)
        let cryptPointer = UnsafeMutablePointer<Void>(cryptData!.mutableBytes)
        let cryptLength  = size_t(cryptData!.length)
        let keyLength              = size_t(kCCKeySizeAES128)
        let algoritm: CCAlgorithm = UInt32(kCCAlgorithmAES128)
        let options: CCOptions   = UInt32(kCCOptionPKCS7Padding + kCCOptionECBMode)
        let operation: CCOperation = UInt32(kCCEncrypt)
        var numBytesEncrypted: size_t = 0
        let cryptStatus = CCCrypt(operation,
                                  algoritm,
                                  options,
                                  keyBytes, keyLength,
                                  nil,
                                  dataBytes, dataLength,
                                  cryptPointer, cryptLength,
                                  &numBytesEncrypted)

        if UInt32(cryptStatus) == UInt32(kCCSuccess) {
            cryptData!.length = Int(numBytesEncrypted)
//            print("cryptLength = \(numBytesEncrypted), cryptData = \(cryptData)")
            // Not all data is a UTF-8 string so Base64 is used
            //let base64cryptString = cryptData!.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
//            print( "Encrypted String = \(NSString(data: cryptData!, encoding: NSUTF8StringEncoding))")
            let string = String(data: cryptData!, encoding: NSASCIIStringEncoding)
            return  string!

        } else {
            print("Error: \(cryptStatus)")
        }
        return ""
    }

    class func decryptTheText(string: String, key: String) -> String //data = cryptData
    {
        let data = NSData(base64EncodedString: string, options: NSDataBase64DecodingOptions(rawValue: 0))
        let keyString        = key
        let keyData: NSData! = (keyString as NSString).dataUsingEncoding(NSUTF8StringEncoding) as NSData!
        let keyBytes         = UnsafeMutablePointer<Void>(keyData.bytes)
//        print("keyLength   = \(keyData.length), keyData   = \(keyData)")
        let dataLength    = size_t(data!.length)
        let dataBytes     = UnsafeMutablePointer<Void>(data!.bytes)
//        print("dataLength  = \(dataLength), data      = \(data)")
        let cryptData    = NSMutableData(length: Int(dataLength) + kCCBlockSizeAES128)
        let cryptPointer = UnsafeMutablePointer<Void>(cryptData!.mutableBytes)
        let cryptLength  = size_t(cryptData!.length)
        let keyLength              = size_t(kCCKeySizeAES128)
        let operation: CCOperation = UInt32(kCCDecrypt)
        let algoritm: CCAlgorithm = UInt32(kCCAlgorithmAES128)
        let options: CCOptions   = UInt32(kCCOptionPKCS7Padding + kCCOptionECBMode)
        var numBytesEncrypted: size_t = 0
        let cryptStatus = CCCrypt(operation,
                                  algoritm,
                                  options,
                                  keyBytes, keyLength,
                                  nil,
                                  dataBytes, dataLength,
                                  cryptPointer, cryptLength,
                                  &numBytesEncrypted)

        if UInt32(cryptStatus) == UInt32(kCCSuccess) {
            //  let x: UInt = numBytesEncrypted
            cryptData!.length = Int(numBytesEncrypted)
//            print("DecryptcryptLength = \(numBytesEncrypted), Decrypt = \(cryptData)")
            // Not all data is a UTF-8 string so Base64 is used
//            let base64cryptString = cryptData!.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
//            print("Base64DecryptString = \(base64cryptString)")
//            print( "Decrypted String  = \(NSString(data: cryptData!, encoding: NSUTF8StringEncoding))")
            let string = String(data: cryptData!, encoding: NSUTF8StringEncoding)
            if string != nil {
            return string!
            } else {
            return ""
            }

        } else {
            print("Error: \(cryptStatus)")
        }
        return ""

    }



}
