//  PushNotificationManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import AirshipKit
import UIKit

class NotificationManager: NSObject, RKDropdownAlertDelegate,UAPushNotificationDelegate {
    
    /* Configures Urban Airship and push notification
     Its gets called on login and on launch of app.
     */
    func register() {
        UAirship.takeOff()
        UAirship.setLogLevel(.Error)
        if let push = UAirship.push()
        {
            push.userPushNotificationsEnabled = true
            push.pushNotificationDelegate = self
        }
        clear()
    }
    
    func restart() {
        if let push = UAirship.push()
        {
            if !push.pushTokenRegistrationEnabled
            {
                push.userPushNotificationsEnabled = true
                push.pushTokenRegistrationEnabled = true
                push.updateRegistration()
            }
        }
    }
    
    func stop() {
        if let push = UAirship.push()
        {
            push.userPushNotificationsEnabled = false
            push.pushTokenRegistrationEnabled = false
            push.updateRegistration()
        }
        clear()
    }
    
    func clear() {
        if let push = UAirship.push()
        {
            push.resetBadge()
        }
        UIApplication.sharedApplication().applicationIconBadgeNumber = 1
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
    }
    
    class func chanelId() -> String {
        if let push = UAirship.push()
        {
            if let chanel = push.channelID
            {
                return chanel
            }
        }
        return String()
    }
    
    func launchedFromNotification(notification: [NSObject : AnyObject]) {
        if isNotificationEnabled(){
        handleNotification(notification)
        }
    }
    
    func receivedForegroundNotification(notification: [NSObject : AnyObject]) {
        if isNotificationEnabled(){
        let parsedNotification = handleNotification(notification)
        showLocalNotification(parsedNotification)
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.refreshScreen = true
        }
    }
    func receivedBackgroundNotification(notification: [NSObject : AnyObject]) {
        if isNotificationEnabled(){
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.refreshScreen = true
        }
    }
    func isNotificationEnabled() -> Bool
    {
        let currentNotification = UIApplication.sharedApplication().currentUserNotificationSettings()
        if currentNotification?.types == UIUserNotificationType.None
        {
            return false
        }
        return true
    }
    private func handleNotification(notif: [NSObject : AnyObject]) -> Notification
    {
        clear()
        let notification = NotificationManager.parse(notif)
        notifyViews(notification)
        return notification
    }
    
    private func notifyViews (notification: Notification) {
        NSNotificationCenter.defaultCenter().postNotificationName(
            StringConstants.RemoteNotification, object: notification)
    }
    
    private class func parse(notification: [NSObject : AnyObject]) -> Notification {
        let parsedNotification = Notification(notificationId: String(), caseID: String(),hospitalCaseID: String(), message: String(), sentTime:0, isRead: false)
        if let notificationId = notification[StringConstants.NotificationId]
        {
            parsedNotification.notificationId = notificationId as! String
        }
        if let caseID = notification[StringConstants.CaseID]
        {
            parsedNotification.caseID = caseID as! String
        }
        if let message = notification[StringConstants.Message]
        {
            parsedNotification.message = message as! String
        }
        if let hospitalCaseId = notification[StringConstants.HospitalCaseID]
        {
            parsedNotification.hospitalCaseID = hospitalCaseId as! String
        }
        if let apps = notification[StringConstants.Apps]
        {
            if let badge = apps[StringConstants.Badge]
            {
                parsedNotification.badge = badge as! Int
            }
        }
        return parsedNotification
    }
    
    
    
    // MARK: Local notification delegates
    
    func dropdownAlertWasTapped(alert: RKDropdownAlert!) -> Bool {
        dismissLocalNotification()
        return true
    }
    
    func dropdownAlertWasDismissed() -> Bool {
        return true
    }
    
    private func showLocalNotification(notif: Notification) {
        let bgColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.7)
        RKDropdownAlert.title(notif.hospitalCaseID, message: notif.message, backgroundColor: bgColor, textColor: UIColor.whiteColor(), time: 3, delegate: self)
    }
    
    private func dismissLocalNotification () {
        RKDropdownAlert.dismissAllAlert()
    }
    
    
}
