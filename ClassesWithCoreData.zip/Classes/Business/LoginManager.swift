//  LoginManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import SwiftyJSON
class LoginManager: NSObject {
    class func manageLoggedInUserData(jsonString: JSON, dictionary: NSDictionary, response: NSHTTPURLResponse?) {
        
        // 1. Hash password
        let password  =  dictionary[StringConstants.Password] as! String
        let username = dictionary[StringConstants.Username] as! String
        let hashedPassword = CryptoUtility.performHashing((password.dataUsingEncoding(NSUTF8StringEncoding))!)
        var options = Dictionary<NSObject, AnyObject>()
        options[StringConstants.Username] = username
        options[StringConstants.UserID] = jsonString[UserInfoKey.UserID.rawValue].stringValue
        let dataofHashedPassword = (hashedPassword.dataUsingEncoding(NSUTF8StringEncoding))
        let base64cryptString = dataofHashedPassword!.base64EncodedStringWithOptions([])
        
        options[StringConstants.Password] = base64cryptString
        
        dispatch_sync(dispatch_get_main_queue(), {
            self.setLoggedInValue (options)
        })
            
        
        
        // 2. Keep password in keychain using the key username
        MEDKeychainWrapper.setValueInKeychain(username, value: password)
        // 3. Insert the user profile
        insertUserProfile(jsonString)
        var dictionary: [String:AnyObject] = [:]
        dictionary[UserInfoKey.UserName.rawValue] = username
        dictionary[UserInfoKey.UserID.rawValue] = jsonString[UserInfoKey.UserID.rawValue].stringValue
        let updatedJson = JSON(dictionary)
        updateUserName(updatedJson)
        let accessToken  = jsonString[StringConstants.oAuthResponse][StringConstants.AccessToken].stringValue
        var tokenType  = jsonString[StringConstants.oAuthResponse][StringConstants.TokenType].stringValue
        tokenType = tokenType.stringByAppendingString(" \(accessToken)")
        let refreshToken = jsonString[StringConstants.oAuthResponse][StringConstants.refreshToken].stringValue
        let expiresIn = jsonString[StringConstants.oAuthResponse][StringConstants.ExpiresIn].stringValue
        let uuid = jsonString[StringConstants.UUID].stringValue
        let user = LoginManager.getLoggedInUser()
        if(user != nil) {
            UserInfo.updateToken(user!, token: tokenType)
            UserInfo.udpateRefreshToken(user!, refreshToken: refreshToken)
            UserInfo.updateAccessTokenExpiryTime(user!, expiryTime: expiresIn)
            UserInfo.udpateUUID(user!, UUID: uuid)
        }
        dispatch_async(dispatch_get_main_queue(), {
            let sessionManager = UIApplication.sharedApplication() as! SessionManager
            sessionManager.resetIdleTimer()
        })
    }
    class func insertUserProfile(json: JSON) {
        UserInfo.insertUserProfile(json)
    }
    class func updateUserProfile(json: JSON) {
         UserInfo.updateUserProfile(json)
    }
    class func updateUserName(json: JSON) {
          UserInfo.updateUserName(json)
    }
    class func getDataFromKeychain(dictionary: NSDictionary) -> String?{
        let username = dictionary[StringConstants.Username] as!String
        return MEDKeychainWrapper.retrieveFromKeychain(username)
    }
    class func storeDataInKeychain(dictionary: NSDictionary) {
        let password = dictionary[StringConstants.Password] as! String
        let username = dictionary[StringConstants.Username] as! String
        let lowercaseUsername = username.lowercaseString
        MEDKeychainWrapper.setValueInKeychain(lowercaseUsername, value: password)
    }
    class func wipeKeychainData(dictionary: NSDictionary) {
        let username = dictionary[StringConstants.Username] as!String
        NSUserDefaults.standardUserDefaults().setObject("", forKey: StringConstants.Username)
        NSUserDefaults.standardUserDefaults().setObject("", forKey: StringConstants.UserID)
        NSUserDefaults.standardUserDefaults().synchronize()
        MEDKeychainWrapper.removeFromKeychain(username)
    }
    class func userExist(username: String) -> UserInfo? {
            let user: UserInfo? = UserInfo.getUserForUsername(username)
        if user == nil {
            return nil
        } else {
            return user
        }
    }
    class func setLoggedInValue(dictionary: NSDictionary) {
        let username = dictionary[StringConstants.Username] as!String
        let userID = dictionary[StringConstants.UserID] as!String
        MEDKeychainWrapper.setValueInKeychain(StringConstants.Username, value: username)
        MEDKeychainWrapper.setValueInKeychain(StringConstants.UserID, value: userID)
        }
    class func getUserDefault(keyToReturnValue: String) -> AnyObject? {
            return MEDKeychainWrapper.retrieveFromKeychain(keyToReturnValue)
    }
    class func getLoggedInUser() -> UserInfo? {
        var tempUser :UserInfo? = nil
//        dispatch_sync(dispatch_get_main_queue(), {
            let userID = LoginManager.getUserDefault(StringConstants.UserID) as! String
            let user = UserInfo.getUserForUserId(userID)
            tempUser = user
//       })
        return tempUser
    }
}
