//  PatientManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import SwiftyJSON

enum CaseTimelineKey:String {
    case TimelineName    = "TimelineName"
    case TimelineDate    = "TimelineDate"
    case TimelineTime    = "TimelineTime"
    case Time            = "Time"
    case Comment         = "Comment"
    case HospitalType    = "HospitalType"
}

struct CaseTimelineStringConstants {
    static  var Diagnosed    = "Diagnosed"
    static  var STEMI        = "STEMI"
    static  var InTransit    = "In Transit"
    static  var FMCDoorOut   = "FMC Door Out"
    static  var DoorinatHub  = "Door in at Hub"
    static  var InternalTransfer    = "Internal Transfer"
    static  var FMCDoorin    = "FMC Door in"
    static  var Undiagnosed  = "Undiagnosed"
    static  var UnderObservation    = "Under Observation"
    static  var CathLabAccepted    = "Arrived at Cath Lab"
    static  var DeviceCrossTime = "Device Cross Time"
    static  var CathLabExit = "Cath Lab Exit"
    static  var CaseCompleted = "Case Completed"
    static  var TreatmentCancelled = "Treatment Cancelled"
}

class PatientManager: NSObject {
    class func managePatientData(jsonString: JSON) {
        let tempCaseID = jsonString[PatientInfoKey.TempCaseID.rawValue].stringValue
        let patient = PatientInfo.getPatientForTempCaseID(tempCaseID)
        if patient != nil {
         PatientInfo.updatePatient(patient!, json: jsonString)
        } else {
           managePatientDataWithCaseID(jsonString)
        }
    }
    class func managePatientDataWithCaseID(jsonString: JSON) {
        let caseId = jsonString[PatientInfoKey.CaseID.rawValue].stringValue
        let patient = PatientInfo.getPatientForCaseID(caseId)
        if patient != nil {
        PatientInfo.updatePatient(patient!, json: jsonString)
        }
        updateAWSInfo(jsonString)
    }
    class func updateAWSInfo(jsonString: JSON) {
//        CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString)
    }
//    class func insertNewPatient(jsonString: JSON) {
//        dispatch_async(dispatch_get_main_queue(), {
//            PatientInfo.insertNewPatientInfo(jsonString) 
//        })
//    }
    
    class func insertNewPatient(jsonString: JSON, completion:(successful: Bool) -> Void) {
        dispatch_async(dispatch_get_main_queue(), {
            PatientInfo.insertNewPatientInfo(jsonString) { (successful, patientInfo) -> Void in
                completion(successful:successful)
            }
        })
    }
    
    class func insertPatient() -> PatientInfo {
        let patientInfo = PatientInfo.insertPatientInfo(nil)
        if (patientInfo != nil) {
            var  timeline: TimeLine? = nil
            timeline = TimeLine.insertTimeLine(patientInfo!, json: nil)
            timeline?.addNewCaseTime = DateUtility.getCurrentTimeInGMT()
            timeline?.fmcDoorInTime = timeline?.addNewCaseTime
            patientInfo?.timeLine = timeline
            var ecg: ECGInfo? = nil
            ecg = ECGInfo.insertECGInfo(patientInfo!, json: nil)
            patientInfo?.ecgInfo = ecg
            var fmc: FMCCentre? = nil
            fmc = FMCCentre.insertFMCHospital(patientInfo!, json: nil)
            patientInfo?.fmcInfo = fmc
            var treatment: TreatmentCentre? = nil
            treatment = TreatmentCentre.insertTreatmentHospital(patientInfo!, json: nil)
            patientInfo?.treatmentInfo = treatment
            var patientHistory: PatientHistory? = nil
            patientHistory = PatientHistory.insertPatientHistory(patientInfo!, json: nil)
            patientInfo?.patientHistory = patientHistory

            }
        return patientInfo!
    }
    class func updateAllInfo (patient: PatientInfo) {
        dispatch_async(dispatch_get_main_queue(), {
         PatientInfo.updateAllInfo(patient)
        })
    }
    class func updateECGURL(patient: PatientInfo, imagePath: String) -> PatientInfo {
        patient.ecgInfo?.ecgURL = imagePath
        var ecg: ECGInfo? = nil
        ecg = ECGInfo.insertECGInfo(patient, json: nil)
        patient.ecgInfo = ecg
        return patient
    }
    class func clearCache(completion:(successful: Bool) -> Void) {
        DataOperation.sharedDataOperation.deleteObjectsInEntity("PatientInfo", completion: { (successful) in
            if let documentDirectoryPath = FileUtility.getDocumentsDirectoryPath() {
                let path = documentDirectoryPath.stringByAppendingString(ecgFolderPath)
                FileUtility.deleteFileFromPath(path)
                completion(successful:successful)
            }
        })
    }
    class func updateCaseTimeLine(json: JSON) -> (NSMutableArray, NSString) {
        var timelineArray: NSMutableArray
        var timelineDate: NSString = ""
        timelineArray = NSMutableArray()
        if (json [TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timelineDate = DateUtility.convertGMTtoShortDate(time!)
        }
        if (json [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            parseFmcDoorInTime(timelineArray, json: json)
        }
        parseDiagnoseAndUnclearECGTime(timelineArray, json:json)
        
        if (json [TimeLineKey.DaignoseTime.rawValue].dictionary  != nil) {
            parseDiagnosedTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.StemiTime.rawValue].dictionary  != nil) {
            parseStemiTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.SpokeTransferTime.rawValue].dictionary  != nil) {
            parseSpokeTransferTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            parseFmcDoorOutTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.HubDoorInTime.rawValue].dictionary  != nil) {
            parseHubDoorInTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.HubInternalTransferTime.rawValue].dictionary  != nil) {
            parseHubInternalTransferTime(timelineArray, json: json)
        }
        parseCathlabTimeline(timelineArray, json:json)
        if (json [TimeLineKey.CancelTreatmentTime.rawValue].dictionary  != nil) {
            parseCancelTreatmentTime(timelineArray, json: json)
        }
        return (timelineArray, timelineDate)
    }
    
    class func setValueToDict(timelineName:String, comment: String, timelineDate:String,timelineTime:String,time:Double,hospitalType:Int,timelineDict:NSMutableDictionary){
        timelineDict[CaseTimelineKey.TimelineName.rawValue] = timelineName
        timelineDict[CaseTimelineKey.TimelineDate.rawValue] = timelineDate
        timelineDict[CaseTimelineKey.TimelineTime.rawValue] = timelineTime
        timelineDict[CaseTimelineKey.Time.rawValue] = time as Double
        timelineDict[CaseTimelineKey.Comment.rawValue] = comment
        timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType)
    }
    class func setValueForUndiagnosedTimeToDict(timelineName:String, timelineDate:String,timelineTime:String,time:Double,hospitalType:String,timelineDict:NSMutableDictionary){
        timelineDict[CaseTimelineKey.TimelineName.rawValue] = timelineName
        timelineDict[CaseTimelineKey.TimelineDate.rawValue] = timelineDate
        timelineDict[CaseTimelineKey.TimelineTime.rawValue] = timelineTime
        timelineDict[CaseTimelineKey.Time.rawValue] = time as Double
        timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType)
    }
    class func parseDiagnosedTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.DaignoseTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.Diagnosed
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseStemiTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.StemiTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.STEMI
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseSpokeTransferTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.SpokeTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.InTransit
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseFmcDoorOutTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.FMCDoorOut
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseCancelTreatmentTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.CancelTreatmentTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let comment = timeDict![TimeLineKey.Comment.rawValue]?.string
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.TreatmentCancelled
        setValueToDict(timelineName, comment: comment!, timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseHubDoorInTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.HubDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.DoorinatHub
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseHubInternalTransferTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.HubInternalTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.InternalTransfer
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseFmcDoorInTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.FMCDoorin as String
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseUndiagnosedTime(timelineArray:NSMutableArray,diagnoseECGTimeArray:NSMutableArray, i:Int){
        let timelineDictForUnDiag = NSMutableDictionary()
        let timeDict = diagnoseECGTimeArray[i] as! NSDictionary
        let time = timeDict[CaseTimelineKey.Time.rawValue] as! Double
        let hospitalType = timeDict[CaseTimelineKey.HospitalType.rawValue] as! String
        let timelineDate = DateUtility.convertGMTtoShortDate(time)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time)
        let timelineName = CaseTimelineStringConstants.Undiagnosed
        setValueForUndiagnosedTimeToDict(timelineName, timelineDate: timelineDate, timelineTime: timelineTime, time: time, hospitalType: hospitalType, timelineDict: timelineDictForUnDiag)
        timelineArray.addObject(timelineDictForUnDiag)
    }
    class func parseunclearECGTime(timelineArray:NSMutableArray,unclearECGTimeArray:NSMutableArray, i:Int){
        let timelineDictUnClr = NSMutableDictionary()
        let timeDict = unclearECGTimeArray[i] as! NSDictionary
        let time = timeDict[CaseTimelineKey.Time.rawValue] as! Double
        let hospitalType = timeDict[CaseTimelineKey.HospitalType.rawValue] as! String
        let timelineDate = DateUtility.convertGMTtoShortDate(time)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time)
        let timelineName = CaseTimelineStringConstants.UnderObservation
        setValueForUndiagnosedTimeToDict(timelineName, timelineDate: timelineDate, timelineTime: timelineTime, time: time, hospitalType: hospitalType, timelineDict: timelineDictUnClr)
        timelineArray.addObject(timelineDictUnClr)
    }
    
    
    class func parseDiagnoseAndUnclearECGTime(timelineArray:NSMutableArray, json: JSON){
        var diagnoseECGTimeArray : NSMutableArray
        var unclearECGTimeArray : NSMutableArray
        diagnoseECGTimeArray = NSMutableArray()
        unclearECGTimeArray = NSMutableArray()
        if (json [TimeLineKey.DiagnoseECGTime.rawValue].dictionary  != nil) {
            
            var array = json [TimeLineKey.DiagnoseECGTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            for i in (0..<array!.count).reverse(){
                let timelineDict = NSMutableDictionary()
                var  timeDict =  array![i].dictionary
                let time = timeDict![TimeLineKey.Time.rawValue]?.double
                let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
                timelineDict[CaseTimelineKey.Time.rawValue] = time
                timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType!)
                diagnoseECGTimeArray.addObject(timelineDict)
            }
        }
        if (json [TimeLineKey.UnclearECGTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.UnclearECGTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            for i in (0..<array!.count).reverse(){
                let timelineDict = NSMutableDictionary()
                var  timeDict =  array![i].dictionary
                let time = timeDict![TimeLineKey.Time.rawValue]?.double
                let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
                timelineDict[CaseTimelineKey.Time.rawValue] = time
                timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType!)
                unclearECGTimeArray.addObject(timelineDict)
            }
        }
        if(diagnoseECGTimeArray.count > 0){
            for i in 0..<diagnoseECGTimeArray.count{
                parseUndiagnosedTime(timelineArray, diagnoseECGTimeArray: diagnoseECGTimeArray, i: i)
                    if((unclearECGTimeArray.count>0) && (i<unclearECGTimeArray.count)){
                    parseunclearECGTime(timelineArray, unclearECGTimeArray: unclearECGTimeArray, i: i)
                }
            }
        }
    }
    
   class func parseCathlabTimeline(timelineArray:NSMutableArray, json: JSON){
        if (json [TimeLineKey.CathLabAcceptedTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.CathLabAcceptedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CathLabAccepted
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.DeviceCrossTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.DeviceCrossTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.DeviceCrossTime
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.CathLabExitTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.CathLabExitTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CathLabExit
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.TreatmentCompletedTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.TreatmentCompletedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CaseCompleted
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
    }
}
