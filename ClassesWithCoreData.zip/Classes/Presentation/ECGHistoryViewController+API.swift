//  ECGHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension  ECGHistoryViewController {
    
    func getAWSBucketInformation( ) {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                 ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.updateUIAfterLoading()
                    
                } else {
                    
                }
            })
        })
    }

    func downloadImage(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String) {
        
        AWSTransferManager.sharedTransferManager.downloadImageRequest(patientInfo, imageURL: imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Updating the ecg array
                    let ecgFileName = imageURL.lastPathComponent
                    let caseID = patientInfo.caseID
                    if caseID != nil {
                        let filePath = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), ecgFileName!)
                    self.updateECGImage(s3DownloadKeyName, localPath: filePath)
                    }
                } else {
                    self.handleDownloadError()

                }
            })
        })
}


    func getECGInfarctAreaDetails(selectedPatient: PatientInfo) {
        checkInternet()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.getECGInfo(caseid: selectedPatient.caseID!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Decrypt the data
                    DecryptionManager.decryptECGInfarctAreaDetails(jsonString!, caseKey:self.patientInfo?.caseKey as! String, completion: {
                        (decryptedArray, error) in
                         print(decryptedArray)
                        self.infarctAreaHistoryArray = decryptedArray!
                       self.updateInfarctAreas(0)
                       self.updateURLArray()
                        self.reloadInfarctAreaTable()
                        self.ecgHistoryCollectionView.reloadData()
                        
                        let dict = self.infarctAreaHistoryArray[0] as! NSMutableDictionary
                        let url = "\(ecgPath)/\((self.patientInfo?.caseID)!)/\((dict.valueForKey("ecgName") as! String))"
                        self.downloadECGImage(url)
                    })
                    self.patientInfo = selectedPatient
                }
            })

        })

    }


}
