//  MEDImagePager.h
//  MEDImagePager

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

typedef void(^MEDImagePagerImageRequestBlock)(UIImage*image, NSError * error);

@class MEDImagePager;
#pragma mark  - Data source
@protocol MEDImagePagerDataSource <NSObject>

@required
- (NSArray *) arrayWithImages:(MEDImagePager*)pager;
- (UIViewContentMode) contentModeForImage:(NSUInteger)image inPager:(MEDImagePager*)pager;

@optional
- (UIImage *) placeHolderImageForImagePager:(MEDImagePager*)pager;
- (NSString *) captionForImageAtIndex:(NSUInteger)index  inPager:(MEDImagePager*)pager;
- (NSString *) dateCaptionForImageAtIndex:(NSUInteger)index  inPager:(MEDImagePager*)pager;
- (UIViewContentMode) contentModeForPlaceHolder:(MEDImagePager*)pager;

@end

#pragma mark  - Delegate
@protocol MEDImagePagerDelegate <NSObject>

@optional
- (void) imagePager:(MEDImagePager *)imagePager didScrollToIndex:(NSUInteger)index;
- (void) imagePager:(MEDImagePager *)imagePager didSelectImageAtIndex:(NSUInteger)index;

@end

#pragma mark  - Image source

@protocol MEDImagePagerImageSource <NSObject>

-(void) imageWithUrl:(NSURL*)url completion:(MEDImagePagerImageRequestBlock)completion;

@end


@interface MEDImagePager : UIView

// Delegate and Datasource
@property (weak) IBOutlet id <MEDImagePagerDataSource> dataSource;
@property (weak) IBOutlet id <MEDImagePagerDelegate> delegate;
@property (weak) IBOutlet id <MEDImagePagerImageSource> imageSource;


// General
@property (nonatomic) UIViewContentMode contentMode;
@property (nonatomic) UIScrollView *scrollView;
@property (nonatomic) UIPageControl *pageControl;
@property (nonatomic) NSUInteger currentPage;
@property (nonatomic) BOOL indicatorDisabled;
@property (nonatomic) BOOL bounces;
@property (nonatomic) BOOL imageCounterDisabled;
@property (nonatomic) BOOL hidePageControlForSinglePages; // Defaults YES

// Slideshow
@property (nonatomic) NSUInteger slideshowTimeInterval; // Defaults 0.0f (off)
@property (nonatomic) BOOL slideshowShouldCallScrollToDelegate; // Defaults YES

// Caption Label
@property (nonatomic, strong) UIColor *captionTextColor; // Defaults Black
@property (nonatomic, strong) UIColor *captionBackgroundColor; // Defaults White (with an alpha of .7f)
@property (nonatomic, strong) UIFont *captionFont; // Defaults to Helvetica 12.0f points

- (void) reloadData;
- (void) setCurrentPage:(NSUInteger)currentPage animated:(BOOL)animated;

@end

@class MEDCustomLabel;
@interface MEDCustomLabel : UILabel
{
}
@end
