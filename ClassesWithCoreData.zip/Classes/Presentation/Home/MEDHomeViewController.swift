//  MEDHomeViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit
import CoreData
class MEDHomeViewController: MEDCameraLauncher, NSFetchedResultsControllerDelegate {
    @IBOutlet weak var noRecordFoundStackView: UIStackView!
    @IBOutlet var noIntConViewHeight: NSLayoutConstraint!
    @IBOutlet var homeScreenListTable: UITableView!
    @IBOutlet var homeSearchBar: MEDCustomSearchBar!
    @IBOutlet var noInternetConnectionView: UIView!
    @IBOutlet var plusIconLabel: UILabel!
    @IBOutlet var addNewCaseButton: UIBarButtonItem!
    @IBOutlet var homeScreenTitle: UINavigationItem!
    var refreshControl: UIRefreshControl?
    var savedContentOffsetY: CGFloat!
    var isServiceRunnig: Bool = false
    var capturedECGImage: UIImage? = nil
    var shouldTableViewRefresh: Bool = false
    var isNewCaseAdded = false
    var tableViewPreviousScrollOffset: CGPoint? = nil
    var isSearchRunning = false
    var isRefreshing = false
    var searchText = ""
    struct HomeStringConstants {
        static  var CellIdentifier = "HomeScreenListCell"
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }

    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
        performGetCASEList()
        savedContentOffsetY=0
        tableViewPreviousScrollOffset = self.homeScreenListTable.contentOffset

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        //self.noRecordFoundStackView.hidden = true
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        if(appDelegate!.refreshScreen == true){
            shouldTableViewRefresh = true
            appDelegate!.refreshScreen = false
        }
        if shouldTableViewRefresh == true {
            // Checking for any newly added case
            self.stopRefreshingTable()
            self.stopSearchingTable(self.homeSearchBar)
            ActivityIndicatorView.sharedActivityView.showOverlay()
            performGetCASEList()
            shouldTableViewRefresh = false
        }
        handleRefreshControlAnimation()

    }

    override func viewWillDisappear(animated: Bool) {
        //invalidateTimer()
//        stopRefreshingTable()
        super.viewWillDisappear(animated)
        // savedContentOffsetY = homeScreenListTable.contentOffset.y;

    }
    override func viewDidAppear(animated: Bool) {

    }

    func handleRefreshControlAnimation() {
        // This code is to handle refresh control when each time we appear to this screen
        // when we move from this screen to any other, this refresh control gets stuck and stop spinning.
        // The below code is to handle the above case
        let offset = self.homeScreenListTable.contentOffset
        if self.refreshControl?.refreshing == true {

            self.refreshControl?.endRefreshing()
            self.refreshControl?.beginRefreshing()
        }
        self.homeScreenListTable.contentOffset = offset
    }
    // MARK: -  NSFetchedResultsController Methods
    func performFetch () {
        do {
            if self.isSearchRunning == true && searchText.isEmpty == false {
                let idPredicate = NSPredicate(format:"hospitalCaseID CONTAINS[cd] %@ OR fmcInfo.consultant CONTAINS[cd] %@ OR fmcInfo.abbreviation CONTAINS[cd] %@ OR treatmentInfo.abbreviation CONTAINS[cd] %@ OR lastName == %@ OR firstName == %@  OR middleName == %@", self.searchText, self.searchText, self.searchText, self.searchText, self.searchText, self.searchText, self.searchText)
                fetchedResultsController.fetchRequest.predicate = idPredicate
            } else {
                fetchedResultsController.fetchRequest.predicate = nil
            }
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("Failed to initialize FetchedResultsController: \(error)")
        }
    }
    //    var fetchedResultsController: NSFetchedResultsController
    lazy var fetchedResultsController: NSFetchedResultsController = {
        let fetchRequest = NSFetchRequest(entityName: "PatientInfo")
        let sortDescriptor = NSSortDescriptor(key: "timeLine.addNewCaseTime", ascending: false)// Add Sort Descriptors
        fetchRequest.sortDescriptors = [sortDescriptor]// Initialize Fetched Results Controller
        // 2
        let fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: DataOperation.sharedDataOperation.mainThreadContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        return fetchedResultsController
    }()
}
// MARK: - @IBAction Methods
extension MEDHomeViewController {
    @IBAction func openCameraButtonAction(sender: AnyObject) {
        self.cameraButtonTapped()

    }
}
// MARK: - Custom Actions
extension MEDHomeViewController {
    func initialSetUp() {
        self.navigationItem.rightBarButtonItem = nil
        self.enableAddNewCaseIcon()
        addRefreshControl()
        homeScreenListTable.exclusiveTouch = true
        self.homeSearchBar.keyboardType = UIKeyboardType.ASCIICapable


    }
    func navigateToCardiologistDiagnoseScreen() {
        let vc: MEDCardiologistECGViewController = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.cardiologistDignoseViewControllerSBID) as! MEDCardiologistECGViewController
        vc.patientInfo = self.patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToOnCallCardiologistDiagnoseScreen() {
        let vc: MEDOnCallCardioDiagnosisVC = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.OnCallCardiologistSBID) as! MEDOnCallCardioDiagnosisVC
        vc.patientInfo = self.patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func addNewCase() {
        self.view.endEditing(true)
        shouldTableViewRefresh = true
        handleFMCTime()
    }

    func stopRefreshingTable() {
        self.view.endEditing(true)
       self.homeScreenListTable.userInteractionEnabled = true
        if let _ = self.refreshControl {
            self.refreshControl!.endRefreshing()
        }
        self.reloadTable()
       

    }

    func stopSearchingTable(searchBar: UISearchBar?) {
        self.isSearchRunning = false
        searchBar!.text = ""
        searchBar!.showsCancelButton = false
        self.homeScreenListTable.addSubview(refreshControl!)
    }
    func navigateToViewSummary(patientInfo: PatientInfo) {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.viewSummaryScreenSBID) as! MEDViewSummaryViewController
        vc.patientInfo = patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func navigateToPatientInfoView(patientInfo: PatientInfo) {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.patientBaseViewControllerSBID) as! MEDPatientBaseContainerView
        vc.patientInfo = patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func handleFMCTime() {
        patientInfo =  PatientManager.insertPatient()
    }
    func updateUI() {
        if(NetworkUtil.isConnected()) {
            if (fetchedResultsController.fetchedObjects != nil && fetchedResultsController.fetchedObjects?.count > 0) {
                enableUI(false, isInternetLableHidden: true)} else {
                enableUI(false, isInternetLableHidden:true)}
        } else {
            enableUI(false, isInternetLableHidden:false)}
    }
    func presentNoInternetConnectionLabel(isConnected: Bool) {
        noInternetConnectionView.hidden = isConnected
    }
    func enableUI(isTableHidden: Bool, isInternetLableHidden: Bool) {
        presentNoInternetConnectionLabel(isInternetLableHidden)
        homeScreenListTable.hidden = isTableHidden
        if isInternetLableHidden {
            noIntConViewHeight.constant = 0} else {
            noIntConViewHeight.constant = 28
        }
    }
    func enableAddNewCaseIcon() {
        let user = LoginManager.getLoggedInUser()
        if (user != nil) {
            switch (user?.roleID)! as String {
            case "1":
                self.navigationItem.rightBarButtonItem = addNewCaseButton
                plusIconLabel.hidden = false
                homeScreenTitle.title = "Recent Cases"
            case "2":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
            case "3":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
                homeScreenTitle.title = "Un-diagnosed Cases"
            case "7":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
            default: break
            }
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(HomeStringConstants.AlertTitle, message:HomeStringConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func configureCellData(cell: MEDHomeScreenTableViewCell, indexpath: NSIndexPath) {
        // Fetch Record
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.statusView.backgroundColor = UIColor.clearColor()
        cell.statusImage.backgroundColor = UIColor.whiteColor()

        let cellPatient = self.fetchedResultsController.objectAtIndexPath(indexpath) as! PatientInfo
        let patientName: String
        if cellPatient.firstName != nil  && cellPatient.lastName != nil {

            if cellPatient.middleName as! String != "" {
                let middileName = String((cellPatient.middleName as! String).characters.prefix(1))
                patientName = (((cellPatient.firstName as! String) as String) + " " + ((middileName) as String) + " " + ((cellPatient.lastName)! as! String) as String).uppercaseString

            } else {

                patientName = (((cellPatient.firstName as! String) as String) + " " + ((cellPatient.lastName)! as! String) as String).uppercaseString

            }
            if cellPatient.hospitalCaseID != nil {
                cell.patientCaseID.text = (cellPatient.hospitalCaseID)! as String + ":" + patientName
            }
        } else {
            if cellPatient.hospitalCaseID != nil {
                cell.patientCaseID.text = (cellPatient.hospitalCaseID)! as String
            }
        }
        let status = (cellPatient.caseStatus)! as String
        let (color) = getStatusImage(status, cell:cell)
        cell.status.textColor = color
        cell.statusImage.image = nil//image
        cell.statusView.backgroundColor = color

        if cellPatient.timeLine?.fmcDoorInTime != nil {
            let fmcDoorInTime = cellPatient.timeLine?.fmcDoorInTime as? Double
            if fmcDoorInTime != 0 {
                let doorInTimeString = DateUtility.convertGMTtoShortDate(fmcDoorInTime!)
                cell.fmcDate.text = doorInTimeString
            }
        }
        if cellPatient.fmcInfo != nil {
            var fmcCenter: String? = ""
            if let _ = cellPatient.fmcInfo!.abbreviation {
                fmcCenter = cellPatient.fmcInfo!.abbreviation
            }
            var drName = ""
            if let _ = cellPatient.fmcInfo?.consultant {
                drName = (cellPatient.fmcInfo?.consultant)!
            }
            if(drName.isEmpty == false && fmcCenter?.isEmpty == false) {
            cell.drName.text = drName + " (" + fmcCenter! + ")"}
        }
        if  cellPatient.treatmentInfo?.abbreviation == nil {
            cell.treatmentCenterLineLabel.hidden = false
            cell.treatmentCenter.text = ""
        } else {
            cell.treatmentCenter.text = cellPatient.treatmentInfo?.abbreviation
            cell.treatmentCenterLineLabel.hidden = true
        }
        let user = LoginManager.getLoggedInUser()
        if (user != nil) {
            if (user?.roleID == "3") {
                cell.treatmentCenterLineLabel.hidden = true
                cell.treatmentCenter.hidden = true
                cell.treatmentCenterLabel.hidden = true
            }
        }
        if(status == "13"){
            cell.drName.textColor = ColorPicker.battleshipGrey()
            cell.treatmentCenter.textColor = ColorPicker.battleshipGrey()
            cell.fmcDate.textColor = ColorPicker.battleshipGrey()
            cell.patientCaseID.textColor = ColorPicker.battleshipGrey()
        }
        else{
            cell.drName.textColor = ColorPicker.greyishBrown()
            cell.treatmentCenter.textColor = ColorPicker.greyishBrown()
            cell.fmcDate.textColor = ColorPicker.greyishBrown()
            cell.patientCaseID.textColor = ColorPicker.greyishBrown()
        }
    }

    func getStatusImage(statusStr: String, cell: MEDHomeScreenTableViewCell) -> (UIColor) {
       // var image: UIImage!
        var color: UIColor!
        switch statusStr {
        case status.Diagnosed.rawValue:
            //image = UIImage(named:ImageConstants.UndiagnosedStatusImage)!
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.Diagnosed
        case status.UnderObservation.rawValue:
            //image = UIImage(named:ImageConstants.UndiagnosedStatusImage)!
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.UnderObservation
        case status.Undiagnosed.rawValue:
            //image = UIImage(named:ImageConstants.UndiagnosedStatusImage)!
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.Undiagnosed
        case status.STEMI.rawValue:
            //image = UIImage(named:ImageConstants.StemiStatusImage)!
            color = ColorPicker.deepOrange()
            cell.status.text = StatusConstants.STEMI
        case status.New.rawValue:
            //image = UIImage(named:ImageConstants.UndiagnosedStatusImage)!
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.New
        case status.InTransit.rawValue:
           // image = UIImage(named:ImageConstants.InTransitStatusImage)!
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.InTransit
        case status.Completed.rawValue:
           // image = UIImage(named:ImageConstants.CompletedStatusImage)!
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.Completed
        case status.InternalTransfer.rawValue:
          //  image = UIImage(named:ImageConstants.InTransitStatusImage)!
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.InternalTransfer
        case status.CathLabAccepted.rawValue:
           // image = UIImage(named:ImageConstants.InTransitStatusImage)!
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.CathLabAccepted
        case status.DeviceCrossTime.rawValue:
           // image = UIImage(named:ImageConstants.CompletedStatusImage)!
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.DeviceCrossTime
        case   status.CathLabExit.rawValue:
            //image = UIImage(named:ImageConstants.CompletedStatusImage)!
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.CathLabExit
        case  status.NotAStemi.rawValue:
            //image = UIImage(named:ImageConstants.CompletedStatusImage)!
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.NotAStemi
        case  status.Cancelled.rawValue:
            //image = UIImage(named:ImageConstants.CancelledStatusImage)!
            color = ColorPicker.fadedOrange()
            cell.status.text = StatusConstants.Cancelled
        default:
           // image = UIImage(named:ImageConstants.CompletedStatusImage)!
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.NotAStemi
        }
        return (color)
    }
    func reloadTable() {
        self.performFetch()
        self.updateUI()
        self.homeScreenListTable.reloadData()
        UIView.animateWithDuration(0.2, animations: {
            self.homeScreenListTable.contentOffset = CGPoint(x: 0, y: 0)
        })

    }
    // MARK: - Segue Methods
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let vc = segue.destinationViewController as! MEDPatientBaseContainerView
        self.addNewCase()
        vc.patientInfo = patientInfo
    }
    //MARK: - Image Picker Delegates
    func cameraButtonTapped() {
        self.presentCamera()
    }
    override  func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        capturedECGImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        addNewCase()

    }

    override func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
        self.capturedECGImage = nil

    }

    func addRefreshControl() {
        refreshControl = UIRefreshControl()
        refreshControl!.addTarget(self, action: #selector(refresh(_:)), forControlEvents: .ValueChanged)
        self.homeScreenListTable.addSubview(refreshControl!)
    }
    func refresh(refreshControl: UIRefreshControl) {
        // Do your job, when done:
        if !isRefreshing{
            self.isRefreshing = true
            self.performGetCASEList()
        }
        //        refreshControl.endRefreshing()
    }

}
// MARK: - tableView Delegate methods
extension MEDHomeViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 6
        }
        return 44
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        var count = 0
        if let sections = fetchedResultsController.sections {
            count = sections.count
            print("fetchedResultsController",count)

        }
        return count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = 0

        if let sections = fetchedResultsController.sections {
            let sectionInfo = sections[section]
            count =  sectionInfo.numberOfObjects

        }
        return count
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 122
    }
}
// MARK: - tableView DataSource methods
extension  MEDHomeViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(HomeStringConstants.CellIdentifier, forIndexPath: indexPath) as! MEDHomeScreenTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.view.endEditing(true)
        let selectedPatientInfo = self.fetchedResultsController.objectAtIndexPath(indexPath) as! PatientInfo
        let user = LoginManager.getLoggedInUser()
        let roleID = (user?.roleID!)! as String
        if (selectedPatientInfo.caseStatus == status.Undiagnosed.rawValue && (roleID == UserRoles.Cardiologist.rawValue || roleID == UserRoles.OnCallCardiologist.rawValue)) {
            getUndiagnosedCaseDetails(selectedPatientInfo)
        } else {
             performGetCASEDetails(selectedPatientInfo)
        }
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }


    func scrollViewDidScroll(scrollView: UIScrollView) {
        // Updating the no record found label's frame when scrolling the table view
        self.view.endEditing(true)
        let delta =  scrollView.contentOffset.y - tableViewPreviousScrollOffset!.y
        self.noRecordFoundStackView.frame.origin.y =  self.noRecordFoundStackView.frame.origin.y - delta
        self.view.layoutIfNeeded()
        tableViewPreviousScrollOffset = scrollView.contentOffset
    }
}

// MARK: UISearchBarDelegate
extension MEDHomeViewController:UISearchBarDelegate {
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        // Search button tapped
        // Dismissing the keyboard
        searchBar.resignFirstResponder()
    }
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        self.stopSearchingTable(searchBar)
        self.searchText = ""
        searchBar.endEditing(true)
        self.reloadTable()
    }
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        self.refreshControl?.removeFromSuperview()
        searchBar.showsCancelButton = true


        for sView in searchBar.subviews {
            for ssView in sView.subviews {
                if ssView.isKindOfClass(UIButton.self) {
                    let cancelButton = ssView as! UIButton
                    cancelButton.setTitle("Cancel", forState: .Normal)
                    cancelButton.titleLabel?.font = UIFont(name: "Effra", size: 15.0)
                    break
                } else if ssView.isKindOfClass(UITextField.self) {
                    let searchTextField = ssView as! UITextField
                    searchTextField.font = UIFont(name: "Effra", size: 14)
                }
            }
        }



    }
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        // Code for handling the search results
            isSearchRunning = true
            self.searchText = searchText
            self.reloadTable()

    }
    func searchBar(searchBar: UISearchBar, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let updatedString = (searchText as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if( updatedString == " "){
            return false
        }
        return true
    }
}
//MARK: - Alert view delegates
extension MEDHomeViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
            // Moving the user to home listing screen
            self.refresh(refreshControl!)
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }

