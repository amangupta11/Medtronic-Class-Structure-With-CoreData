//  MEDHomeViewController+FetchedResultsController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import CoreData
// MARK: Fetched Results Controller Delegate Methods
extension MEDHomeViewController {
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        homeScreenListTable.beginUpdates()
    }
    func controller(controller: NSFetchedResultsController, didChangeSection sectionInfo: NSFetchedResultsSectionInfo, atIndex sectionIndex: Int, forChangeType type: NSFetchedResultsChangeType) {
        switch type {
        case .Insert:
            homeScreenListTable.insertSections(NSIndexSet(index: sectionIndex), withRowAnimation: .Fade)
        case .Delete:
            homeScreenListTable.deleteSections(NSIndexSet(index: sectionIndex), withRowAnimation: .Fade)
        case .Move: break

        case .Update: break

        }
    }
    func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
        switch (type) {
        case .Insert:
            if let indexPath = newIndexPath {
                homeScreenListTable.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
            }

        case .Delete:
            if let indexPath = indexPath {
                homeScreenListTable.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
            }

        case .Update:
            if let indexPath = indexPath {
                dispatch_async(dispatch_get_main_queue(), {
                    let cell = self.homeScreenListTable.cellForRowAtIndexPath(indexPath)
                    if cell != nil {
                        self.configureCellData(cell as! MEDHomeScreenTableViewCell, indexpath:indexPath)}
                })
            }

        case .Move:
            if let indexPath = indexPath {
                homeScreenListTable.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
            }
            if let newIndexPath = newIndexPath {
                homeScreenListTable.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Fade)
            }

        }
    }
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        homeScreenListTable.endUpdates()
    }
}
