//  MEDHomeScreenTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDHomeScreenTableViewCell: UITableViewCell {
    
    @IBOutlet weak var statusView: UIView!
    @IBOutlet var statusImage: UIImageView!
    @IBOutlet var fmcDate: UILabel!
    @IBOutlet var status: UILabel!
    @IBOutlet var treatmentCenter: UILabel!
    @IBOutlet var drName: UILabel!
    @IBOutlet var treatmentCenterLineLabel: UILabel!
    @IBOutlet var patientCaseID: UILabel!
    @IBOutlet var treatmentCenterLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    override func layoutSubviews() {
        statusView.layer.cornerRadius =  5
        statusImage.layer.cornerRadius =  5
        statusView.layer.shadowColor = UIColor.grayColor().CGColor
        statusView.layer.shadowOpacity = 0.2
        statusView.layer.shadowOffset = CGSizeMake(2, 2)
        statusView.layer.shadowRadius = 0.5
        statusView.layer.masksToBounds = false
    }
}
