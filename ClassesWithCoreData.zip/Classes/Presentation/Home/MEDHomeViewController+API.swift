//  MEDHomeViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDHomeViewController {
    func performGetCASEDetails(selectedPatientInfo: PatientInfo) {
        checkInternet()
        if  selectedPatientInfo.caseID != nil {
            let dict = [PatientInfoKey.CaseID.rawValue:selectedPatientInfo.caseID as! AnyObject]
            APIRequest.sharedAPI.getCASEDetails(dictionary:dict, patientInfo:selectedPatientInfo, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                        if (selectedPatientInfo.caseStatus == status.Diagnosed.rawValue || selectedPatientInfo.caseStatus == status.UnderObservation.rawValue || selectedPatientInfo.caseStatus == status.New.rawValue) {
                            self.navigateToPatientInfoView(selectedPatientInfo)
                        } else {
                        self.navigateToViewSummary(selectedPatientInfo)
                        }
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                })
            })
        }}
    func performGetCASEList() {

        PatientManager.clearCache { (successful) in
//            self.reloadTable()
            // Disabling the table view interaction
            self.homeScreenListTable.userInteractionEnabled = false
            self.enableUI(false, isInternetLableHidden: true)
            if successful == true {
                self.performUIOperation()
                self.isRefreshing = false
                    }
            else{
                self.isRefreshing = false
            }
                }
            }

    func performUIOperation() {
        if NetworkUtil.isConnected() == true {
//            ActivityIndicatorView.sharedActivityView.showOverlay()
            let dict = [String:String]()

            APIRequest.sharedAPI.getCASEList(dictionary:dict, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                   ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
//                    self.reloadTable()
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                    self.reloadTable()
                    if let _ = self.refreshControl {
                        self.refreshControl!.endRefreshing()
                    }
                    if self.fetchedResultsController.fetchedObjects?.count > 0 {
                        self.noRecordFoundStackView.hidden = true
                    } else {
                        self.noRecordFoundStackView.hidden = false
                        self.view.bringSubviewToFront(self.noRecordFoundStackView)
                        self.homeScreenListTable.backgroundColor = UIColor.clearColor()
                    }
                    self.homeScreenListTable.userInteractionEnabled = true
                })
            })

        } else {
            if let _ = self.refreshControl {
                self.refreshControl!.endRefreshing()
            }
        self.homeScreenListTable.userInteractionEnabled = true
         ActivityIndicatorView.sharedActivityView.hideOverlayView()
           self.enableUI(false, isInternetLableHidden: false)
        }
    }

    func getUndiagnosedCaseDetails(selectedPatient: PatientInfo) {
        checkInternet()
            ActivityIndicatorView.sharedActivityView.showOverlay()
            let dict = [PatientInfoKey.CaseID.rawValue: selectedPatient.caseID as! AnyObject ]
                APIRequest.sharedAPI.getUndiagnosedCaseDetails(dictionary: dict, patientInfo: selectedPatient, completion: {
                    (jsonString, successful, error, response) in
                    dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                    self.patientInfo = selectedPatient
                        let user = LoginManager.getLoggedInUser()
                        let roleID = (user?.roleID!)! as String
                        if (roleID == UserRoles.Cardiologist.rawValue){
                            self.navigateToCardiologistDiagnoseScreen()
                        }
                        else{
                            self.navigateToOnCallCardiologistDiagnoseScreen()
                        }
                    }
                    else{
                        if(response?.statusCode == 403){
                            self.showUnauthorizationAlert()
                        }
                        }
                })
                })
        }
}