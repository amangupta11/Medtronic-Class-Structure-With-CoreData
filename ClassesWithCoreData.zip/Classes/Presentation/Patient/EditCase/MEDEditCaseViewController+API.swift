//  MEDEditCaseViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDEditCaseViewController {

    func performEditCaseGeneralInfo() {
        checkInternet()
        let dict = [PatientInfoKey.CaseID.rawValue:patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.editCaseGeneralInfo(dictionary:dict, patientInfo: patientInfo!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.performGetCASEDetails()
                } else {
                    if(response?.statusCode == 403){
                        self.authorizationAlert = true
                        self.showUnauthorizationAlert()
                    }else{
                        super.handleError(error)
                    }
                }
            })
        })
    }
    func performPostCASEDetails() {
        checkInternet()
        APIRequest.sharedAPI.postCASEDetails(patientInfo:patientInfo!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.performGetCASEDetails()
                } else {
                    super.handleError(error)
                }})})
    }

    func performGetCASEDetails() {
        checkInternet()
        let dict = [PatientInfoKey.CaseID.rawValue:patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.getCASEDetails(dictionary:dict, patientInfo:(patientInfo)!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.performNavigation()} else {
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription}
                    super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)}})})}
}
