//  MEDPatientHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
extension MEDPatientHistoryViewController {

    func postPatientHistoryInfoDetails() {
        checkInternet()
        APIRequest.sharedAPI.updatePatientHistory(patientInfo: patientInfo!, completion: {
            (jsonString, successful, error, response) in
                if successful {
                    dispatch_async(dispatch_get_main_queue(), {
                        ActivityIndicatorView.sharedActivityView.hideOverlayView()
                        self.handleResponse()
                        })

                } else {
                    super.handleError(error)

                }
        })
    }
}
