//  MEDStopTreatmentController.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class MEDStopTreatmentController: MEDBaseViewController, UITableViewDataSource, UITableViewDelegate ,AlertViewControllerProtocol{
 var doneBarButton = UIBarButtonItem()
    @IBOutlet weak var stopTreatmentTV: UITableView!
    var commonArr = NSMutableArray()
    var scrollOffset: CGFloat!
    var commentsTV = UITextView()
    var indexPath = NSIndexPath()
    var selectedDataDict = NSMutableDictionary(capacity: 0)
    var stoppedTimeDataDict = NSMutableDictionary(capacity: 0)
    var requestDict = NSMutableDictionary(capacity: 0)
    var isTextViewMarkedRed = false
    var currentAlertViewTag: stopTreatmentAlertTags!

    enum StopTreatmentCellIdentifier : String {
        case CUSTOMCELLID = "STOPTREATMENTCELLIDENTIFIER"
        case OTHERCELLID = "OTHERCELLIDENTIFIER"
    }
    struct StopTreatmentConstants {
        static  var ConfirmationTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static  var ConfirmationMsg = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_STOP_TREATMENT", comment: "")
    }
    
    enum stopTreatmentAlertTags: Int {
        case AlreadyTransfered = 101
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            startTimer()
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
}
    // MARK: - TABLE VIEW DELEGATES
    extension MEDStopTreatmentController{
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let dataDict : NSMutableDictionary = commonArr[indexPath.row] as! NSMutableDictionary
        let isSelected = dataDict[stopTreatmentDictKey.others] as! Bool
        if isSelected{
            return 130
        }
        else{
            return 60
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return commonArr.count
    }
    
    func getCustomCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = stopTreatmentTV.dequeueReusableCellWithIdentifier(StopTreatmentCellIdentifier.CUSTOMCELLID.rawValue , forIndexPath: indexPath) as! MEDStopTreatmentCustomCell
        let dataDict : NSMutableDictionary = commonArr[indexPath.row] as! NSMutableDictionary
        cell.trtReasonLbl.text = self.getTreatmentName(dataDict)
        let isSelected = dataDict[stopTreatmentDictKey.selectedKey] as! Bool
        if isSelected{
            cell.trtCheckMarkIV.image = UIImage(named: "checkedGenderImage")
        }
        else{
            cell.trtCheckMarkIV.image = UIImage(named: "UncheckedGenderImage")
            
        }
        return cell
    }
    
    func getOtherCustomCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        self.indexPath = indexPath
        let cell: OtherCustomCell = tableView.dequeueReusableCellWithIdentifier(StopTreatmentCellIdentifier.OTHERCELLID.rawValue) as! OtherCustomCell
        cell.commentsTV.layer.borderWidth = 1
        self.commentsTV = cell.commentsTV
        let dataDict : NSMutableDictionary = commonArr[indexPath.row] as! NSMutableDictionary
        cell.otherLbl.text = self.getTreatmentName(dataDict)
        let isSelected = dataDict[stopTreatmentDictKey.others] as! Bool
        if isSelected{
            cell.checkMarkIV.image = UIImage(named: "checkedGenderImage")
        }
        else{
            cell.checkMarkIV.image = UIImage(named: "UncheckedGenderImage")
        }
        self.handleTextViewUI(cell.commentsTV)
        return cell
    }
    
    func getTreatmentName(dataDict: NSMutableDictionary) -> String
    {
        let delimiter = ","
        let str = dataDict[stopTreatmentDictKey.valueKey] as? String
        var strippedStr = str!.componentsSeparatedByString(delimiter)
        return strippedStr[1] as String
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        if indexPath.row == commonArr.count - 1
        {
            return self.getOtherCustomCell(tableView, cellForRowAtIndexPath: indexPath)
        }
        else{
            return self.getCustomCell(tableView, cellForRowAtIndexPath: indexPath)
        }
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        doneBarButton.enabled = true
        for dict in commonArr {
            dict.setValue(false, forKey: stopTreatmentDictKey.selectedKey)
            dict.setValue(false, forKey: stopTreatmentDictKey.others)
        }
        let selDataDict = commonArr.objectAtIndex(indexPath.row)
        selDataDict.setValue(true, forKey: stopTreatmentDictKey.selectedKey)
        
        if indexPath.row == commonArr.count - 1{
            selDataDict.setValue(true, forKey: stopTreatmentDictKey.others)
        }
        else{
            self.commentsTV.text = ""
        }
        stopTreatmentTV.reloadData()
        
        let currentTime = DateUtility.getCurrentTimeInGMT() as NSNumber
        selectedDataDict = NSMutableDictionary(capacity: 0)
        selectedDataDict[StringConstants.Comment] = selDataDict[stopTreatmentDictKey.valueKey]
        selectedDataDict[StringConstants.Location] = ""
        selectedDataDict[StringConstants.Time] = currentTime.stringValue
        stoppedTimeDataDict = NSMutableDictionary(capacity: 0)
        stoppedTimeDataDict[StringConstants.Comment] = ""
        stoppedTimeDataDict[StringConstants.Location] = ""
        stoppedTimeDataDict[StringConstants.Time] = currentTime.stringValue
        requestDict[StringConstants.CaseID] = patientInfo?.caseID
        requestDict[StringConstants.CancelTreatmentTime] = selectedDataDict
        requestDict[StringConstants.StoppedTime] = stoppedTimeDataDict
    }
        
        func getCommentText() -> String{
            var commentTVTxt = self.commentsTV.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            commentTVTxt = "10," + commentTVTxt
            return commentTVTxt
        }
        
        func handleTextViewUI(textView: UITextView) {
            if self.isTextViewMarkedRed == false {
                self.normalizeOtherCommentsTextView(textView)
            } else {
                self.highlightOtherCommentsTextView(textView)
            }
        }
}
extension MEDStopTreatmentController {
    func initialSetup() {
        self.stopTreatmentTV.tableFooterView = UIView()
        self.navigationItem.rightBarButtonItem = nil
        setNavigationBackButtonImage()
        getNavigationRightBarButtonItem()
        let user = LoginManager.getLoggedInUser()
        var dataArr = NSArray()
        if let path = FileUtility.getPlistPath() {
            if let metaDataPList = NSDictionary(contentsOfFile: path) {
                if (user != nil) {
                    switch (user?.roleID)! as String {
                    case "1"://Spoke or Hub
                        dataArr = metaDataPList.objectForKey("CancelTreatmentOptionsForEDNurse") as! NSArray
                    case "2"://CathLab
                        dataArr = metaDataPList.objectForKey("CancelTreatmentOptionsForCathLab") as! NSArray
                    case "3": break//Cardio
                    default: break
                    }
                }
                
            }
            
        }
        commonArr = createDataArray(dataArr)
    }
    func createDataArray(datArr : NSArray) -> NSMutableArray{
        let mutArr = NSMutableArray()
        for i in datArr{
            let dict = NSMutableDictionary()
            dict.setValue(i, forKey: stopTreatmentDictKey.valueKey)
            dict.setValue(false, forKey: stopTreatmentDictKey.selectedKey)
            dict.setValue(false, forKey: stopTreatmentDictKey.others)
            mutArr.addObject(dict)
        }
        return mutArr
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    override func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func getNavigationRightBarButtonItem() {
        
        let backButton = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: 20))
        backButton.addTarget(self, action:#selector(rightBarButtonAction), forControlEvents: .TouchUpInside)
        backButton.setTitle("Done", forState: UIControlState.Normal)
        backButton.titleLabel?.font = UIFont(name: "effra-regular", size: 16)!
        backButton.titleLabel?.textColor = UIColor.whiteColor()
        let color : UIColor = UIColor.whiteColor()
        let disableColor : UIColor = UIColor.grayColor()
        
        backButton.setTitleColor(color, forState: UIControlState.Normal)
        backButton.setTitleColor(disableColor, forState: UIControlState.Disabled)
            doneBarButton = UIBarButtonItem(customView: backButton)
        self.navigationItem.rightBarButtonItem = doneBarButton
        doneBarButton.enabled = false
}
    func getSelectedDict() -> NSMutableDictionary
    {
        var selDict = NSMutableDictionary(capacity: 0)
        for dict in commonArr{
            let isSelected = dict[stopTreatmentDictKey.selectedKey] as! Bool
            if isSelected{
                selDict = dict as! NSMutableDictionary
                return selDict
            }
        }
        return selDict
    }
    
    func rightBarButtonAction()
    {
        if self.getTreatmentName(self.getSelectedDict()) == "Others" {
            if self.commentsTV.text.utf16.count == 0{
                isTextViewMarkedRed = true
                self.handleTextViewUI(self.commentsTV)
            }
            else{
                isTextViewMarkedRed = false
                self.selectedDataDict .setValue(self.getCommentText(), forKey: StringConstants.Comment)
                
                let indexPath = NSIndexPath(forRow: commonArr.count - 1, inSection: 0)
                let commentCell = self.stopTreatmentTV.cellForRowAtIndexPath(indexPath) as! OtherCustomCell
                self.normalizeOtherCommentsTextView(commentCell.commentsTV)
                self.showAlertWithTwoButtons(StopTreatmentConstants.ConfirmationTitle, alertMsg: StopTreatmentConstants.ConfirmationMsg)
                
            }
        }
        else{
            isTextViewMarkedRed = false
            self.showAlertWithTwoButtons(StopTreatmentConstants.ConfirmationTitle, alertMsg: StopTreatmentConstants.ConfirmationMsg)
        }
        self.stopTreatmentTV.reloadData()
    }

    override func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                let contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height - 41, 0)
                
                self.stopTreatmentTV.scrollEnabled = true
                self.stopTreatmentTV.contentInset = contentInset
                self.stopTreatmentTV.scrollIndicatorInsets = contentInset
                let indexPath = NSIndexPath(forRow: self.commonArr.count - 1, inSection: 0)
                let commentCell = self.stopTreatmentTV.cellForRowAtIndexPath(indexPath) as! OtherCustomCell
                self.stopTreatmentTV.scrollRectToVisible(commentCell.frame, animated: true)
                
            })
        }
    }
    override func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.stopTreatmentTV.contentInset = UIEdgeInsetsZero
        })
    }
    func highlightOtherCommentsTextView(textView: UITextView) {
        self.commentsTV.layer.borderColor = UIColor.redColor().CGColor
    }
    func normalizeOtherCommentsTextView(textView: UITextView) {
        self.commentsTV.layer.borderColor = ColorPicker.lightBlueGray2().CGColor
    }
}
// MARK: - ALERT VIEW DELEGATES
extension MEDStopTreatmentController{
    func showAlertWithTwoButtons(alertTitle: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTitle, message:alertMsg, okTitle: AlertViewButtonTitle.NoButtonTitle, cancelTitle: AlertViewButtonTitle.YesButtonTitle, prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    
    //MARK: - Custom alert view
    func showCustomAlertWithOneButton(alertTitle: String, message: String, alertTag: stopTreatmentAlertTags) {
        
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        currentAlertViewTag = alertTag
        alertView = alertController.showSimpleAlert(alertTitle, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
        
    }
    
    func cancelButtonAction(alertController: UIAlertController) {
     //YES
        patientInfo?.timeLine?.stoppedTime = DateUtility.getCurrentTimeInGMT()
        self.requestToCancelTreatment(requestDict)
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func OKButtonAction(alertController: UIAlertController) {
        //NO
        alertController.dismissViewControllerAnimated(true, completion: nil)
        //self.stopTreatmentTV.reloadData()

    }
    
    func defaultButtonAction(alertController: UIAlertController) {
        switch currentAlertViewTag.rawValue {
        case 101:
            navigateToHome()
        default:
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}

extension MEDStopTreatmentController: UITextViewDelegate {

    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.commentsTV = textView

        textView.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textView)
        return true
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.becomeFirstResponder()
            return true
        }
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if (updatedString?.characters.count)! > 139 {
            return false
        }
        else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}