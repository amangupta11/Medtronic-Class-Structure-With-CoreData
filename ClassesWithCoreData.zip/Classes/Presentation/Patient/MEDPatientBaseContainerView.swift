//  MEDPatientBaseContainerView.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

enum ScreenTag: Int {
    case Step1 = 1
    case Step2 = 2
    case Step3 = 3
}


enum PaginationButtonTag: Int {
    case Page1 = 101
    case Page2 = 102
    case Page3 = 103
}
struct MEDPatientBaseConstants {
    static  var SaveDataAlertMsg            = NSLocalizedString("YOU_WILL_LOSE_UNSAVEDDATA_WOULD _YOU_LIKE_TO_CONTINUE", comment: "")
    static var ConfirmationAlertTitle       = NSLocalizedString("CONFIRMATION", comment: "")
}
class MEDPatientBaseContainerView: MEDBaseViewController {
    @IBOutlet weak var stepButtonContainerView: UIView!
    @IBOutlet weak var firstLineLbl: UILabel!
    @IBOutlet weak var secondLineLbl: UILabel!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var step1ButtonOutlet: UIButton!
    @IBOutlet weak var step2ButtonOutlet: UIButton!
    @IBOutlet weak var stepTwoBtnWidth: NSLayoutConstraint!
    @IBOutlet weak var step3ButtonOutlet: UIButton!
    @IBOutlet weak var stepOneBtnWidth: NSLayoutConstraint!
    var screenTag: ScreenTag!
    @IBOutlet weak var stepOneBtnheight: NSLayoutConstraint!
    @IBOutlet weak var stepTwoBtnHeight: NSLayoutConstraint!
    @IBOutlet weak var stepThreeBtnHeight: NSLayoutConstraint!
    @IBOutlet weak var stepThreeBtnWidth: NSLayoutConstraint!
    var patientInfoScreen: MEDPatientGeneralInfoViewController?
    var patientHistoryScreen: MEDPatientHistoryViewController?
    var ecgViewControllerScreen: MEDPatientECGViewController?
    var highlightedButton: UIButton!
     var normalizeButton: UIButton!
    var tempValue: CGFloat!
    var tempValueTwo: CGFloat!
    var ecgImage: UIImage!
    var highLighted: NSString!
    var shouldAnimate = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
        shouldAnimate = true
    }
    override func viewDidLayoutSubviews() {
        self.highlightStepButton(self.highlightedButton)
    }
    override func viewDidAppear(animated: Bool) {

    }

}


// MARK: - Custom Actions
extension MEDPatientBaseContainerView {
    override  func backButtonAction(button: UIButton) {
        // Confirming before popping
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(MEDPatientBaseConstants.ConfirmationAlertTitle, message: MEDPatientBaseConstants.SaveDataAlertMsg, okTitle: AlertViewButtonTitle.NoButtonTitle, cancelTitle: AlertViewButtonTitle.YesButtonTitle, prefereredStyle: UIAlertControllerStyle.Alert, tag:AlertViewTag.AlertViewTagForBackButton.rawValue)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    override func initialSetUp(bgImage: String) {
        setNavigationBackButtonImage()
        if (patientInfo?.caseID == nil) {
        addGeneralPatientInfoScreen()
        self.screenTag = ScreenTag.Step1
        highlightedButton = self.step1ButtonOutlet
        highlightStepButton(self.step1ButtonOutlet)
        } else {
            self.containerView.subviews.forEach { $0.removeFromSuperview() }
            if (patientInfo?.patientHistory?.diastolic != nil && patientInfo?.patientHistory?.diastolic?.isEmpty == false) {
                normalizeStepButtonSize(self.step1ButtonOutlet)
                normalizeStepButtonSize(self.step2ButtonOutlet)
                highlightedButton = self.step3ButtonOutlet
                self.step2ButtonOutlet.selected=true
                highlightStepButton(self.step3ButtonOutlet)
                addECGPreviewScreen()

            } else if(patientInfo?.firstName != nil) {
                normalizeStepButtonSize(self.step1ButtonOutlet)
                normalizeStepButtonSize(self.step3ButtonOutlet)
                addPatientHistoryScreen()
                highlightedButton = self.step2ButtonOutlet
                self.screenTag = ScreenTag.Step2
                highlightStepButton(self.step2ButtonOutlet)

            } else {
                highlightedButton = self.step1ButtonOutlet
                normalizeStepButtonSize(self.step2ButtonOutlet)
                normalizeStepButtonSize(self.step3ButtonOutlet)
                highlightStepButton(self.step1ButtonOutlet)

                addGeneralPatientInfoScreen()
            }

        }
    }

    func highlightStepButton(button: UIButton) {
        button.selected = true
        if(button.frame.origin.y==9) {
            button.frame.origin.y = 7
            if(button == self.step1ButtonOutlet) {
                self.stepOneBtnWidth.constant=28.0
                 self.stepOneBtnheight.constant=28.0

            } else  if(button == self.step2ButtonOutlet) {
                self.stepTwoBtnHeight.constant=28.0
                self.stepTwoBtnWidth.constant=28.0
            } else {
            self.stepThreeBtnWidth.constant=28.0
            self.stepThreeBtnHeight.constant=28.0
            }
        }

        self.view.layoutIfNeeded()
    }


    func normalizeStepButtonSize(button: UIButton) {

        if(button.frame.origin.y==7) {
            button.frame.origin.y = 9
            button.frame.origin.x = button.frame.origin.x+4
            button.frame.size.width = 24
            button.frame.size.height = 24
            if(button == self.step1ButtonOutlet) {
                self.stepOneBtnWidth.constant=24
                self.stepOneBtnheight.constant=24

            } else  if(button == self.step2ButtonOutlet) {
            self.stepTwoBtnHeight.constant=24
            self.stepTwoBtnWidth.constant=24
        } else {
            self.stepThreeBtnWidth.constant=24
            self.stepThreeBtnHeight.constant=24
        }

        }
    }



    func addGeneralPatientInfoScreen() {
        patientInfoScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.generalInfoViewControllerScreenSBID) as? MEDPatientGeneralInfoViewController
        patientInfoScreen!.patientInfo = patientInfo
        self.addChildViewController(patientInfoScreen!)
        if shouldAnimate {
            patientInfoScreen!.view.frame = CGRectMake(-self.view.frame.width, 0, self.containerView.frame.width, self.containerView.frame.height)
        } else {
             patientInfoScreen!.view.frame = CGRectMake(0, 0, self.containerView.frame.width, self.containerView.frame.height)
        }
        self.containerView.addSubview(patientInfoScreen!.view)
        UIView.animateWithDuration(0.5, animations: {
            self.view.userInteractionEnabled = false
            self.patientInfoScreen!.view.frame.origin.x = 0
            }, completion: {(value: Bool) in
                self.view.userInteractionEnabled = true
                if self.patientHistoryScreen != nil {
                self.patientHistoryScreen!.view.removeFromSuperview()
            } else {
                self.ecgViewControllerScreen?.view.removeFromSuperview()
                }
                self.patientHistoryScreen = nil
                self.ecgViewControllerScreen = nil
            })
        patientInfoScreen!.didMoveToParentViewController(self)
        invalidateTimer()
        self.title = "Patient Information"
        screenTag = ScreenTag.Step1
           }
    func addPatientHistoryScreen() {
        patientHistoryScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.patientHistoryScreenSBID) as? MEDPatientHistoryViewController
        patientHistoryScreen!.patientInfo = patientInfo
        self.addChildViewController(patientHistoryScreen!)
         if shouldAnimate {
        patientHistoryScreen!.view.frame = CGRectMake(self.view.frame.width, 0, self.containerView.frame.width, self.containerView.frame.height)
            setInitialPositionOfPatientHistoryBeforeAnimation(patientHistoryScreen!.view)
         } else {
            patientHistoryScreen!.view.frame = CGRectMake(0, 0, self.containerView.frame.width, self.containerView.frame.height)
        }
        self.containerView.addSubview(patientHistoryScreen!.view)
        UIView.animateWithDuration(0.5, animations: {
            self.view.userInteractionEnabled = false
            self.patientHistoryScreen!.view.frame.origin.x = 0
            }, completion: {(value: Bool) in
                self.view.userInteractionEnabled = true
                if self.patientInfoScreen != nil {
                    self.patientInfoScreen!.view.removeFromSuperview()
                } else {
                    self.ecgViewControllerScreen?.view.removeFromSuperview()
                }
                self.patientInfoScreen = nil
                self.ecgViewControllerScreen = nil
        })
        patientHistoryScreen!.didMoveToParentViewController(self)
        invalidateTimer()
        self.title = "Clinical Examination"
        screenTag = ScreenTag.Step2


    }

      func addECGPreviewScreen() {
         ecgViewControllerScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgViewControllerSBID) as? MEDPatientECGViewController
        ecgViewControllerScreen!.patientInfo = patientInfo
        self.addChildViewController(ecgViewControllerScreen!)
          if shouldAnimate {
        ecgViewControllerScreen!.view.frame = CGRectMake(self.containerView.frame.width, 0, self.containerView.frame.width, self.containerView.frame.height)
          } else {
            ecgViewControllerScreen!.view.frame = CGRectMake(0, 0, self.containerView.frame.width, self.containerView.frame.height)
        }
        self.containerView.addSubview(ecgViewControllerScreen!.view)
        UIView.animateWithDuration(0.5, animations: {
            self.view.userInteractionEnabled = false
            self.ecgViewControllerScreen!.view.frame.origin.x = 0
            }, completion: {(value: Bool) in
                self.view.userInteractionEnabled = true
                if self.patientHistoryScreen != nil {
                    self.patientHistoryScreen!.view.removeFromSuperview()
                } else {
                    self.patientInfoScreen?.view.removeFromSuperview()
                }

                self.patientHistoryScreen = nil
                self.patientInfoScreen = nil

        })
        ecgViewControllerScreen!.didMoveToParentViewController(self)
        startTimer()
        screenTag = ScreenTag.Step3
        }
    func setInitialPositionOfPatientHistoryBeforeAnimation(view: UIView) {
        if patientInfoScreen != nil {
            // Left To right Animation
            view.frame.origin.x = self.view.frame.size.width
        } else {
            // right To left animation
            view.frame.origin.x = -self.view.frame.size.width
        }

    }

    func saveUnsavedData() {

        if let _ = self.patientHistoryScreen {
            // Save patient history data
            patientHistoryScreen?.saveData()
        } else if let _ = self.ecgViewControllerScreen {
            // Save patient ecg data
            ecgViewControllerScreen!.updateTimeLineInfo()
            // saving image
            if let ecgReportImage = ecgViewControllerScreen?.ecgImage {
                self.ecgImage = ecgReportImage
            }
        } else {
            // General Info
            let vc = patientInfoScreen
            vc?.saveData()
        }
    }
}
// MARK: - AlertView delegates
extension MEDPatientBaseContainerView: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        let alertTag =  alertController.view.tag
        switch alertTag {
        case AlertViewTag.AlertViewTagForBackButton.rawValue:
            if patientInfo != nil {
            DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
            self.navigationController?.popViewControllerAnimated(true)
            }
        default:
            break
        }
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)

    }
    func defaultButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
        self.navigationController?.popViewControllerAnimated(true)
    }

}

// MARK: - @IBAction Actions
extension MEDPatientBaseContainerView {
    @IBAction func stepButtonAction(sender: AnyObject) {
        self.view.endEditing(true)
        switch sender.tag {
        case PaginationButtonTag.Page1.rawValue:
            if self.highlightedButton == self.step1ButtonOutlet {
                return
            }
            normalizeStepButtonSize(self.step2ButtonOutlet)
            normalizeStepButtonSize(self.step3ButtonOutlet)
            highlightedButton = self.step1ButtonOutlet
                saveUnsavedData()
                addGeneralPatientInfoScreen()
            highlightStepButton(sender as! UIButton)


        case PaginationButtonTag.Page2.rawValue:
            if self.highlightedButton == self.step2ButtonOutlet {
                return
            }
            if (patientInfo?.caseID != nil && patientInfo?.firstName != nil ) {
                normalizeStepButtonSize(self.step1ButtonOutlet)
                normalizeStepButtonSize(self.step3ButtonOutlet)
                highlightedButton = self.step2ButtonOutlet
                    saveUnsavedData()
                    addPatientHistoryScreen()
                highlightStepButton(sender as! UIButton)

            }

        case PaginationButtonTag.Page3.rawValue:
            if self.highlightedButton == self.step3ButtonOutlet {
                return
            }
            if (patientInfo?.caseID != nil && patientInfo?.patientHistory?.diastolic != nil && patientInfo?.patientHistory?.diastolic != "") {
                normalizeStepButtonSize(self.step1ButtonOutlet)
                normalizeStepButtonSize(self.step2ButtonOutlet)
                highlightedButton = self.step3ButtonOutlet
                    saveUnsavedData()
                    addECGPreviewScreen()
                highlightStepButton(sender as! UIButton)

            }

        default:
            break
        }
    }

}
