//  MEDPatientHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
extension MEDPatientECGViewController {

    func getAWSBucketInformation(upload: Bool) {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    if(upload == true){
                        self.startUploadingOfImage()}
                    else{
                        self.downloadECGImage()
                    }

                } else {

                }
            })
        })
    }
    func downloadImage(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String) {
        AWSTransferManager.sharedTransferManager.downloadImageRequest(patientInfo, imageURL: imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.updateECGImage()
                } else {
                    self.handleDownloadError()

                }
            })
        })
    }
    func uploadImage(patientInfo: PatientInfo, imageURL: NSURL, s3UploadKeyName: String) {
        checkInternet()
        AWSTransferManager.sharedTransferManager.uploadImageRequest(patientInfo, imageURL: imageURL, s3UploadKeyName: s3UploadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    //Store this url in db ecg info
                    self.handleUplaodResponse()
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    func postPatientECGInfoDetails() {
        checkInternet()
        APIRequest.sharedAPI.updatePatientECGInfo(patientInfo: patientInfo!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.handleBottonButtonActionResponse()
                     self.previousState = self.patientInfo?.caseStatus

                } else {
                    self.patientInfo?.caseStatus = self.previousState
                    super.handleError(error)

                }
            })
        })
    }

    func performGetCASEDetails(selectedPatientInfo: PatientInfo) {
        checkInternet()
        if  selectedPatientInfo.caseID != nil {
            let dict = [PatientInfoKey.CaseID.rawValue:selectedPatientInfo.caseID as! AnyObject
            ]
            APIRequest.sharedAPI.getCASEDetails(dictionary:dict, patientInfo:selectedPatientInfo, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                     self.navigateToViewSummary(selectedPatientInfo)
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                })
            })
        }}

}
