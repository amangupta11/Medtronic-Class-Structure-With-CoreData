//  MEDPatientECGPreviewViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDPatientECGPreviewViewController: MEDBaseViewController, UIScrollViewDelegate {
    @IBOutlet weak var imageView: UIImageView!
    var newImageView: UIImageView!
    var scrollView: UIScrollView!
    var ecgImage: UIImage!

     struct ECGPreviewStringConstants {
        static var imageTitle = "ECG"
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")

    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }

    func addImageView() {
        self.view.backgroundColor = UIColor.whiteColor()
        scrollView = UIScrollView(frame:CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        scrollView.backgroundColor = UIColor.blackColor()
        scrollView.delegate = self
        scrollView.contentMode = UIViewContentMode.ScaleAspectFit
        scrollView.maximumZoomScale = 4.0
        scrollView.minimumZoomScale = 1.0
        view.addSubview(scrollView)

        newImageView = UIImageView(image: self.ecgImage)

        newImageView.backgroundColor = UIColor.blackColor()
        newImageView.contentMode =  .ScaleAspectFit
        newImageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height-44)
        newImageView.userInteractionEnabled = true
        scrollView.addSubview(newImageView)
    }
    func toggle(sender: AnyObject) {
        if(self.navigationController?.navigationBar.hidden==true) {
            self.navigationController?.navigationBar.hidden=false
            self.view.backgroundColor=UIColor.whiteColor()
        } else {

            self.navigationController?.navigationBar.hidden=true
            self.view.backgroundColor=UIColor.blackColor()
        }
    }
    func cancelButton(sender: AnyObject) {
        scrollView.removeFromSuperview()
        self.navigationController?.navigationBar.backgroundColor=UIColor.blackColor()
        self.navigationController?.navigationBar.items = nil
    }
    func galleryButton(sender: AnyObject) {

    }
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return newImageView
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
// MARK: - Custom Actions
extension MEDPatientECGPreviewViewController {
    override func initialSetUp(bgImage: String) {
        setNavigationBackButtonImage()
        addImageView()

}

}
