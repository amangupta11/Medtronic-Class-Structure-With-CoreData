//  MEDPatientECGViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

enum StemiActivationTag: Int {
    case activateStemi = 3
    case diagnoseECG = 2
    case notAStemi = 10
}

struct ECGPreviewConstants {

    static  var SaveDataAlertMsg            = NSLocalizedString("YOU_WILL_LOSE_UNSAVEDDATA_WOULD _YOU_LIKE_TO_CONTINUE", comment: "")
    static var ConfirmationAlertTitle       = NSLocalizedString("CONFIRMATION", comment: "")
    static var ActivateNotAStemiAlertMsg    = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_MARK_THIS_AS_NOT_A_STEMI", comment: "")
    static var ActivateStemiAlertMsg        = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_ACTIVATE_STEMI", comment: "")
    static var diagnoseECGAlertMsg          = NSLocalizedString("ARE_YOU_WANT_TO_SEND_THE_CASE_FOR_DIAGNOSIS", comment: "")
    static var notAStemiSuccessAlertMsg     = NSLocalizedString("THE_CASE_WAS_MARKED_AS_NOT_A_STEMI", comment: "")
    static var ECGTitle                     = NSLocalizedString("ECG", comment: "")
    static var STEMIComment = NSLocalizedString("CARDIOLOGIST_HAS_DIAGNOSED_CASE_AS_STEMI", comment: "")
    static var NotAStemiCommentString = NSLocalizedString("CARDIOLOGIST_HAS_DIAGNOSED_CASE_AS_NOT_A_STEMI", comment: "")

}
enum InfractAreaTag: Int {
    case anteroseptal = 0
    case anterior = 1
    case lateral = 2
    case extensiveanterolateral = 3
    case inferior = 4
    case posterior = 5
    case rightsided = 6
    case leftmainstem = 7
    case other = 8
    case otherComments = 9
}

class MEDPatientECGViewController: MEDCameraLauncher {
    @IBOutlet weak var scrollContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var scrollContainerView: UIView!
    @IBOutlet weak var topScrollViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var topViewOfScrollView: UIView!
    @IBOutlet weak var cardioCommentsLabel: UILabel!
    @IBOutlet weak var captureECGCameraIcon: UIButton!
    @IBOutlet weak var imageViewShadowImage: UIImageView!
    @IBOutlet weak var infractAreaTableView: UITableView!
    @IBOutlet weak var captureImageContainerView: UIView!
    @IBOutlet weak var notStemiButtonOutlet: UIButton!
    @IBOutlet weak var stemiButtonOutlet: UIButton!
    @IBOutlet weak var diagnoseButtonOutelt: UIButton!
    @IBOutlet weak var imageDownloadingButton: UIButton!
    @IBOutlet weak var ecgReportImageView: UIImageView!
    @IBOutlet weak var smallCameraLogoButtonOutlet: UIButton!
    @IBOutlet weak var commentContainerView: UIView!
    @IBOutlet weak var commentContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var commentContainerViewYConstraint: NSLayoutConstraint!
    var otherCommentsPlaceholderLabel: UILabel!
    let defaultCommentViewRowHeight = 135
    let defaultScrollContainerViewHeight = 720
    var otherCommentsTextView: UITextView? = nil
    var ecgImage: UIImage!
    var stemiActivationTag: StemiActivationTag!
    var previousState: String!

    var isTextViewMarkedRed = false
    var infractAreaArray: NSMutableArray!
    var AWStag: Int = 0

    var  fileName: String! = nil
    var  fileURL: String! = nil

    struct ECGControllerStringConstants {
        static  var CellIdentifier = StringConstants.CellIdentifier
        static var CellIdentifierForOtherComments = StringConstants.CellIdentifierForOtherComments
       
        static var InfractAreaNameKey = StringConstants.InfractAreaNameKey
        static var StElevationNameKey = StringConstants.StElevationNameKey
        static var OtherCommentsText = StringConstants.OtherCommentsText
        static var otherCommentsCellBGImageKey = StringConstants.otherCommentsCellBGImageKey
    }

    // MARK: - UIView life cycle Actions


    enum BottomButtonTags: Int {
        case Diagnose = 101
        case NotAStemi = 102
        case Stemi = 103
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
        handleCardioCommentView()
        self.updateUI()
        handleBottomButtonPresentation()
    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)

    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    
    
  

}
// MARK: - Custom Actions
extension MEDPatientECGViewController {
    func validateFields() -> Bool {
        if(ecgReportImageView.image == nil) {
            let alertClass = AlertController()
            let alertController = alertClass.showSimpleAlert(NSLocalizedString("ALERT", comment: ""), message:NSLocalizedString("PLEASE_ADD_ECG_TO_THE_CASE_DETAILS", comment: ""), preferredStyle: UIAlertControllerStyle.Alert)
            self.presentViewController(alertController, animated: true, completion: {
            })
            return false
        }
        var isValid = true
        if (infractAreaArray.count > 0) {
        let dict = infractAreaArray.objectAtIndex(self.infractAreaArray.count - 1) as? NSMutableDictionary
        if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == true {
            if (self.otherCommentsTextView?.text == "") {
                let indexPath = NSIndexPath(forRow: 0, inSection: self.infractAreaArray.count - 1)
                self.infractAreaTableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: UITableViewScrollPosition.Bottom, animated: true)
                self.highlightOtherCommentsTextView(self.otherCommentsTextView!)
                isValid = false
                self.isTextViewMarkedRed = true
            } else {
                if let _ = self.otherCommentsTextView {
                    normalizeOtherCommentsTextView(self.otherCommentsTextView!)
                }
            }
        }
        }
        return isValid
    }
    func highlightOtherCommentsTextView(textView: UITextView) {
        textView.layer.borderColor = UIColor.redColor().CGColor
        textView.layer.borderWidth = 0.5

    }
    func normalizeOtherCommentsTextView(textView: UITextView) {
        textView.layer.borderColor = ColorPicker.lightBlueGray2().CGColor
        textView.layer.borderWidth = 1
    }

    func updateUI() {

        //Take values from here and update the UI
        var infractKeys = [patientInfo?.patientHistory?.anteroseptal, patientInfo?.patientHistory!.anterior, patientInfo?.patientHistory!.lateral, patientInfo?.patientHistory!.extensiveanterolateral, patientInfo?.patientHistory!.inferior, patientInfo?.patientHistory!.posterior, patientInfo?.patientHistory!.rightsided, patientInfo?.patientHistory!.leftmainstem, patientInfo?.patientHistory!.others]

        for i in 0..<self.infractAreaArray!.count {
            let dict = self.infractAreaArray!.objectAtIndex(i).mutableCopy()
            dict.setValue(infractKeys[i]?.boolValue, forKey: StringConstants.IsChecked)
            self.infractAreaArray!.replaceObjectAtIndex(i, withObject: dict as! NSDictionary)

        }

        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            // Update the UI in read only mode
            infarctAreasForReadOnlyMode()
            self.smallCameraLogoButtonOutlet.hidden = true
            handleScrollContainerViewHeight()
            self.captureECGCameraIcon.hidden = true
        } else if patientInfo?.caseStatus == status.UnderObservation.rawValue {
            self.handleScrollContainerViewHeight()
        }

        // storing the textview Comments
        if (self.infractAreaArray.count > 0) {
            if let _ = self.patientInfo?.patientHistory?.otherscomments {
                let otherCommentsDict = self.infractAreaArray.objectAtIndex(self.infractAreaArray.count-1).mutableCopy()
                otherCommentsDict.setValue(patientInfo!.patientHistory!.otherscomments, forKey: ECGControllerStringConstants.OtherCommentsText)
                self.infractAreaArray.replaceObjectAtIndex(self.infractAreaArray.count-1, withObject: otherCommentsDict as! NSDictionary)
            } else {
                let otherCommentsDict = self.infractAreaArray.objectAtIndex(self.infractAreaArray.count-1).mutableCopy()
                otherCommentsDict.setValue(nil, forKey: ECGControllerStringConstants.OtherCommentsText)
                self.infractAreaArray.replaceObjectAtIndex(self.infractAreaArray.count-1, withObject: otherCommentsDict as! NSDictionary)
            }
        }



        // image presentation

        let vc = self.parentViewController as! MEDPatientBaseContainerView


        if let _ = vc.ecgImage {
            // Stopping the downloading button
            self.imageDownloadingButton.hidden = true
            self.ecgReportImageView.userInteractionEnabled = true
            self.ecgImage = vc.ecgImage
            self.setImageToImageView(self.ecgImage)
            showECGReportImageView()
        }
        // Reload the infract area table view
        self.infractAreaTableView.reloadData()
    }

    func infarctAreasForReadOnlyMode() {
        let updatedArray = NSMutableArray()
        for i in 0..<self.infractAreaArray!.count {
            let dict = self.infractAreaArray!.objectAtIndex(i).mutableCopy()
            if dict.valueForKey(StringConstants.IsChecked)?.boolValue == true {
                updatedArray.addObject(dict)
            }
        }
        self.infractAreaArray = updatedArray
    }

    func getImageFromDirectory(ecgFileName: String) {
        let caseID = patientInfo?.caseID
        let fileURL = NSURL(fileURLWithPath: String(format: "%@/%@", FileUtility.getECGFolder(caseID!), ecgFileName))
        if let imageData = NSData(contentsOfURL: fileURL) {
            let image = UIImage(data: imageData) // Here you can attach image to UIImageView
            self.ecgReportImageView.image = image
        }
        // Reload the infract area table view
        self.infractAreaTableView.reloadData()
    }
    func generateRandomNumber() -> CFString {
        let UniqueIdNumber = CFUUIDCreateString(nil, CFUUIDCreate(nil))
        return UniqueIdNumber
    }

    func configureCellData(cell: MEDPatientInfractAreaTableViewCell, indexpath: NSIndexPath) {
        let infractDict = infractAreaArray[indexpath.section] as? NSMutableDictionary
        cell.checkMarkButtonOutlet.tag = indexpath.section
        cell.checkMarkButtonOutlet.selected = false
        let dict = self.infractAreaArray.objectAtIndex(cell.checkMarkButtonOutlet.tag).mutableCopy() as? NSMutableDictionary
        if(dict![StringConstants.IsChecked]?.boolValue == true) {
            cell.checkMarkButtonOutlet.selected = true
        }

        cell.infractAreaLabel.text = infractDict?.valueForKey(ECGControllerStringConstants.InfractAreaNameKey) as? String
        cell.stElevationLabel.text = infractDict?.valueForKey(ECGControllerStringConstants.StElevationNameKey) as? String

        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            cell.infractAreaLabel.textColor = ColorPicker.steelGreyColor()
            cell.stElevationLabel.textColor = ColorPicker.steelGreyColor()
        }
    }

    func configureOtherCommentsCell(cell: MEDPatientInfractAreaTableViewCell, indexPath: NSIndexPath) {
        cell.otherCommentsCheckedButton.tag = indexPath.section
        let dict = infractAreaArray.objectAtIndex(self.infractAreaArray.count - 1) as? NSMutableDictionary
        if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == false {
            cell.otherCommentsTextView.hidden = true
            cell.otherCommentsCheckedButton.selected = false
            cell.otherCommentsCellBgImage.image = UIImage(named: "shadowImageBackground")
            self.isTextViewMarkedRed = false
        } else {
            cell.otherCommentsTextView.hidden = false
            cell.otherCommentsCheckedButton.selected = true
            cell.otherCommentsCellBgImage.image = UIImage(named: ECGControllerStringConstants.otherCommentsCellBGImageKey)
            let otherCommentsDict = self.infractAreaArray.objectAtIndex(self.infractAreaArray.count - 1).mutableCopy()

            if let commentString = otherCommentsDict.valueForKey(ECGControllerStringConstants.OtherCommentsText) {
                if commentString as! String == ""{
                    // Checking if the comment string is Empty
                    cell.otherCommentsPlaceholderLabel.hidden = false
                } else {
                cell.otherCommentsTextView.text = otherCommentsDict.valueForKey(ECGControllerStringConstants.OtherCommentsText) as! String
                cell.otherCommentsTextView.textColor = ColorPicker.lightBlackColor()
                }
            } else {
                    cell.otherCommentsPlaceholderLabel.hidden = false
            }

            if(cell.otherCommentsTextView.text == nil) {
                cell.otherCommentsPlaceholderLabel.hidden = false
            }
        }
        self.otherCommentsTextView = cell.otherCommentsTextView
        self.otherCommentsPlaceholderLabel = cell.otherCommentsPlaceholderLabel
        handleTextViewUI(cell.otherCommentsTextView)


        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            // Handle read only mode UI
            cell.otherCommentsLabel.textColor = ColorPicker.steelGreyColor()
            cell.otherCommentsTextView.textColor = ColorPicker.steelGreyColor()
            cell.otherCommentsTextView.editable = false
        }

    }
    func handleTextViewUI(textView: UITextView) {
        if self.isTextViewMarkedRed == false {
            self.normalizeOtherCommentsTextView(textView)
        } else {
            self.highlightOtherCommentsTextView(textView)
        }
    }
    func loadInfractAreas() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.infractAreaArray = metaDataPList.objectForKey("InfractAreaDetails")?.mutableCopy() as? NSMutableArray
        }
    }

    func otherCommentsCheckMarkButtonTapped(sender: UIButton) {
        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            // Do not allow to edit again
            return
        }
        let indexPath: NSIndexPath = NSIndexPath(forRow: 0, inSection: 0)
        self.infractAreaTableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: UITableViewScrollPosition.None, animated: true)
        if sender.selected == false {
            self.scrollContainerViewHeight.constant += 60
        } else {
            self.scrollContainerViewHeight.constant -= 60
        }
        self.updateDataSource(sender)
        UIView.performWithoutAnimation {
            self.infractAreaTableView.reloadRowsAtIndexPaths([ NSIndexPath(forRow: 0, inSection: self.infractAreaArray.count-1)], withRowAnimation: UITableViewRowAnimation.Top)
        }

        self.infractAreaTableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: UITableViewScrollPosition.Bottom, animated: true)

        // Hide and show the text view

    }
    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        tapGesture.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tapGesture)
        
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }

    func updateTimeLineInfo() {
        if(patientInfo?.caseStatus == status.Diagnosed.rawValue) {
            return
        }
        for i in 0..<infractAreaArray.count {
            let dict = self.infractAreaArray.objectAtIndex(i).mutableCopy()
            let isChecked = dict.valueForKey(StringConstants.IsChecked) as! Bool
            switch i {
            case InfractAreaTag.anteroseptal.rawValue:
                patientInfo?.patientHistory!.anteroseptal = isChecked

            case InfractAreaTag.anterior.rawValue:
                patientInfo?.patientHistory!.anterior = isChecked

            case InfractAreaTag.lateral.rawValue:
                patientInfo?.patientHistory!.lateral = isChecked

            case InfractAreaTag.extensiveanterolateral.rawValue:
                patientInfo?.patientHistory!.extensiveanterolateral = isChecked

            case InfractAreaTag.inferior.rawValue:
                patientInfo?.patientHistory!.inferior = isChecked

            case InfractAreaTag.posterior.rawValue:
                patientInfo?.patientHistory!.posterior = isChecked

            case InfractAreaTag.rightsided.rawValue:
                patientInfo?.patientHistory!.rightsided = isChecked

            case InfractAreaTag.leftmainstem.rawValue:
                patientInfo?.patientHistory?.leftmainstem = isChecked

            case InfractAreaTag.otherComments.rawValue:

                if (isChecked) {
                    patientInfo?.patientHistory!.others = isChecked
                } else {
                    patientInfo?.patientHistory!.otherscomments = ""
                }

            case InfractAreaTag.other.rawValue:
                patientInfo?.patientHistory?.others = isChecked

            default:
                break
            }
        }
        // Updating textview data
        if self.otherCommentsTextView?.text != nil {
            self.patientInfo!.patientHistory!.otherscomments = self.otherCommentsTextView!.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            if(self.patientInfo?.patientHistory?.otherscomments == "" ) {
                self.patientInfo?.patientHistory?.otherscomments = nil
            }
        }
    }
    func updateDataSource(sender: UIButton) {
        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            // Do not allow to edit again
            return
        }
        var isChecked = false
        switch sender.selected {
        case false:

            isChecked = true
            sender.selected = true

        case true:
            isChecked = false
            sender.selected = false

        }
        let dict = self.infractAreaArray.objectAtIndex(sender.tag).mutableCopy()
        dict.setValue(isChecked, forKey: StringConstants.IsChecked)
        print(self.infractAreaArray.objectAtIndex(sender.tag).valueForKey(StringConstants.IsChecked)?.boolValue)
        print(dict.valueForKey(StringConstants.IsChecked)?.boolValue)
        self.infractAreaArray.replaceObjectAtIndex(sender.tag, withObject: dict as! NSDictionary)
    }

    override func initialSetUp(bgImage: String) {
        self.setTapGestureForView()
        self.loadInfractAreas()
        setNavigationBackButtonImage()
        self.setTapActionOnImageView()
        previousState = patientInfo?.caseStatus
        patientInfo?.patientHistory?.isFreshUpload = false
        self.patientInfo?.editInfarctArea = false
        if(patientInfo?.caseStatus == status.Diagnosed.rawValue || patientInfo?.caseStatus == status.UnderObservation.rawValue) {
            fileName = patientInfo?.ecgInfo?.ecgFileName
            let caseID = patientInfo?.caseID
            fileURL = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), fileName)
            let vc = self.parentViewController as! MEDPatientBaseContainerView
            if let _ = vc.ecgImage{
           // Image is already there in local
            }else {
                showECGReportImageView()
                setDefaultECGImage()
                self.smallCameraLogoButtonOutlet.hidden = true
                self.getAWSBucketInformation(false)
                //            }
                self.showRetryButton(false, isRotating: true)
                handleUserInteractionForFields(false)
            }

        } else {
            handleUserInteractionForFields(true)

        }
    }

    func enableBottomButtons(isEnabled: Bool) {
        self.stemiButtonOutlet.enabled = isEnabled
        self.notStemiButtonOutlet.enabled = isEnabled
        self.diagnoseButtonOutelt.enabled = isEnabled
        
        if isEnabled == false{
            self.stemiButtonOutlet.alpha = 0.4
            self.notStemiButtonOutlet.alpha = 0.4
            self.diagnoseButtonOutelt.alpha = 0.4
        }else{
            self.stemiButtonOutlet.alpha = 1.0
            self.notStemiButtonOutlet.alpha = 1.0
            self.diagnoseButtonOutelt.alpha = 1.0
            
        }
    }
    func setDefaultECGImage() {
        // Setting default ecg image while downloading the ecg image
        self.ecgReportImageView.image = UIImage(named: "defaultECGImage")
    }
    func downloadECGImage() {
        // Clear all downloading
        
        //enableBottomButtons(false)
        AWSTransferManager.sharedTransferManager.cancelAllTask()
        self.smallCameraLogoButtonOutlet.hidden = true
        if NetworkUtil.isConnected() == false {
            showRetryButton(false, isRotating: false)
            return
        }else{
            showRetryButton(false, isRotating: true)
        }
        self.ecgReportImageView.userInteractionEnabled = false
        let downloadURL = String(format:"%@/%@/%@", ecgPath, (patientInfo?.caseID)!, (patientInfo?.ecgInfo?.ecgFileName)!)
        let fileName = String(format: "%@", (patientInfo?.ecgInfo?.ecgFileName)!)
        downloadImage(patientInfo!, imageURL: NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(fileName)), s3DownloadKeyName:downloadURL)
        //        }
    }

    func showRetryButton(isHide: Bool, isRotating: Bool) {
        self.imageDownloadingButton.hidden = isHide
        if isRotating == true {
            rotateView(self.imageDownloadingButton)
            self.imageDownloadingButton.userInteractionEnabled = false
        } else {
            self.imageDownloadingButton.userInteractionEnabled = true
            stopRotatingView(self.imageDownloadingButton)
        }
    }

    func rotateView(view: UIView, duration: Double = 1) {
        if view.layer.animationForKey(kRotationAnimationKey) == nil {
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")

            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = duration
            rotationAnimation.repeatCount = Float.infinity
            view.layer.addAnimation(rotationAnimation, forKey: kRotationAnimationKey)
        }
    }
    func stopRotatingView(view: UIView) {
        if view.layer.animationForKey(kRotationAnimationKey) != nil {
            view.layer.removeAnimationForKey(kRotationAnimationKey)
        }
    }

    // Function will be called when downloading interupts
    // Update the UI
    func handleDownloadError() {
        showRetryButton(false, isRotating: false)
    }

    // Function will be called when downloading happens successfully
    // Update the UI
    func updateECGImage() {
        //enableBottomButtons(true)
        if patientInfo?.caseStatus != status.Diagnosed.rawValue{
            self.smallCameraLogoButtonOutlet.hidden = false
        }
        self.ecgReportImageView.userInteractionEnabled = true
        showRetryButton(true, isRotating: false)
        let image    = UIImage(contentsOfFile: (patientInfo?.ecgInfo?.localPath)!)
        self.ecgImage = image
        self.ecgReportImageView.image = self.ecgImage

    }
    func handleUserInteractionForFields(enabled: Bool) {
        self.infractAreaTableView.scrollEnabled = false
        setUpCommentContainerView()
    }
    func setUpCommentContainerView() {
        self.cardioCommentsLabel.sizeToFit()
        self.commentContainerViewYConstraint.constant = -self.commentContainerView.frame.size.height
        self.commentContainerView.frame.origin.y = -self.commentContainerView.frame.size.height
        self.commentContainerView.clipsToBounds = true
        let vc = self.parentViewController as! MEDPatientBaseContainerView
        vc.view.bringSubviewToFront(vc.stepButtonContainerView)
    }
    func getNumberOfLines(label: UILabel) -> Int {
        var lineCount = 0
        let textSize = CGSizeMake(label.frame.size.width, CGFloat(Float.infinity))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(label.font.lineHeight))
        lineCount = rHeight/charSize
        return lineCount
    }

    func setTapActionOnImageView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(MEDPatientECGViewController.imageTapped(_:)))
        self.ecgReportImageView.userInteractionEnabled = true
        self.ecgReportImageView.addGestureRecognizer(tapGestureRecognizer)
    }

    func imageTapped(img: AnyObject) {
        //Present ecg preview controller screen to zoom in and out
        self.presenetECGImagePreviewScreen()
    }

    func cameraButtonTapped() {
        self.presentCamera()
    }
    func presenetECGImagePreviewScreen() {
        let ecgPreviewScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgPreviewScreenSBID) as? MEDPatientECGPreviewViewController
        let vc = self.parentViewController as! MEDPatientBaseContainerView
        ecgPreviewScreen?.ecgImage = self.ecgImage
        ecgPreviewScreen?.title = "ECG"
        vc.navigationController?.pushViewController(ecgPreviewScreen!, animated: true)
    }
    func setImageToImageView(image: UIImage) {
        self.ecgReportImageView.image = image
        fileName = FileUtility.getImageName()
        let caseID = patientInfo?.caseID
        let imageData = UIImageJPEGRepresentation(image, 0.8)


        let formatted1 = NSByteCountFormatter.stringFromByteCount(
            Int64(imageData!.length),
            countStyle: NSByteCountFormatterCountStyle.File
        )
        print(formatted1)

        FileUtility.createCaseIDFolder(FileUtility.getECGFolder(caseID!), caseID: caseID!)
        fileURL = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), fileName)
        NSFileManager.defaultManager().createFileAtPath(fileURL, contents: imageData, attributes: nil)
    }


    func showECGReportImageView() {
        self.ecgReportImageView.hidden = false
        self.imageViewShadowImage.hidden = false
        self.captureECGCameraIcon.hidden = true
        self.captureImageContainerView.hidden = false
        if patientInfo?.caseStatus != status.Diagnosed.rawValue {
            self.smallCameraLogoButtonOutlet.hidden = false
        } else {
            self.smallCameraLogoButtonOutlet.hidden = true
        }
    }

    func showActivateStemiAlert(alertTile: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: AlertViewButtonTitle.NoButtonTitle, cancelTitle: AlertViewButtonTitle.YesButtonTitle, prefereredStyle: UIAlertControllerStyle.Alert, tag:AlertViewTag.AlertViewTagForStemiButton.rawValue)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }

    func handleCardioCommentView() {
        if  patientInfo?.caseStatus == status.Diagnosed.rawValue {
            self.cardioCommentsLabel.text = patientInfo?.timeLine!.isStemi == true ? ECGPreviewConstants.STEMIComment : ECGPreviewConstants.NotAStemiCommentString
            self.animateCardioCommentsView()
        } else if patientInfo?.caseStatus == status.UnderObservation.rawValue {
            // Case is in under observation. Put comments to the label
            self.cardioCommentsLabel.text = patientInfo?.patientHistory?.uncleatECGComments
            self.animateCardioCommentsView()
        }
    }
    func animateCardioCommentsView() {
        // Move the comment view to show on the screen
        self.cardioCommentsLabel.sizeToFit()
        let numOfLines = self.getNumberOfLines(self.cardioCommentsLabel)
        self.commentContainerViewHeight.constant = 10 + CGFloat(numOfLines * 22)
        self.commentContainerView.frame.size.height = self.commentContainerViewHeight.constant
        self.commentContainerViewYConstraint.constant = -self.commentContainerView.frame.size.height
        self.view.layoutIfNeeded()
        self.commentContainerViewYConstraint.constant = 0
        self.topScrollViewHeightConstraint.constant = self.commentContainerViewHeight.constant
        self.view.setNeedsUpdateConstraints()
        UIView.animateWithDuration(1.0, delay: 0.5, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.5, options: .CurveEaseOut, animations: { self.view.layoutIfNeeded()}, completion: nil)
    }

    func handleBottomButtonPresentation() {
        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            if patientInfo?.timeLine?.isStemi == true {
                self.notStemiButtonOutlet.hidden = true
                self.diagnoseButtonOutelt.hidden = true
                self.stemiButtonOutlet.setTitle("Activate STEMI", forState: .Normal)
            } else {
                // Case is not a stemi
                self.stemiButtonOutlet.hidden = true
                self.diagnoseButtonOutelt.hidden = true
            }
        }
    }

    func handleScrollContainerViewHeight() {
        scrollContainerViewHeight.constant = CGFloat(defaultScrollContainerViewHeight) -  CGFloat((9 - infractAreaArray.count)*50) + commentContainerViewHeight.constant
        self.view.layoutIfNeeded()
    }


}
//MARK: - Keyboard Notification Handling
extension MEDPatientECGViewController {
    override func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.view.frame.origin.y = 0})
    }
    override func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                self.view.frame.origin.y = -keyboardSize.height+80})
        }
    }
}

// MARK: - tableView Delegate methods
extension MEDPatientECGViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.infractAreaArray.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.section == self.infractAreaArray.count - 1 {
            let dict = infractAreaArray.objectAtIndex(self.infractAreaArray.count - 1) as? NSMutableDictionary
            if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == false {
                return 50
            }
            if dict?.allKeys.count < 3 {
                // Checking if the last row has other comments section
                // Other comments section has only two keys, Othercomments text and isChecked  While others have 3 rows
                return  CGFloat(defaultCommentViewRowHeight)
            }
        }
        return 50
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! MEDPatientInfractAreaTableViewCell
        if cell.reuseIdentifier == ECGControllerStringConstants.CellIdentifier
        {
            self.updateDataSource(cell.checkMarkButtonOutlet)
        }
        else if cell.reuseIdentifier == ECGControllerStringConstants.CellIdentifierForOtherComments
        {
            otherCommentsCheckMarkButtonTapped(cell.otherCommentsCheckedButton)
        }
    }
    
}

// MARK: - TableView Datasourse methods

extension  MEDPatientECGViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            if patientInfo?.patientHistory!.others?.boolValue == true {
                if indexPath.section == self.infractAreaArray.count - 1 {
                    let cell = tableView.dequeueReusableCellWithIdentifier(ECGControllerStringConstants.CellIdentifierForOtherComments, forIndexPath: indexPath) as! MEDPatientInfractAreaTableViewCell

                    configureOtherCommentsCell(cell, indexPath: indexPath)
                    return cell
                }
            }
        } else {
            if indexPath.section == self.infractAreaArray.count - 1 {
                let cell = tableView.dequeueReusableCellWithIdentifier(ECGControllerStringConstants.CellIdentifierForOtherComments, forIndexPath: indexPath) as! MEDPatientInfractAreaTableViewCell
                configureOtherCommentsCell(cell, indexPath: indexPath)
                return cell
            }
        }
        let cell = tableView.dequeueReusableCellWithIdentifier(ECGControllerStringConstants.CellIdentifier, forIndexPath: indexPath) as! MEDPatientInfractAreaTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }

}
//MARK:- Image picker delegates
extension MEDPatientECGViewController {
    override  func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
        ActivityIndicatorView.sharedActivityView.showOverlay()
        let queue =
            dispatch_queue_create("cqueue.hoffman.jon",DISPATCH_QUEUE_CONCURRENT)
        dispatch_async(queue, {
            self.showCompressedImage(info)
        })
        }

    override func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func showCompressedImage(info:[String : AnyObject]){
       
        let data1 = UIImagePNGRepresentation((info[UIImagePickerControllerOriginalImage] as? UIImage)!)
        let formatted1 = NSByteCountFormatter.stringFromByteCount(
            Int64(data1!.length),
            countStyle: NSByteCountFormatterCountStyle.File
        )
        print(formatted1)
        
        self.ecgImage = self.compressImage((info[UIImagePickerControllerOriginalImage] as? UIImage)!)
        let data = UIImagePNGRepresentation(self.ecgImage)
        let formatted = NSByteCountFormatter.stringFromByteCount(
            Int64(data!.length),
            countStyle: NSByteCountFormatterCountStyle.File
        )
        print(formatted)
        dispatch_async(dispatch_get_main_queue(), {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            self.setImageToImageView(self.ecgImage)
            self.patientInfo?.patientHistory?.isFreshUpload = true
            self.ecgReportImageView.userInteractionEnabled = true
            self.patientInfo?.editInfarctArea = true
            self.showECGReportImageView()
        })
       
    }

    func compressImage(let image: UIImage) -> UIImage {
        var actualHeight = Float(image.size.height)
        var actualWidth = Float(image.size.width)
        let maxHeight = Float(actualHeight - 300)
        let maxWidth = Float(actualWidth - 300)
        var imageRatio = Float(actualWidth/actualHeight)
        let maxRatio = Float(maxWidth/maxHeight)
        let compressionQuality = Float( 0.05 )  // 50 percent compression
        if actualHeight > maxHeight || actualWidth > maxWidth {
            if imageRatio < maxRatio {
                //adjust width according to maxHeight
                imageRatio = maxHeight / actualHeight
                actualWidth = imageRatio * actualWidth
                actualHeight = maxHeight
            } else if imageRatio > maxRatio {
                imageRatio = maxWidth / actualWidth
                actualHeight = imageRatio * actualHeight
                actualWidth = maxWidth

            } else {
                actualHeight = maxHeight
                actualWidth = maxWidth
            }

        }

        let rect = CGRectMake(0.0, 0.0,
                              CGFloat(actualWidth), CGFloat(actualHeight))
        UIGraphicsBeginImageContext(rect.size)
        image.drawInRect(rect)
        let compressedImage =  UIGraphicsGetImageFromCurrentImageContext()
        let compressedImageData  = UIImageJPEGRepresentation(compressedImage,
                                                             CGFloat(compressionQuality))
        UIGraphicsEndImageContext()
        return UIImage(data: compressedImageData!)!
    }


}

//MARK:- Text view delegates
extension MEDPatientECGViewController: UITextViewDelegate {
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        textView.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textView)
        return true

    }
    func textViewDidBeginEditing(textView: UITextView) {
        self.otherCommentsPlaceholderLabel.hidden = true
    }
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text == ""{
        self.otherCommentsPlaceholderLabel.hidden = false
        }
    }
    func textViewDidChange(textView: UITextView) {
        let dict = self.infractAreaArray.objectAtIndex(self.infractAreaArray.count - 1).mutableCopy()
        if textView.text == "" {
            dict.setValue(nil, forKey: ECGControllerStringConstants.OtherCommentsText)
        } else {
            dict.setValue(textView.text, forKey: ECGControllerStringConstants.OtherCommentsText)
        }
        self.infractAreaArray.replaceObjectAtIndex(self.infractAreaArray.count-1, withObject: dict as! NSDictionary)
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
         let charSet =  NSCharacterSet.newlineCharacterSet()
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        // checking if typed character is new line character
        // Return false if yes
        if let _ = updatedString!.rangeOfCharacterFromSet(charSet) {
            return false
        }

        if updatedString?.characters.count > 140 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}
// MARK: - @IBAction Actions
extension MEDPatientECGViewController {
    @IBAction func bottomButtonAction(sender: AnyObject) {
        if validateFields() {
            updateTimeLineInfo()
            if NetworkUtil.isConnected() == false {
                showAlert( NSLocalizedString("NO_INTERNET_CONNECTION", comment: ""), alertMsg: NSLocalizedString("YOUR_REQUEST_COULD_NOT_BE_COMPLETED", comment: ""))
                return
            }
            switch sender.tag {
            case BottomButtonTags.Diagnose.rawValue:
                // Code for handling the diagnose button action
                patientInfo?.timeLine?.diagnoseECGTime = DateUtility.getCurrentTimeInGMT()
                stemiActivationTag = StemiActivationTag.diagnoseECG
                showActivateStemiAlert(ECGPreviewConstants.ConfirmationAlertTitle, alertMsg: ECGPreviewConstants.diagnoseECGAlertMsg)
            case BottomButtonTags.NotAStemi.rawValue:
                // Code for handling not a stemi button action
                patientInfo?.timeLine?.notAStemiTime = DateUtility.getCurrentTimeInGMT()
                stemiActivationTag = StemiActivationTag.notAStemi
                showActivateStemiAlert(ECGPreviewConstants.ConfirmationAlertTitle, alertMsg: ECGPreviewConstants.ActivateNotAStemiAlertMsg)

            case BottomButtonTags.Stemi.rawValue:
                // code for handling stemi button action
                patientInfo?.timeLine?.stemiTime = DateUtility.getCurrentTimeInGMT()
                stemiActivationTag = StemiActivationTag.activateStemi
                showActivateStemiAlert(ECGPreviewConstants.ConfirmationAlertTitle, alertMsg: ECGPreviewConstants.ActivateStemiAlertMsg)

            default:
                break
            }
            if patientInfo?.caseStatus == status.Diagnosed.rawValue {
            self.patientInfo?.editInfarctArea = false
            }
            //Server Call

        }
    }
    @IBAction func viewECGButtonTapped(sender: AnyObject) {
        presenetECGImagePreviewScreen()
    }
    @IBAction func cameraAction(sender: AnyObject) {
        self.cameraButtonTapped()
    }

    @IBAction func retryButtonClicked(sender: AnyObject) {
        downloadECGImage()
    }
}
//MARK: - Alert view delegates
extension MEDPatientECGViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {

        switch(stemiActivationTag.rawValue) {
        case StemiActivationTag.diagnoseECG.rawValue:
            patientInfo?.caseStatus = status.Undiagnosed.rawValue
        case StemiActivationTag.activateStemi.rawValue:
            patientInfo?.caseStatus = status.STEMI.rawValue
        case StemiActivationTag.notAStemi.rawValue:
            patientInfo?.caseStatus = status.NotAStemi.rawValue
        default:
            break
        }
        self.getAWSBucketInformation(true)
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)

        switch(stemiActivationTag.rawValue) {
        case StemiActivationTag.diagnoseECG.rawValue:
            self.performGetCASEDetails(patientInfo!)
        case StemiActivationTag.activateStemi.rawValue:
            self.performGetCASEDetails(patientInfo!)
        case StemiActivationTag.notAStemi.rawValue:
            if(self.navigationController?.viewControllers.first is MEDHomeViewController)
            {
                let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
                topViewController.shouldTableViewRefresh = true
            }
            self.navigationController?.popToRootViewControllerAnimated(true)
        default:
            break
        }
    }
}

//MARK: - Server Interation

extension MEDPatientECGViewController {
    func handleBottonButtonActionResponse() {
        var alertView: UIAlertController?

        let alertController = AlertController()
        alertController.delegate = self
        let title = "Success"

        var message = NSLocalizedString("CASE_SENT_FOR_DIAGNOSIS_SUCESSFULLY", comment: "")

        switch(stemiActivationTag.rawValue) {
        case StemiActivationTag.diagnoseECG.rawValue:
            message =  NSLocalizedString("CASE_SENT_FOR_DIAGNOSIS_SUCESSFULLY", comment: "")
        case StemiActivationTag.activateStemi.rawValue:
            message = NSLocalizedString("STEMI_ACTIVATED", comment: "")

        case StemiActivationTag.notAStemi.rawValue:
            message = NSLocalizedString("THE_CASE_WAS_MARKED_AS_NOT_A_STEMI", comment: "")

        default:
            break
        }
        alertView = alertController.showSimpleAlert(title, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func startUploadingOfImage() {
        patientInfo?.ecgInfo?.ecgFileName = fileName
        patientInfo?.ecgInfo?.localPath = fileURL
        let uploadURL = String(format:"%@/%@/%@", ecgPath, (patientInfo?.caseID)!, (patientInfo?.ecgInfo?.ecgFileName)!)
        // Perform Encryption
        patientInfo!.ecgInfo?.localPath = CryptoUtility.encryptTheFile(fileURL, key: patientInfo!.caseKey! as! String, patient: patientInfo!)
//        if (patientInfo?.patientHistory?.isFreshUpload == true) {
            uploadImage(patientInfo!, imageURL: NSURL.fileURLWithPath((patientInfo?.ecgInfo?.localPath)!), s3UploadKeyName: uploadURL)
//        } else {
//            handleUplaodResponse()
//        }
    }
    func handleUplaodResponse() {

        postPatientECGInfoDetails()
    }
    func navigateToViewSummary(patientInfo: PatientInfo) {

        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.viewSummaryScreenSBID) as! MEDViewSummaryViewController
        self.hidesBottomBarWhenPushed = false
        for viewController in (self.navigationController?.viewControllers)! {
            viewController.hidesBottomBarWhenPushed = false
        }
        vc.hidesBottomBarWhenPushed = false
        vc.patientInfo = patientInfo
        self.navigationController?.pushViewController(vc, animated: true)

    }
}
