//  MEDPatientValidations.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
// MARK: - RegixExpression Methods
class MEDPatientValidations: NSObject {
    class func validateFirstORLastName(text: String) -> Bool {
        let userNameRegex = "^[A-Za-z ]{0,30}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(text)
    }
    class  func isValidPassportORIc(userNameStr: String) -> Bool {
        let userNameRegex = "[A-Z0-9a-z]{0,15}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }
    class  func isValidPhoneNumber(userNameStr: String) -> Bool {
        let userNameRegex = "[0-9]{7,10}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }
    class func isValidAge(string: String!) -> Bool {
        let userNameRegex = "[1-9]{1}[0-9]{0,2}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(string)
    }
    class  func isValidText(userNameStr: String) -> Bool {
        let userNameRegex = "[0-9]{0,3}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }
    class  func isValidTextWithDecimal(userNameStr: String) -> Bool {
        let userNameRegex = "^[3-5][0-9][.][0-9]{0,4}||[3-5][0-9]{0,2}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }
    class  func isValidTextForTroponin(userNameStr: String) -> Bool {
        let userNameRegex = "^[0-9]{0,4}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }
    class  func isValidTextWithMaxTwoNum(userNameStr: String) -> Bool {
        let userNameRegex = "[0-9]{0,3}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(userNameStr)
    }

}
