//  MHImagesDataSource.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation

class MHImagesDataSource : NSObject {
    
    var arrImagesMHSource:[MHImageSourceInfo] =  []
    var patientInfo:PatientInfo?
    var collectionView:UICollectionView?
    
    init(arrImages: NSMutableArray!,patInfo: PatientInfo?, collView: UICollectionView) {
        super.init()
        self.patientInfo = patInfo
        self.collectionView = collView
        self.populateData(arrImages)
    }
    
    func numbeOfRows(index: Int) -> Int {
        return self.arrImagesMHSource.count
    }

    // MARK:- Populate Data
    func populateData(arrImages:NSArray) {
        
        arrImages.enumerateObjectsUsingBlock { (anObject, index, nil) in
            print("Object = \(anObject) & index = \(index)")
            
            let imageURL = "\(ecgPath)/\((self.patientInfo?.caseID)!)/\(anObject)"
            let imageInfo:MHImageSourceInfo = MHImageSourceInfo(url: imageURL,typeOfTransfer: MHImageTransferType.download)
            self.arrImagesMHSource.append(imageInfo)
            
            let filePathUrl = NSURL.fileURLWithPath(imageInfo.imageURL)
            imageInfo.fileName = filePathUrl.lastPathComponent!
            
            self.downloadImage(self.patientInfo!, imageURL: NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(filePathUrl.lastPathComponent!)), s3DownloadKeyName:imageInfo.imageURL, imageSource:imageInfo)
            
        }
        
        self.addCaptureImageIfRequired()
        
    }
    
    func captureImageCount() -> Int {
        
        var captureCount = 0
        
        for imageInfo:MHImageSourceInfo in arrImagesMHSource {
            
            if imageInfo.transferType == .upload {
                
                captureCount += 1
                
            }
            
        }
        
        return captureCount
        
    }
    
    func addCaptureImageIfRequired() {
        
        if patientInfo?.caseStatus == status.Completed.rawValue {
            if(self.arrImagesMHSource.count != 0){
                return}
            
        }
        
        if arrImagesMHSource.count < MedicalHistoryConstants.kMAXIMUM_COUNT_MH_IMAGES_SUPPORTED && arrImagesMHSource.last?.transferType != .capture  {
            
            let captureImage:MHImageSourceInfo = MHImageSourceInfo(url: nil,typeOfTransfer: MHImageTransferType.capture)
            self.arrImagesMHSource.append(captureImage)
            
        }
        
    }

    func deleteImageRecordAtIndex(deleteIndex:Int) {
    
        self.arrImagesMHSource.removeAtIndex(deleteIndex)
        self.addCaptureImageIfRequired()
        self.collectionView?.reloadData()
        
    }
    
    func retryDownloadForImageInfo (imageInfo:MHImageSourceInfo) {
        
        let filePathUrl = NSURL.fileURLWithPath(imageInfo.imageURL)
        
        imageInfo.downloadError = false
        self.collectionView?.reloadData()
        
        self.downloadImage((patientInfo)!, imageURL: NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(filePathUrl.lastPathComponent!)), s3DownloadKeyName: imageInfo.imageURL, imageSource: imageInfo)
        
    }
    
    func addCapturedImage(imageInfo:[String : AnyObject]) {
        
        self.arrImagesMHSource.removeLast()
        self.saveCaptureImageInfo(imageInfo)
        
    }
    
    func saveCaptureImageInfo(imageInfo:[String : AnyObject]) {
        
        let data1 = UIImagePNGRepresentation((imageInfo[UIImagePickerControllerOriginalImage] as? UIImage)!)
        let formatted1 = NSByteCountFormatter.stringFromByteCount(
            Int64(data1!.length),
            countStyle: NSByteCountFormatterCountStyle.File
        )
        print(formatted1)
        
        let ecgImage = self.compressImage((imageInfo[UIImagePickerControllerOriginalImage] as? UIImage)!)
        let data = UIImagePNGRepresentation(ecgImage)
        
        let formatted = NSByteCountFormatter.stringFromByteCount(
            Int64(data!.length),
            countStyle: NSByteCountFormatterCountStyle.File
        )
        print(formatted)
        patientInfo?.patientHistory?.isFreshUpload = true
        self.saveImageToDirectory(ecgImage)
        
        
    }
    
    func compressImage(let image: UIImage) -> UIImage {
                
        var actualHeight = Float(image.size.height)
        var actualWidth = Float(image.size.width)
        let maxHeight = Float(actualHeight - 300)
        let maxWidth = Float(actualWidth - 300)
        var imageRatio = Float(actualWidth/actualHeight)
        let maxRatio = Float(maxWidth/maxHeight)
        let compressionQuality = Float( 0.05 )  // 50 percent compression
        if actualHeight > maxHeight || actualWidth > maxWidth {
            if imageRatio < maxRatio {
                //adjust width according to maxHeight
                imageRatio = maxHeight / actualHeight
                actualWidth = imageRatio * actualWidth
                actualHeight = maxHeight
            } else if imageRatio > maxRatio {
                imageRatio = maxWidth / actualWidth
                actualHeight = imageRatio * actualHeight
                actualWidth = maxWidth
                
            } else {
                actualHeight = maxHeight
                actualWidth = maxWidth
            }
            
        }
        
        let rect = CGRectMake(0.0, 0.0,
                              CGFloat(actualWidth), CGFloat(actualHeight))
        UIGraphicsBeginImageContext(rect.size)
        image.drawInRect(rect)
        let compressedImage =  UIGraphicsGetImageFromCurrentImageContext()
        let compressedImageData  = UIImageJPEGRepresentation(compressedImage,
                                                             CGFloat(compressionQuality))
        UIGraphicsEndImageContext()
        return UIImage(data: compressedImageData!)!
    }
    
    func saveImageToDirectory(image: UIImage){

        let fileName:String = FileUtility.getImageName()
        let imageData = UIImageJPEGRepresentation(image, 0.8)
        
        FileUtility.createCaseIDFolder(FileUtility.getECGFolder((patientInfo?.caseID)!), caseID: (patientInfo?.caseID)!)
        
        let fileURL: String = String(format: "%@/%@", FileUtility.getECGFolder((patientInfo?.caseID)!), fileName)
        
        NSFileManager.defaultManager().createFileAtPath(fileURL, contents: imageData, attributes: nil)
        
        let imageInfo:MHImageSourceInfo = MHImageSourceInfo(url: fileURL,typeOfTransfer: .upload)
        imageInfo.localPath = fileURL
        imageInfo.imageCaptured = image
        imageInfo.fileName = fileName
        
        self.arrImagesMHSource.append(imageInfo)
        self.addCaptureImageIfRequired()
        self.collectionView?.reloadData()

    }

    func imagesFilePaths() -> [String] {
        
        var imagesNames: [String] = []

        for imageInfo:MHImageSourceInfo in arrImagesMHSource {
            
            if imageInfo.transferType != .capture {
                
                imagesNames.append(imageInfo.fileName)
            }
            
        }
        
        return imagesNames
        
    }
    
    func addImagesNamesInDictionary(mhDict: NSMutableDictionary) -> NSMutableDictionary {
        
        if self.arrImagesMHSource.count > 1 {
            
            mhDict.setValue(self.imagesFilePaths(), forKey: "medicalHistoryImages")
            
        } else {
            
            mhDict.setValue([], forKey: "medicalHistoryImages")
            
        }
        
        return mhDict
        
    }
    
    func downloadImage(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String, imageSource: MHImageSourceInfo) {
        
        AWSTransferManager.sharedTransferManager.downloadImageRequest(patientInfo, imageURL: imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                
                if successful {

                    let ecgFileName = imageURL.lastPathComponent
                    let caseID = patientInfo.caseID
                    if caseID != nil {
                        
                        let filePath = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), ecgFileName!)
                        imageSource.downloadError = false
                        imageSource.localPath = filePath
                        self.collectionView?.reloadData()
                        
                    }
                    
                } else {
                    
                    imageSource.downloadError = true
                    self.collectionView?.reloadData()

                }
                
            })
        })
    }

}

