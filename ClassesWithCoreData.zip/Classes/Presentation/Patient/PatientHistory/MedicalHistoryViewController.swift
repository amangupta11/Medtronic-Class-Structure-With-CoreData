//  MedicalHistoryViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MedicalHistoryViewController: MEDCameraLauncher,UIGestureRecognizerDelegate {
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var notesHeaderHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var notesContainerHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var additionalHeaderHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var medicalNotesContainerView: UIView!
    @IBOutlet weak var medicalHIstoryScrollView: UIScrollView!
    @IBOutlet weak var medicalHistoryNotesTextView: UITextView!
    @IBOutlet weak var medicalHistoryConditionsTableView: UITableView!
    @IBOutlet weak var additionalImgsCollectionView: UICollectionView!
    @IBOutlet weak var additionalImgCaptureView: UIImageView!
    var dataSourceMHImages:MHImagesDataSource!
    let identifier = "MHImgCellIdentifier"
    let identifierUpload = "MHIUploadCellIdentifier"
    var scrollOffset: CGPoint!
    var medicalNotes: String? = nil
    var medicalHistoryDict: NSMutableDictionary? = nil
    var isCaseEditable:Bool = true
    var authorizationAlert:Bool = false
    var isFromMedication:Bool = false
    var isExpTimeAvbl:Bool = false
    let kTABLEVIEW_CELL_HEIGHT:CGFloat = 50
    enum MedicalHistoryAlertViewTags: Int{
        case ImageDelete = 101
        case ConditionEditButtonTag =  601
        case MedicationEditButtonTag = 602
    }
    var currentAlertViewTag: MedicalHistoryAlertViewTags!
    enum MedicalHistoryStringConstants: String{
        case ConditionTableViewCellIdentifier = "medicalCondtionCustomCell"
        case MedicationTableViewCellIdentifier = "medicationCustomCell"
        case ConditionSectionHeaderTableViewCellIdentifier = "medicalConditionsSectionHeader"
        case MedicationHeaderTableViewCellIdentifier = "medicationSectionHeader"
    }
    struct StringConstants {
        static  var isChecked = "isChecked"
        static  var MedicalHistoryNotes = "medicalHistoryNotes"
        static  var MedicalHistoryConditions = "medicalHistoryConditions"
        static  var Image = "Image"
        static  var Id = "id"
        static  var SelectConditions = "Select Conditions"
        static  var SelectMedication = "Select Medication"
        static  var SelectConditionsMsg = "Conditions not added"
        static  var SelectMedicationMsg = "Medication not added"
        static  var NotesNotAddedMsg =  "Notes not added"
        static  var ImagesNotAddedMsg = "Images not added"
        static  var Value = "value"
        static  var MedicineDescription = "medicineDescription"
        static  var MedicineDose = "medicineDose"
        static  var Conditions = "CONDITIONS"
        static  var Medication = "MEDICATION"
        static  var PatientMedications = "patientMedications"
        static  var Medicines = "medicines"
        static var Medications = "medications"
        static var HistoryConditions = "Conditions"
        static var MedicineKey = "medicineKey"
        static var SelectedDosage = "selectedDosage"
    }
    @IBOutlet weak var captureAdditionalImageContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var constraintContentViewHeight: NSLayoutConstraint!
    var medicalConditionsArray: NSMutableArray!
    var medicationsArray: NSMutableArray!
    var medicalHistoryImagesArray: NSMutableArray?
    var dataArray = [AnyObject]()//NSMutableArray!
    var originalCollectionViewHeight:CGFloat = 0
    var arrangeDataArray: Bool = false
    var currentDeleteIndex:Int = 0
    var isMedicalHistoryDataChanged = false
    struct MedicalHisConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var Confirmation = NSLocalizedString("CONFIRMATION", comment: "")
        static  var SuccessAlertTitle = NSLocalizedString("SUCCESS", comment: "")
        static  var SuccessAlertMsg = NSLocalizedString("INFORMATION_SAVED_SUCCESSFULLY", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
        static  var ImageConfirmationMessage = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_DELETE_IMAGE", comment: "")
    }
    
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAWSBucketInformationToDownloadImage()
        initialSetup()
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        if (patientInfo?.caseStatus == status.Completed.rawValue || self.patientInfo?.caseStatus == status.Cancelled.rawValue) {
            self.isCaseEditable = false
            medicalHistoryNotesTextView.editable = false
        }
    }
    override func viewDidLayoutSubviews() {
        
        self.updateUIConstraints()
        
    }
    override func viewWillAppear(animated: Bool) {
        if(arrangeDataArray == true){
           arrangeTheDataArray()
        }
        self.medicalHistoryConditionsTableView.reloadData()
        self.calculateTableViewHeight()
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(0.01 * Double(NSEC_PER_SEC))), dispatch_get_main_queue()) { () -> Void in
            self.calculateTableViewHeight()
        }
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isMedicalHistoryDataChanged = self.isMedicalHistoryDataChanged
        super.viewWillAppear(animated)
        super.addKeyboardObserver(self)
        
    }
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        super.removeKeyBoardObserver(self)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

// MARK: - Custom Actions
extension MedicalHistoryViewController {
    func initialSetup(){
        setBorderOfNotesView(medicalHistoryNotesTextView)
        if (patientInfo?.caseStatus == status.Completed.rawValue || self.patientInfo?.caseStatus == status.Cancelled.rawValue) {
            medicalHistoryNotesTextView.userInteractionEnabled = false
            if(self.medicalNotes == "" || self.medicalNotes == nil){
                self.medicalHistoryNotesTextView.textColor = ColorPicker.silverColor()
                self.medicalHistoryNotesTextView.text = StringConstants.NotesNotAddedMsg}
            else{
                 self.medicalHistoryNotesTextView.text = self.medicalNotes
            }
        }
        else{
            self.medicalHistoryNotesTextView.text = self.medicalNotes
        }
        dataSourceMHImages = MHImagesDataSource(arrImages: self.medicalHistoryImagesArray,patInfo:patientInfo,collView: self.additionalImgsCollectionView)
        additionalImgsCollectionView.dataSource = self
        additionalImgsCollectionView.delegate = self
        additionalImgCaptureView.image = UIImage(named:ImageConstants.kNotesShadowImage)
        self.medicalHistoryConditionsTableView.estimatedRowHeight = kTABLEVIEW_CELL_HEIGHT
        self.medicalHistoryConditionsTableView.rowHeight = UITableViewAutomaticDimension
        medicalConditionsArray = NSMutableArray()
        medicationsArray = NSMutableArray()
        getMedicalHistoryCondtions()
        getMedications()
    }
    func updateUIConstraints() {
        if originalCollectionViewHeight <= 0 {
            captureAdditionalImageContainerViewHeight.constant = (self.view.frame.size.height / 5 )
            originalCollectionViewHeight = captureAdditionalImageContainerViewHeight.constant
        }
        calculateTableViewHeight()
    }
    
    func arrangeTheDataArray(){
        if(arrangeDataArray == true){
            if(self.isFromMedication == true ){
                arrangeTheMedicationsArray(self.dataArray)
            }
            else{
                arrangeTheMedicalConditionsArray(self.dataArray)
            }
        }
    }
    
    func arrangeTheMedicationsArray(medications:[AnyObject]){
        medicationsArray = NSMutableArray()
        for i in 0..<medications.count{
            let dict = medications[i] as! NSDictionary
            let checkedValue = dict[StringConstants.isChecked] as! Int
            if(checkedValue == 1){
                self.medicationsArray.addObject(dict)
            }
        }
    }
    
    func popViewController(){
        self.navigationController?.popViewControllerAnimated(true)
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKindOfClass(MEDViewSummaryViewController){
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    func arrangeTheMedicalConditionsArray(medicalCondtions:[AnyObject]){
        medicalConditionsArray = NSMutableArray()
        for i in 0..<medicalCondtions.count{
            let dict = medicalCondtions[i] as! NSDictionary
            let checkedValue = dict[StringConstants.isChecked] as! Int
            if(checkedValue == 1){
                self.medicalConditionsArray.addObject(dict)
            }
        }
    }
    
    func calculateTableViewHeight(){
        if(self.medicalConditionsArray?.count == 0 && self.medicationsArray?.count != 0){
            self.tableViewHeightConstraint.constant = self.medicalHistoryConditionsTableView.contentSize.height
            self.constraintContentViewHeight.constant = 5 + notesHeaderHeightConstraint.constant + notesContainerHeightConstraint.constant + additionalHeaderHeightConstraint.constant + self.medicalHistoryConditionsTableView.contentSize.height + captureAdditionalImageContainerViewHeight.constant;
        }
        else if(self.medicalConditionsArray?.count != 0 && self.medicationsArray?.count == 0){
            self.tableViewHeightConstraint.constant = self.medicalHistoryConditionsTableView.contentSize.height
            self.constraintContentViewHeight.constant = 5 + notesHeaderHeightConstraint.constant + notesContainerHeightConstraint.constant + additionalHeaderHeightConstraint.constant + self.medicalHistoryConditionsTableView.contentSize.height  + captureAdditionalImageContainerViewHeight.constant;
        }
        else if(self.medicalConditionsArray?.count == 0 && self.medicationsArray?.count == 0){
            self.tableViewHeightConstraint.constant = self.medicalHistoryConditionsTableView.contentSize.height
            self.constraintContentViewHeight.constant = 5 + self.medicalHistoryConditionsTableView.contentSize.height + notesHeaderHeightConstraint.constant + notesContainerHeightConstraint.constant + additionalHeaderHeightConstraint.constant + captureAdditionalImageContainerViewHeight.constant;
        }
        else{
            self.tableViewHeightConstraint.constant = self.medicalHistoryConditionsTableView.contentSize.height
            self.constraintContentViewHeight.constant = 5 + notesHeaderHeightConstraint.constant + notesContainerHeightConstraint.constant + additionalHeaderHeightConstraint.constant + self.medicalHistoryConditionsTableView.contentSize.height + captureAdditionalImageContainerViewHeight.constant;
        }
    }
    
    func saveMedicalHistory() {
        self.view.endEditing(true)
        let captureCount:Int = dataSourceMHImages.captureImageCount()
        if captureCount > 0 {
            self.getAWSBucketInformation(captureCount)
        } else {
            saveMedicalConditions()
        }
    }
    
    func presentImagePreviewScreen(image: UIImage) {
        let previewScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgPreviewScreenSBID) as? MEDPatientECGPreviewViewController
        previewScreen?.ecgImage = image
        previewScreen?.hidesBottomBarWhenPushed = true
        previewScreen?.title = StringConstants.Image
        self.parentViewController!.navigationController?.pushViewController(previewScreen!, animated: true)
    }

    func getMedicalHistoryCondtions(){
        print(self.medicalHistoryDict)
        let selectedMedicalHistoryConditions = (self.medicalHistoryDict?.objectForKey(StringConstants.HistoryConditions))! as? NSMutableArray
        let ConditionArray:[AnyObject] = self.medicalHistoryDict!.valueForKey(StringConstants.MedicalHistoryConditions) as! [AnyObject]
        if selectedMedicalHistoryConditions != nil {
            for i in 0..<selectedMedicalHistoryConditions!.count{
                let selectedCondition = selectedMedicalHistoryConditions!.objectAtIndex(i) as! String
                for j in 0..<ConditionArray.count{
                    let dict = ConditionArray[j] as! NSDictionary
                    let condition = dict[StringConstants.Id] as? String
                    if(selectedCondition == condition){
                        dict.setValue(true, forKey: StringConstants.isChecked)
                    }
                }
            }
                                        
        }
        self.arrangeTheMedicalConditionsArray(ConditionArray )
    }
    func getMedications(){
        let selectedMedications = (self.medicalHistoryDict?.objectForKey(StringConstants.Medications))! as? NSMutableArray
        let medicinesArray:[AnyObject] = self.medicalHistoryDict!.valueForKey(StringConstants.PatientMedications) as! [AnyObject]
        if selectedMedications != nil {
            for i in 0..<selectedMedications!.count{
                let selectedMedicine = selectedMedications?.objectAtIndex(i) as! NSDictionary
                let selectedMedicationDes = selectedMedicine.valueForKey(StringConstants.MedicineDescription)
                let selectedMedicationKey = selectedMedicine.valueForKey(StringConstants.MedicineKey)
                let selectedDose = selectedMedicine.valueForKey(StringConstants.MedicineDose)
                for j in 0..<medicinesArray.count{
                    let dict = medicinesArray[j] as! NSDictionary
                    let medication = dict[StringConstants.MedicineKey] as? String
                    if(String(selectedMedicationKey!) == medication){
                        dict.setValue(true, forKey: StringConstants.isChecked)
                        dict.setValue((selectedDose)?.integerValue, forKey: StringConstants.SelectedDosage)
                        dict.setValue(String(selectedMedicationDes!), forKey: StringConstants.MedicineDescription)
                    }
                }
            }
        }
       self.arrangeTheMedicationsArray(medicinesArray )
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    func addTapGestureRecognizer(view: UIView){
        let tap = UITapGestureRecognizer(target: self, action: #selector(MedicalHistoryViewController.handleTap(_:)))
        tap.delegate = self
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    func handleTap(sender: UITapGestureRecognizer? = nil) {
        // handling code
        self.view.endEditing(true)
    }
    
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(MedicalHisConstants.AlertTitle, message:MedicalHisConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func setBorderOfNotesView(textView: UITextView) {
        textView.layer.borderColor = ColorPicker.warmGreyColor2().CGColor
        textView.layer.borderWidth = 1
    }
    func saveMedicalConditions() {
        let medicalConditionsDict = NSMutableDictionary()
        medicalConditionsDict.setValue(patientInfo?.caseID, forKey: PatientInfoKey.CaseID.rawValue)
        medicalConditionsDict.setValue(self.medicalHistoryNotesTextView.text, forKey: StringConstants.MedicalHistoryNotes)
        let updatedConditionArray = NSMutableArray()
        let updatedMedicationArray = NSMutableArray()
        for condition in self.medicalConditionsArray!{
                updatedConditionArray.addObject(condition.valueForKey(StringConstants.Id)!)
        }
        for condition in self.medicationsArray!{
                print(condition)
                let medicationsDict = NSMutableDictionary()
                let selectedDosageIndex = condition.valueForKey(StringConstants.SelectedDosage) as? Int
                medicationsDict.setValue(condition.valueForKey(StringConstants.MedicineKey)!, forKey: StringConstants.MedicineKey)
                medicationsDict.setValue(String(selectedDosageIndex!), forKey: StringConstants.MedicineDose)
                medicationsDict.setValue(condition.valueForKey(StringConstants.MedicineDescription)!, forKey: StringConstants.MedicineDescription)
                updatedMedicationArray.addObject(medicationsDict)
        }
        medicalConditionsDict.setValue(updatedConditionArray, forKey: StringConstants.MedicalHistoryConditions)
        medicalConditionsDict.setValue(updatedMedicationArray, forKey: StringConstants.PatientMedications)
        let mhFinalDict = dataSourceMHImages.addImagesNamesInDictionary(medicalConditionsDict)
        self.setPatientMedicalHistory(mhFinalDict)
    }
    
    func uploadNewImages(captureCount: Int) {
        var completedCount:Int = 0
        let captureCount:Int = captureCount
        for imageInfo:MHImageSourceInfo in dataSourceMHImages.arrImagesMHSource {
            if imageInfo.transferType == .upload {
                let uploadURL = String(format:"%@/%@/%@", ecgPath, (patientInfo?.caseID)!, imageInfo.fileName)
                patientInfo?.ecgInfo?.localPath = imageInfo.localPath
                imageInfo.localPath = CryptoUtility.encryptTheFile(imageInfo.imageURL, key: patientInfo!.caseKey! as! String, patient: patientInfo!)
                self.uploadImage(patientInfo!, imageURL: NSURL.fileURLWithPath(imageInfo.localPath), s3UploadKeyName: uploadURL, completed: { (success, error) in
                    if success {
                        completedCount += 1
                        imageInfo.transferType = .download
                        if (completedCount >= captureCount) {
                            self.saveMedicalConditions()
                        }
                    } else {
                        super.handleError(error)
                    }
                })
            }
        }
    }
    
    func showSimpleAlert(alertTitle: String, message: String) {
        if self.presentedViewController is UIAlertController {
            return;
        }
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showSimpleAlert(alertTitle, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    
    func heightenCollectionView(expand:Bool) {
        let padding:CGFloat = 5
        if expand {
            self.captureAdditionalImageContainerViewHeight.constant = (originalCollectionViewHeight * 2) + (padding * 3)
        } else {
            self.captureAdditionalImageContainerViewHeight.constant = originalCollectionViewHeight + (padding * 2)
        }
    }
    
    func actionDeleteImage(sender: UIButton!) {
        currentDeleteIndex = sender.tag
        self.currentAlertViewTag = MedicalHistoryAlertViewTags.ImageDelete
        self.showAlertWithTwoButtons(MedicalHisConstants.Confirmation, alertMsg: MedicalHisConstants.ImageConfirmationMessage)
    }
    
    func actionRetryDownload (sender: UIButton!) {
        let imageSource:MHImageSourceInfo = dataSourceMHImages.arrImagesMHSource[sender.tag]
        dataSourceMHImages.retryDownloadForImageInfo(imageSource)
    }
    func calculateNumberOfRowsForSection(section:Int) -> Int{
        if(section == 0){
            if(self.medicalConditionsArray?.count == 0){
                return 1
            }else{
                return (self.medicalConditionsArray?.count)!
            }
        }
        else{
            if(self.medicationsArray?.count == 0){
                return 1
            }else{
                return (self.medicationsArray?.count)!
            }
        }
    }
    
    func navigateToTypeOfMethodsScreen(){
        let methodsVC : MethodsViewController = UIStoryboard(name: StroryBoardNameConstants.SBMedicalHistory, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.MethodsSBID) as! MethodsViewController
        methodsVC.medicalHistoryDataDict = self.medicalHistoryDict
        methodsVC.patientInfo = patientInfo
        methodsVC.isFromMedication = self.isFromMedication
        self.navigationController?.pushViewController(methodsVC, animated: true)
    }
    func headerButtonAction(sender: UIButton){
        let methodsVC : MethodsViewController = UIStoryboard(name: StroryBoardNameConstants.SBMedicalHistory, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.MethodsSBID) as! MethodsViewController
        methodsVC.medicalHistoryDataDict = self.medicalHistoryDict
        methodsVC.patientInfo = patientInfo
        if(sender.tag == MedicalHistoryAlertViewTags.ConditionEditButtonTag.rawValue){
            methodsVC.isFromMedication = false
            isFromMedication = false
        }
        else{
            methodsVC.isFromMedication = true
            isFromMedication = true
        }
        self.navigationController?.pushViewController(methodsVC, animated: true)
    }
    func addShadow(cell: MedicalHistoryTableViewCell) {
        cell.layer.shadowColor = UIColor.blackColor().CGColor
        cell.layer.shadowOpacity = 0.15
        cell.layer.shadowOffset = CGSizeMake(1, 1)
        cell.layer.masksToBounds = false
        cell.layer.shadowRadius = 2
    }
    func removeShadow(cell: MedicalHistoryTableViewCell) {
        cell.layer.shadowColor = UIColor.clearColor().CGColor
        cell.layer.shadowOpacity = 0
        cell.layer.masksToBounds = false
    }
    
    func cellForRowForConditionSection(cell: MedicalHistoryTableViewCell, indexPath:NSIndexPath, lastRowIndex:Int){
        if(self.medicalConditionsArray?.count == 0){
            if (patientInfo?.caseStatus == status.Completed.rawValue || self.patientInfo?.caseStatus == status.Cancelled.rawValue) {
                cell.medicalConditionLabel.text = StringConstants.SelectConditionsMsg
                cell.medicalConditionLabel.textColor = ColorPicker.silverColor()
                cell.selectionArrowImage.hidden = true
                cell.lineLabel.hidden = true
            }
            else{
                cell.medicalConditionLabel.text = StringConstants.SelectConditions
                cell.selectionArrowImage.hidden = false
                cell.lineLabel.hidden = true
            }
        }
        else{
            cell.selectionArrowImage.hidden = true
            cell.lineLabel.hidden = false
            let conditionDict = medicalConditionsArray![indexPath.row]
            cell.medicalConditionLabel.text = conditionDict.valueForKey(StringConstants.Value) as? String
        }
        if(indexPath.row == lastRowIndex - 1){
            cell.lineLabel.hidden = true
            addShadow(cell)
        }
        else{
            cell.lineLabel.hidden = false
        }
    }
    func cellForRowForMedicationSection(cell: MedicalHistoryTableViewCell, indexPath:NSIndexPath, lastRowIndex:Int){
        if(self.medicationsArray?.count == 0){
            if (patientInfo?.caseStatus == status.Completed.rawValue || self.patientInfo?.caseStatus == status.Cancelled.rawValue) {
                cell.medicalConditionLabel.text = StringConstants.SelectMedicationMsg
                cell.medicalConditionLabel.textColor = ColorPicker.silverColor()
                cell.selectionArrowImage.hidden = true
                cell.lineLabel.hidden = true
            }
            else{
                cell.medicalConditionLabel.text = StringConstants.SelectMedication
                cell.selectionArrowImage.hidden = false
                cell.lineLabel.hidden = true
            }
        }
        else{
            cell.selectionArrowImage.hidden = true
            cell.lineLabel.hidden = false
            let conditionDict = medicationsArray![indexPath.row]
            cell.medicalConditionLabel.text = conditionDict.valueForKey(StringConstants.MedicineDescription) as? String
            let selectedDosageIndex = conditionDict.valueForKey(StringConstants.SelectedDosage) as? Int
            let medicineDoseArray = conditionDict.objectForKey(StringConstants.MedicineDose) as? NSArray
            if(medicineDoseArray?.count != 0){
            let mgLabel = medicineDoseArray?.objectAtIndex(selectedDosageIndex!) as? String
            if(mgLabel != ""){
                cell.mgLabel.hidden = false
                cell.mgLabel.text = String(mgLabel!)
                cell.mgLabel.sizeToFit()
                cell.mgLabelLeadingConstraint.constant = (self.medicalHistoryConditionsTableView.frame.size.width - (cell.mgLabel.frame.size.width + 10))
                }
            }
        }
        if(indexPath.row == lastRowIndex - 1){
            cell.lineLabel.hidden = true
            addShadow(cell)
        }
        else{
            cell.lineLabel.hidden = false
        }
    }
    
}
//MARK:- Text view delegates
extension MedicalHistoryViewController: UITextViewDelegate {
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        textView.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textView)
        return true
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.becomeFirstResponder()
            return true
        }
        // Comments is getting changed
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isMedicalHistoryDataChanged = true
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        // checking if typed character is new line character
        // Return false if yes
        if updatedString?.characters.count > 250 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}

// MARK:- ALERT VIEW DELEGATES
extension MedicalHistoryViewController:AlertViewControllerProtocol {
    func showAlertWithTwoButtons(alertTitle: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTitle, message:alertMsg, okTitle: AlertViewButtonTitle.NoButtonTitle, cancelTitle: AlertViewButtonTitle.YesButtonTitle, prefereredStyle: UIAlertControllerStyle.Alert, tag:AlertViewTag.AlertViewTagForStemiButton.rawValue)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    
    func cancelButtonAction(alertController: UIAlertController) {
        switch(currentAlertViewTag.rawValue) {
        case MedicalHistoryAlertViewTags.ImageDelete.rawValue:
            // Image is getting deleted
            let parentController = self.parentViewController as! BasePatientHistoryViewController
            parentController.isMedicalHistoryDataChanged = true
            dataSourceMHImages.deleteImageRecordAtIndex(currentDeleteIndex)
            break
        default:
            break
        }
        
    }
    
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func defaultButtonAction(alertController: UIAlertController) {
        if (authorizationAlert == true){
            self.view.endEditing(true)
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
            else if isExpTimeAvbl{
            self.popViewController()
        }
        else{
            self.view.endEditing(true)
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    
}

//MARK:- Image picker delegates
extension MedicalHistoryViewController {
    override  func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        // image is getting changed
        self.isMedicalHistoryDataChanged = true
        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
        dataSourceMHImages.addCapturedImage(info)
    }
    override func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
    }
    
}

//MARK: - KEYBOARD NOTIFICATIONS
extension MedicalHistoryViewController{
    // MARK: - Keyboard Notification Handling
    override func keyboardWillShow(notification: NSNotification) {
        self.scrollOffset = self.medicalHIstoryScrollView.contentOffset
        let info : NSDictionary = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue().size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        self.medicalHIstoryScrollView.contentInset = contentInsets
        self.medicalHIstoryScrollView.scrollRectToVisible(self.medicalNotesContainerView.frame, animated: true)
    }
    override func keyboardWillHide(notification: NSNotification) {
        self.medicalHIstoryScrollView.contentInset = UIEdgeInsetsZero
        if self.scrollOffset != nil  {
            self.medicalHIstoryScrollView.contentOffset = self.scrollOffset
        }
    }
}


// MARK: - tableView Delegate methods
extension MedicalHistoryViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = UIView()
        view.backgroundColor = UIColor.clearColor()
        return view
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView:MedicalHistorySectionHeaderTableViewCell
        if(section == 0){
            headerView = tableView.dequeueReusableCellWithIdentifier(MedicalHistoryStringConstants.ConditionSectionHeaderTableViewCellIdentifier.rawValue)  as! MedicalHistorySectionHeaderTableViewCell
            headerView.label?.text = StringConstants.Conditions
            headerView.editButton.hidden = true
            if(self.medicalConditionsArray?.count != 0){
                if(patientInfo?.caseStatus == status.Completed.rawValue || patientInfo?.caseStatus == status.Cancelled.rawValue){
                    headerView.editButton.hidden = true
                }
                else{
                    headerView.editButton.hidden = false
                    headerView.editButton.tag = MedicalHistoryAlertViewTags.ConditionEditButtonTag.rawValue
                    headerView.editButton.addTarget(self, action:#selector(headerButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
                }
            }
        }
        else{
            headerView = tableView.dequeueReusableCellWithIdentifier(MedicalHistoryStringConstants.MedicationHeaderTableViewCellIdentifier.rawValue) as! MedicalHistorySectionHeaderTableViewCell
            headerView.label?.text = StringConstants.Medication
            headerView.editButton.hidden = true
            if(self.medicationsArray?.count != 0){
                if(patientInfo?.caseStatus == status.Completed.rawValue || patientInfo?.caseStatus == status.Cancelled.rawValue){
                    headerView.editButton.hidden = true
                }
                else{
                    headerView.editButton.hidden = false
                    headerView.editButton.tag = MedicalHistoryAlertViewTags.MedicationEditButtonTag.rawValue
                    headerView.editButton.addTarget(self, action:#selector(headerButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
                }
            }
        }
        return headerView
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 7
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 30
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 2
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return calculateNumberOfRowsForSection(section)
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if (patientInfo?.caseStatus == status.Completed.rawValue || self.patientInfo?.caseStatus == status.Cancelled.rawValue) {
            return
        }
        if(indexPath.section == 0){
            if(self.medicalConditionsArray?.count == 0){
                self.isFromMedication = false
                navigateToTypeOfMethodsScreen()
            }
        }
        else{
            if( self.medicationsArray?.count == 0){
                self.isFromMedication = true
                navigateToTypeOfMethodsScreen()
            }
        }
    }
}

// MARK: - TableView Datasourse methods

extension  MedicalHistoryViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:MedicalHistoryTableViewCell
        if(indexPath.section == 0){
            cell = tableView.dequeueReusableCellWithIdentifier(MedicalHistoryStringConstants.ConditionTableViewCellIdentifier.rawValue, forIndexPath: indexPath) as! MedicalHistoryTableViewCell
            let lastRowIndex = tableView.numberOfRowsInSection(indexPath.section)
            removeShadow(cell)
            cellForRowForConditionSection(cell, indexPath: indexPath, lastRowIndex: lastRowIndex)
        }
        else{
            cell = tableView.dequeueReusableCellWithIdentifier(MedicalHistoryStringConstants.MedicationTableViewCellIdentifier.rawValue, forIndexPath: indexPath) as! MedicalHistoryTableViewCell
            let lastRowIndex = tableView.numberOfRowsInSection(indexPath.section)
            removeShadow(cell)
            cell.mgLabel.hidden = true
            cellForRowForMedicationSection(cell, indexPath: indexPath , lastRowIndex: lastRowIndex)
        }
        return cell
    }
    
}

extension MedicalHistoryViewController : UICollectionViewDataSource {
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if dataSourceMHImages.numbeOfRows(0) >= MedicalHistoryConstants.kMAXIMUM_COUNT_MH_IMAGES_SUPPORTED {
            self.heightenCollectionView(true)
        } else {
            self.heightenCollectionView(false)
        }
        
        self.updateUIConstraints()
        return dataSourceMHImages.numbeOfRows(0)
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let imageSource:MHImageSourceInfo = dataSourceMHImages.arrImagesMHSource[indexPath.row]
        switch imageSource.transferType {
        case .capture:
            let uploadCell: MHUploadImageCell = collectionView.dequeueReusableCellWithReuseIdentifier(identifierUpload,forIndexPath:indexPath) as! MHUploadImageCell
            if(patientInfo?.caseStatus == status.Completed.rawValue || patientInfo?.caseStatus == status.Cancelled.rawValue){
                uploadCell.captureIcon.hidden = true
                uploadCell.label.text = StringConstants.ImagesNotAddedMsg
                uploadCell.label.textColor = ColorPicker.silverColor()
                uploadCell.label.hidden = false
                if(self.medicalHistoryImagesArray?.count != 0){
                    uploadCell.label.hidden = true
                }
            }
            return uploadCell
            
        case .upload:
            let downloadCell: AdditionalImageCell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier,forIndexPath:indexPath) as! AdditionalImageCell
            downloadCell.imageView.image = imageSource.imageCaptured
            downloadCell.deleteButton.hidden = false
            downloadCell.deleteButton.addTarget(self, action:#selector(actionDeleteImage), forControlEvents: .TouchUpInside)
            downloadCell.deleteButton.tag = indexPath.row
            return downloadCell
        case .download:
            let downloadCell: AdditionalImageCell = collectionView.dequeueReusableCellWithReuseIdentifier(identifier,forIndexPath:indexPath) as! AdditionalImageCell
            downloadCell.startRotation()
            downloadCell.deleteButton.tag = indexPath.row
            downloadCell.buttonActivity.tag = indexPath.row
            var image = UIImage(contentsOfFile: imageSource.localPath)
            if image == nil{
                image = CryptoUtility.decryptImage(imageSource.localPath, key: patientInfo!.caseKey! as! String, patient: patientInfo!)
            }
            if image != nil {
                downloadCell.stopRotation()
                downloadCell.imageView.image = image
                downloadCell.deleteButton.hidden = !isCaseEditable
                downloadCell.deleteButton.addTarget(self, action:#selector(actionDeleteImage), forControlEvents: .TouchUpInside)
                
            } else {
                downloadCell.resetCell()
                if imageSource.downloadError == true {
                    downloadCell.stopRotation()
                    downloadCell.buttonActivity.hidden = false
                    downloadCell.buttonActivity.userInteractionEnabled = true
                    downloadCell.buttonActivity.addTarget(self, action:#selector(actionRetryDownload), forControlEvents: .TouchUpInside)
                }
            }
            return downloadCell
        }
    }
}



// MARK:- UICollectionViewDelegate Methods

extension MedicalHistoryViewController : UICollectionViewDelegate {
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let cell:UICollectionViewCell = collectionView.cellForItemAtIndexPath(indexPath)!
        if cell is MHUploadImageCell {
            if(patientInfo?.caseStatus != status.Completed.rawValue && patientInfo?.caseStatus != status.Cancelled.rawValue){
                self.presentCamera()
            }
        } else if cell is AdditionalImageCell {
            if ((cell as! AdditionalImageCell).buttonActivity.hidden == true) {
                self.presentImagePreviewScreen((cell as! AdditionalImageCell).imageView.image!)
            }
        }
    }
}

extension MedicalHistoryViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
    {
        if(patientInfo?.caseStatus == status.Completed.rawValue || patientInfo?.caseStatus == status.Cancelled.rawValue){
            if(self.medicalHistoryImagesArray?.count == 0){
                let length = (collectionView.frame.size.width-30)/3
                return CGSizeMake(140 ,length);
            }
            let length = (collectionView.frame.size.width-30)/3
            return CGSizeMake(length ,length);
        }
        let length = (collectionView.frame.size.width-30)/3
        return CGSizeMake(length ,length);
    }
}


