//  MedicalHistoryTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MedicalHistoryTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var mgLabelLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var mgLabel: UILabel!
    @IBOutlet weak var lineLabel: UILabel!
    @IBOutlet weak var selectionArrowImage: UIImageView!
    @IBOutlet weak var medicalConditionLabel: UILabel!
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    override func layoutSubviews() {
    }
}
