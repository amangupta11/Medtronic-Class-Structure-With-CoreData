//  AdditionalImageCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation

import UIKit

class AdditionalImageCell: UICollectionViewCell {
    
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var buttonActivity: UIButton!
    
    var isRotating:Bool = false
    
    func stopRotation() {
        
        isRotating = false
        
        if self.buttonActivity.layer.animationForKey(kRotationAnimationKey) != nil {
            
            self.buttonActivity.layer.removeAnimationForKey(kRotationAnimationKey)
            
        }
        
        self.buttonActivity.hidden = true
        
        
    }
    
    func startRotation() {
        
        if isRotating {
            
            return
            
        }
        
        isRotating = true
        self.buttonActivity.hidden = false
        
        if self.buttonActivity.layer.animationForKey(kRotationAnimationKey) == nil {
      
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
            
            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = 1
            rotationAnimation.repeatCount = Float.infinity
            self.buttonActivity.layer.addAnimation(rotationAnimation, forKey: kRotationAnimationKey)
            
        }
        
    }
    
    func resetCell() {
        
        self.imageView.image = UIImage(named: ImageConstants.kDefaultECGImage)
        self.buttonActivity.userInteractionEnabled = false
        self.deleteButton.hidden = true
        
    }

    func downloadFailed() {
        
        self.imageView.image = UIImage(named: ImageConstants.kDefaultECGImage)
        
        self.deleteButton.hidden = true
        
    }

    
}