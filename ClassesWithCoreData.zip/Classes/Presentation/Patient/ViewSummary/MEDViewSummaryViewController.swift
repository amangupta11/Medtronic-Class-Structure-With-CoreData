//  MEDViewSummaryViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import SwiftyJSON
class MEDViewSummaryViewController: MEDBaseViewController {
    @IBOutlet var editButton: UIButton!
    @IBOutlet var chatIcon: UIBarButtonItem!
    @IBOutlet var patientPhoneNumber: UIButton!
    @IBOutlet var patientDoorInTime: UILabel!
    @IBOutlet var patientGender: UILabel!
    @IBOutlet var patientAge: UILabel!
    @IBOutlet var patientName: UILabel!
    @IBOutlet var triageDateTimeLabel: UILabel!
    @IBOutlet var onsetDateTimeLabel: UILabel!
    @IBOutlet var icORPassportLabel: UILabel!
    @IBOutlet var citizenshipTypeLabel: UILabel!
    @IBOutlet var paymentType: UILabel!
    @IBOutlet var patientCaseID: UILabel!
    @IBOutlet weak var treatmentButton: UIButton!
    @IBOutlet weak var transferButton: UIButton!
    @IBOutlet var treatmentLabel: UILabel!
    @IBOutlet var transferLabel: UILabel!
    @IBOutlet var patientHistoryLabel: UILabel!
    @IBOutlet var ecgLabel: UILabel!
    @IBOutlet var timelineLabel: UILabel!
    @IBOutlet var dischargeLabel: UILabel!
    @IBOutlet var shadowImageTopConstraint: NSLayoutConstraint!
    @IBOutlet var scrollView: UIScrollView!
    
    @IBOutlet weak var shadowImageOutlet: UIImageView!
    @IBOutlet weak var bottomViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var transferButtonBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var patientHistoryBottomConstarint: NSLayoutConstraint!
    @IBOutlet weak var ecgButtonBottomConstarint: NSLayoutConstraint!
    @IBOutlet weak var BottomButtonDeviderLabel: UILabel!
    @IBOutlet weak var dischargeButtonOutlet: MEDDashboardCustomButton!
    @IBOutlet weak var timelineButtonOutlet: MEDDashboardCustomButton!
    @IBOutlet weak var bottomButtonHeightConstraint: NSLayoutConstraint!
    var  medicalHistoryDict = NSMutableDictionary()
    var authorizationAlert:Bool = false
    var navigateToScreen:Int = 0
    var medicalNotes:String? = nil
    var stopTreatmentBarButton = UIBarButtonItem()
    var timelineEnabled: Bool = false
    //var hospitalListArray: NSArray!
    var hospitalListArray: [JSON] = []
    var timelineArray:NSMutableArray!
    struct ViewSummaryConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    var onsetDate:NSString!
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            updateUI()
            startTimer()
        }
    }
}
// MARK: - @IBAction Methods
extension MEDViewSummaryViewController {
    @IBAction func ecgButtonAction(sender: AnyObject) {
        self.getECGInfarctAreaDetails(patientInfo!)
    }
    @IBAction func timelineButtonAction(sender: AnyObject) {
        performGetCaseTimelineDetails()
    }
    @IBAction func dischargeButtonAction(sender: AnyObject) {
        //showNotImplementedUserStoryAlert()
    }
    @IBAction func patientHistoryButtonAction(sender: AnyObject) {
        // Call the getMedical history api to get the data
        getPatientMedicalConditions()
    }
    @IBAction func treatmentButtonAction(sender: AnyObject) {
        onTreatmentButtonTap()
    }
    @IBAction func transferButtonAction(sender: AnyObject) {
        onTransferButtonTap()
    }
    @IBAction func editButtonAction(sender: AnyObject) {
        self.performNavigation()
    }
    @IBAction func callButtonAction(sender: AnyObject) {
        if(self.patientPhoneNumber.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((patientPhoneNumber.titleLabel?.text)!)
        }
    }
}
// MARK: - Custom Actions
extension MEDViewSummaryViewController {
    func initialSetup() {
        self.navigationItem.rightBarButtonItem = nil
        self.buttonActionEnabling()
        setNavigationBackButtonImage()
        setshadowImageForScrollView()
        getNavigationRightBarButtonItem()
    }
    func onTreatmentButtonTap() {
        self.handleTreatment ()
    }
    func onTransferButtonTap() {
        if(timelineEnabled == true){
           self.performGetCaseTimelineDetails()
        }
        else{
           self.handleTransfer()
        }
    }
    func handleTreatment () {
        navigateToScreen = 4
        performGetTreatmentCASEDetails()
    }

    func setshadowImageForScrollView() {
        let screenRect = UIScreen.mainScreen().bounds
        if (screenRect.size.height <= 568) {
            // this is an iPhone 5s or below
            self.shadowImageTopConstraint.constant = 260
        } else if screenRect.size.height == 667.0 {
            // Iphone 6s
            self.shadowImageTopConstraint.constant = 400
        } else {
            // Iphone 6s
            self.shadowImageTopConstraint.constant = 410
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(ViewSummaryConstants.AlertTitle, message:ViewSummaryConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }

    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    func showNotImplementedUserStoryAlert() {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showSimpleAlert("", message:NSLocalizedString( "Not_Yet_Implemented", comment: ""), preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func handleTransfer() {
        let user = LoginManager.getLoggedInUser()
        let hospitalTypeID = (user?.hospitalTypeID!)! as String
        let caseStatus = (patientInfo?.caseStatus!)! as String
        let roleID = (user?.roleID!)! as String

        if (user != nil) {
            if roleID == UserRoles.GeneralPractitioner.rawValue // Transfer is only for Nurse
            {
                if hospitalTypeID == "1" // Handle Spoke Nurse Transfer
                {
                    if caseStatus == status.STEMI.rawValue // If status is STEMI then show hospital listing screen
                    {
                        performGetHospitalDetails()
                    } else if caseStatus == status.InTransit.rawValue // If status is In Transit show Spoke  time line screen
                    {
                        getFMCDoorOutForPatient()
                    }
                } else if hospitalTypeID == "2" // Handle Hub Nurse Transfer
                {
                    if  caseStatus == status.InTransit.rawValue   // If status is STEMI|| Intransit  then show Hub internal transfer screen
                    {
                        navigateToScreen = 2
                        performGetTreatmentCASEDetails()
                    } else if caseStatus == status.STEMI.rawValue // If status is Internal Transfer then show Hub Time Line screen
                    {
                        navigateToScreen = 3
                        performGetTreatmentCASEDetails()
                        // Sprint 4
                    }
                }
            } else {
                //Ignore all actions for other roles
            }
        }
    }
    func navigateToParticularScreen(navigateToScreen:Int){
        switch navigateToScreen {
        case 2:
            navigateToHubNurseTimelineScreen()
        case 3:
            navigateTohubNurseInternalTransferScreen()
        case 4:
            navigateViewSummaryToTreatmentScreen()
        default: break
        }
        
    }
    func navigateViewSummaryToTimelineScreen() {
        let timeLineController: TimelineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.TimelineViewControllerSBID) as! TimelineViewController
        timeLineController.patientInfo = patientInfo
        timeLineController.timelineArray = timelineArray
        timeLineController.onsetDate = onsetDate
        self.navigationController?.pushViewController(timeLineController, animated: true)
    }
    func navigateToHubNurseTimelineScreen() {
        let hubNurseTimeLineController: MEDHubNurseTimeLineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.hubNurseTimeLineScreenSBID) as! MEDHubNurseTimeLineViewController
        hubNurseTimeLineController.patientInfo = patientInfo
        self.navigationController?.pushViewController(hubNurseTimeLineController, animated: true)
    }

    func navigateViewSummaryToTreatmentScreen() {
        self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToTreatmentSegueIdentifier, sender: nil)
    }
    func navigateToViewSummaryToTransferScreen() {
        self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToTransferSegueIdentifier, sender: nil)
    }
    func navigateTospokeNurseTimelineScreen() {
        let spokeNurseTimelineController: MEDSpokeNurseTimeLineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.spokeNurseTimelineScreenSBID) as! MEDSpokeNurseTimeLineViewController
        spokeNurseTimelineController.patientInfo = patientInfo
        self.navigationController?.pushViewController(spokeNurseTimelineController, animated: true)
    }
    func navigateTohubNurseInternalTransferScreen() {
        let hubNurseInternalTransfer: MEDHubNurseInternalTransferViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.internalTransferScreenSBID) as! MEDHubNurseInternalTransferViewController
        hubNurseInternalTransfer.patientInfo = patientInfo
        self.navigationController?.pushViewController(hubNurseInternalTransfer, animated: true)
    }


    func navigateToECGHistoryScreen(withInfarctAreaArray: NSMutableArray) {
        let ecgHistoryController: ECGHistoryViewController = UIStoryboard(name: StroryBoardNameConstants.SBECGHistory, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ECGHistoryControllerSBID) as! ECGHistoryViewController
        ecgHistoryController.patientInfo = patientInfo
        ecgHistoryController.infarctAreaHistoryArray = withInfarctAreaArray
        self.navigationController?.pushViewController(ecgHistoryController, animated: true)
    }

    override func backButtonAction(button: UIButton) {
        DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func updateUI() {
        var middileName: String = ""
        let countryCode = patientInfo?.countryCode as String!
        let mobileNumber = patientInfo?.mobileNumber as! String!
        if(patientInfo?.middleName != nil && patientInfo?.middleName != "") {
        middileName = String((patientInfo?.middleName as! String).characters.prefix(1))}
        let patientName = (patientInfo?.firstName as! String) + " " + (middileName) + " " + ((patientInfo?.lastName)! as! String) as String
        let paymentType = patientInfo?.paymentType as? String
        self.patientCaseID.text = "Case ID : " + (patientInfo?.hospitalCaseID)! as String!
        self.paymentType.text = paymentType?.uppercaseString
        self.citizenshipTypeLabel.text = (patientInfo?.citizenshipType as? String)?.uppercaseString
        self.patientName.text = patientName.uppercaseString
        self.patientAge.text = patientInfo?.age as? String
        self.icORPassportLabel.text = (patientInfo?.icOrPassport as? String)?.uppercaseString
        self.patientGender.text = "FEMALE"
        if(patientInfo?.gender == "1") {
            self.patientGender.text = "MALE"}
        let fmcDoorInTime = patientInfo?.timeLine?.fmcDoorInTime as? Double
        let doorInTimeString = DateUtility.convertGMTtoLongDate(fmcDoorInTime!)
        self.patientDoorInTime.text = doorInTimeString.uppercaseString
        if(patientInfo?.timeLine?.onsetTime != nil && patientInfo?.timeLine?.onsetTime != 0) {
        let onsetDateTime = patientInfo?.timeLine?.onsetTime as? Double
        let onsetDateTimeString = DateUtility.convertGMTtoLongDate(onsetDateTime!)
        self.onsetDateTimeLabel.text = onsetDateTimeString.uppercaseString}
        if(patientInfo?.timeLine?.triageTime != nil && patientInfo?.timeLine?.triageTime != 0) {
        let traigeTime = patientInfo?.timeLine?.triageTime as? Double
        let triageTimeString = DateUtility.convertGMTtoLongDate(traigeTime!)
        self.triageDateTimeLabel.text = triageTimeString.uppercaseString}
        if(mobileNumber != nil) {
            if(countryCode != nil && mobileNumber.isEmpty == false) {
                self.patientPhoneNumber.setTitle((countryCode) + " " + (mobileNumber) as String, forState: .Normal)
            }
            else{
                self.patientPhoneNumber.setTitle(("") + " " + ("") as String, forState: .Normal)
            }
        }
    }
    func stopTreatmentButtonAction()
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.StopTreatmentScreenSBID) as? MEDStopTreatmentController
        vc?.patientInfo = patientInfo
        self.navigationController?.pushViewController(vc!, animated: true)

    }
    func getNavigationRightBarButtonItem() {
        stopTreatmentBarButton = UIBarButtonItem(title: "Stop Treatment", style: .Plain, target: self, action: #selector(stopTreatmentButtonAction))
        
        let color : UIColor = UIColor.whiteColor()
        let titleFont : UIFont = UIFont(name: "effra-regular", size: 14.0)!
        let attributes = [
            NSForegroundColorAttributeName : color,
            NSFontAttributeName : titleFont
        ]
        stopTreatmentBarButton.setTitleTextAttributes(attributes, forState: UIControlState.Normal)
        let user = LoginManager.getLoggedInUser()
        if (user != nil) {
            print(user?.roleID)
            switch (user?.roleID)! as String {
            case "1"://Spoke or Hub
                if self.patientInfo?.caseStatus == status.STEMI.rawValue || self.patientInfo?.caseStatus == status.InTransit.rawValue || self.patientInfo?.caseStatus == status.Undiagnosed.rawValue{
                    self.navigationItem.rightBarButtonItem = stopTreatmentBarButton

                }else{
                    self.navigationItem.rightBarButtonItem = nil
                }
                enableEditButton()
            case "2"://CathLab
                if self.patientInfo?.caseStatus == status.InternalTransfer.rawValue || self.patientInfo?.caseStatus == status.InTransit.rawValue || self.patientInfo?.caseStatus == status.CathLabAccepted.rawValue{
                    self.navigationItem.rightBarButtonItem = stopTreatmentBarButton
                    
                }else{
                    self.navigationItem.rightBarButtonItem = nil
                }
            case "3"://Cardio
                self.navigationItem.rightBarButtonItem = nil// chatIcon
            case "7"://Cardio
                self.navigationItem.rightBarButtonItem = nil// chatIcon
            default: break
            }
        }
    }
    
    func buttonActionEnabling() {
        let user = LoginManager.getLoggedInUser()
        transferButton.enabled = false
        transferLabel.alpha = 0.4
        editButton.hidden = true
        // treatmentButton.enabled = false
        if (user != nil) {
            print(user?.roleID)
            switch (user?.roleID)! as String {
            case "1":
                self.navigationItem.rightBarButtonItem = nil// chatIcon
                enableEditButton()
            case "2":
                self.navigationItem.rightBarButtonItem = nil
                 handleTreatmentButton()
            // treatmentButton.enabled = true
            case "3":
                self.navigationItem.rightBarButtonItem = nil// chatIcon
            case "7":
                self.navigationItem.rightBarButtonItem = nil// chatIcon
                handleBottomButtonForOnCallCardio()
            default: break
            }
        }
    }
    func handleBottomButtonForOnCallCardio(){
        treatmentButton.hidden = true
        dischargeButtonOutlet.hidden = true
        timelineButtonOutlet.hidden = true
        bottomButtonHeightConstraint.constant = 80
        ecgButtonBottomConstarint.constant = 0
        patientHistoryBottomConstarint.constant = 0
        transferButtonBottomConstraint.constant = 0
        BottomButtonDeviderLabel.hidden = true
        timelineLabel.hidden = true
        dischargeLabel.hidden = true
        treatmentLabel.hidden = true
        transferButton.enabled = true
        transferLabel.alpha = 1.0
        transferLabel.text = "Timeline"
        transferButton.setImage(UIImage(named:"timeline"), forState: UIControlState.Normal)
        timelineEnabled = true
        bottomViewHeightConstraint.constant = -50
        shadowImageOutlet.hidden = true
    }
    func handleTreatmentButton(){
       let caseStatus = (patientInfo?.caseStatus!)! as String
        if(caseStatus == status.Cancelled.rawValue){
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        }
    }

    func enableEditButton() {

        let caseStatus = (patientInfo?.caseStatus!)! as String
        switch (caseStatus) {
        case status.UnderObservation.rawValue:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4

        case status.Undiagnosed.rawValue:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case status.NotAStemi.rawValue:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4

        case status.STEMI.rawValue:
            editButton.hidden = false
            transferButton.enabled = true
            transferLabel.alpha = 1.0
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case status.InTransit.rawValue:
            editButton.hidden = false
            transferButton.enabled = true
            transferLabel.alpha = 1.0
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case status.InternalTransfer.rawValue:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case status.CathLabAccepted.rawValue:
            editButton.hidden = false
        case status.DeviceCrossTime.rawValue:
            editButton.hidden = false
        case status.CathLabExit.rawValue:
            editButton.hidden = false
        case status.Completed.rawValue:
            editButton.hidden = true
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = true
            treatmentLabel.alpha = 1.0
        case status.Cancelled.rawValue:
            editButton.hidden = true
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        default:
            editButton.hidden = true
        }
    }
    func performNavigation() {
        if let viewControllers = self.navigationController?.viewControllers {
            var count = 0
            for viewController in viewControllers {
                count += 1
                if viewController.isKindOfClass(MEDEditCaseViewController) {
                    viewController.hidesBottomBarWhenPushed = true
                    self.hidesBottomBarWhenPushed = true
                    self.navigationController?.popViewControllerAnimated(true)
                    return
                }
            }
            self.pushViewSummaryToEditCaseController(count, viewControllers: viewControllers)
        }
    }
    func pushViewSummaryToEditCaseController(count: Int, viewControllers: [UIViewController]) {
        if(count == viewControllers.count) {
            self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToEditCaseSegueIdentifier, sender: nil)
        }
    }
    // MARK: - Segue Methods
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == SegueIdentifierConstants.ViewSummaryToEditCaseSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDEditCaseViewController
            vc.patientInfo = patientInfo
        } else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToTransferSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDHospitalListViewController
            vc.patientInfo = patientInfo
            vc.hospitalListArray = hospitalListArray
        } else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToTreatmentSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDTreatmentViewController
            vc.patientInfo = patientInfo
        }else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToPatientHistorySegueIdentifier) {
            let vc = segue.destinationViewController as! BasePatientHistoryViewController
            vc.medicalHistoryDict = self.medicalHistoryDict
            vc.patientInfo = patientInfo
        }
        else {

        }
    }
    
func navigateToPatientHistory(){
self.performSegueWithIdentifier("ViewSummaryToPatientHistory", sender: self)
    }
    
}
//MARK: - Alert view delegates
extension MEDViewSummaryViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
        if (authorizationAlert == true){
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
        else{
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
