//  MEDPatientGeneralInfoViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDPatientGeneralInfoViewController: MEDBaseViewController {
    enum GenderButtonTag: Int {
        case Male = 1011
        case Female = 1022
    }
    @IBOutlet weak var fmcdoorinEditedLbl: UILabel!
    @IBOutlet weak var doorInAttemptLbl: UILabel!
    @IBOutlet weak var doorInTimeBtn: UIButton!
    @IBOutlet weak var doorInButtonOutlet: MEDBorderedButton!
    @IBOutlet weak var onsiteDateTimeLineButton: UIButton!
    @IBOutlet weak var citizenshipLabel: UILabel!
    @IBOutlet var nextButton: UIButton!
    @IBOutlet weak var lastNameTFOutlet: MEDBorderedTextField!
    @IBOutlet weak var middleNameTFOutlet: MEDBorderedTextField!
    @IBOutlet weak var firstNameTFOutlet: MEDBorderedTextField!
    @IBOutlet weak var ICNoTFOutlet: MEDBorderedTextField!
    @IBOutlet weak var citizenshipButtonOutlet: MEDBorderedButton!
    @IBOutlet weak var onsiteDateTimeButtonOutlet: MEDBorderedButton!
    @IBOutlet weak var citizenshipTextLabel: UILabel!
    @IBOutlet weak var maxAttemptsLabel: UILabel!
    @IBOutlet weak var ageTextFieldOutlet: MEDBorderedTextField!
    @IBOutlet weak var femaleButtonOutlet: UIButton!
    @IBOutlet weak var maleButtonOutlet: UIButton!
    @IBOutlet weak var onsetDateTimeEditedLabel: UILabel!
    
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    var citizenshipTypeArray: NSArray!
     var pickerContainerView: UIView!
    var activeTextField: MEDBorderedTextField!
    var pickerViewIdentifierString: PickerViewIdentifiers!
    var cameFromViewSummary: Bool = false
    var countryNamesArray: NSMutableArray!
    var scrollOffset: CGPoint!
    var pickerViewtag: Int!
    static var defaultCountryName = "Malaysia"

    @IBOutlet weak var generalInfoScrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        super.addKeyboardObserver(self)
        updateUI()
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }

}
// MARK: - Custom Actions
extension MEDPatientGeneralInfoViewController {
    func handleResponse() {
        self.navigateToStep2View()
    }
    func navigateToStep2View() {
        // Navigate to next screen
        let baseController =  self.parentViewController as! MEDPatientBaseContainerView
        baseController.stepButtonAction(baseController.step2ButtonOutlet)
    }
    func updateUI() {

        self.firstNameTFOutlet.text =  patientInfo?.firstName as? String
        self.lastNameTFOutlet.text = patientInfo?.lastName as? String
        self.middleNameTFOutlet.text = patientInfo?.middleName as? String
        self.ICNoTFOutlet.text = patientInfo?.icOrPassport as? String
        self.ageTextFieldOutlet.text = patientInfo?.age as? String

        let onsiteTime = patientInfo?.timeLine?.onsetTime as? Double
        let dateString = String(format: "%@", (patientInfo?.timeLine?.onsetTime!)!)
        if dateString != "0"{
        let onsetTimeString = DateUtility.convertGMTtoTime(onsiteTime!)
        let onsetDateString = DateUtility.convertGMTtoShortDate(onsiteTime!)
        self.onsiteDateTimeButtonOutlet.setTitle(onsetDateString+" "+onsetTimeString, forState: .Normal)
        }
        self.onsiteDateTimeButtonOutlet.userInteractionEnabled = true
        
        
        let fmcdoorInTime = patientInfo?.timeLine?.fmcDoorInTime as? Double
        let dateStr = String(format: "%@", (patientInfo?.timeLine?.fmcDoorInTime!)!)
        if dateStr != "0"{
            let fmcTimeString = DateUtility.convertGMTtoTime(fmcdoorInTime!)
            let fmcDateString = DateUtility.convertGMTtoShortDate(fmcdoorInTime!)
            self.doorInButtonOutlet.setTitle(fmcDateString+" "+fmcTimeString, forState: .Normal)
        }
        self.doorInButtonOutlet.userInteractionEnabled = true
        
        self.citizenshipTextLabel.text =  patientInfo?.citizenshipType as? String
        if(patientInfo?.gender == "1") {
            self.maleButtonOutlet.selected = true
            self.femaleButtonOutlet.selected = false
        } else { self.femaleButtonOutlet.selected = true
            self.maleButtonOutlet.selected = false
        }

        // Updating max attempts label
        updateMaxAttemptsLabel()
        updateOnsetTimeEditedStringLabel()
        
        updateFMCDoorInTimeMaxAttemptsLabel()
        updateFMCDoorInTimeEditedStringLabel()
    }
    
    func addPickerForFmcDoorIn(tag:Int){
        self.view.endEditing(true)
        initializePickerContainerView()
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        pickerViewtag = tag
        var date: NSDate
        if patientInfo?.timeLine?.addNewCaseTime != nil {
            date = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.addNewCaseTime as! Double)} else {
            date = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.fmcDoorInTime as! Double)
        }
        self.pickerContainerDelegate.datePicker.maximumDate = date
        self.pickerContainerDelegate.datePicker.minimumDate = date.dateByAddingTimeInterval(-3600*4)
        self.makeTransparentScreenColor()
        self.addPickerContainerView()
    }
    
    func addPickerForOnsetDate(tag:Int){
        self.view.endEditing(true)
        initializePickerContainerView()
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        pickerViewtag = tag
        var date: NSDate
        if patientInfo?.timeLine?.addNewCaseTime != nil {
            date = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.addNewCaseTime as! Double)} else {
            date = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.fmcDoorInTime as! Double)
        }
        self.pickerContainerDelegate.datePicker.maximumDate = date
        self.makeTransparentScreenColor()
        self.addPickerContainerView()
    }

    func updateMaxAttemptsLabel() {
        //self.maxAttemptsLabel.text =  ButtonTitles.attemptRemainingString
        if Int((patientInfo?.timeLine?.onsetEditCount)!) == 3 {
            self.onsiteDateTimeLineButton.hidden = true
            self.maxAttemptsLabel.hidden = true
            self.onsiteDateTimeButtonOutlet.userInteractionEnabled = false
            self.onsiteDateTimeButtonOutlet.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
            self.onsiteDateTimeButtonOutlet.titleLabel?.textColor = ColorPicker.ligthGrey()
        }
        else{
            self.maxAttemptsLabel.text =  "\(3 - Int((patientInfo?.timeLine?.onsetEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }
    }
    
    func updateFMCDoorInTimeMaxAttemptsLabel() {
        //self.maxAttemptsLabel.text =  ButtonTitles.attemptRemainingString
        if Int((patientInfo?.timeLine?.fmcDoorInEditCount)!) == 3 {
            self.doorInTimeBtn.hidden = true
            self.doorInAttemptLbl.hidden = true
            self.doorInButtonOutlet.userInteractionEnabled = false
            self.doorInButtonOutlet.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
            self.doorInButtonOutlet.titleLabel?.textColor = ColorPicker.ligthGrey()
        }
        else{
            self.doorInAttemptLbl.text =  "\(3 - Int((patientInfo?.timeLine?.fmcDoorInEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }
    }
    
    func updateOnsetTimeEditedStringLabel() {
        let string  = patientInfo?.timeLine?.onsetEditedText
        if string != nil {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  string! )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 2, range: NSMakeRange(0, attributeString.length))
            self.onsetDateTimeEditedLabel.attributedText = attributeString
        }

    }
    
    func updateFMCDoorInTimeEditedStringLabel() {
        let string  = patientInfo?.timeLine?.fmcDoorInEditedText
        if string != nil {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  string! )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 2, range: NSMakeRange(0, attributeString.length))
            self.fmcdoorinEditedLbl.attributedText = attributeString
        }
        
    }
    
    override func backButtonAction(button: UIButton) {
        if(cameFromViewSummary == true) {
            self.performSegueWithIdentifier(SegueIdentifierConstants.EditCaseToViewSummarySegueIdentifier, sender: nil)
        } else {
            if let viewControllers = navigationController?.viewControllers {
                var i = 0
                for viewController in viewControllers {
                    i += 1
                    if viewController.isKindOfClass( MEDViewSummaryViewController) {
                        self.navigationController?.popViewControllerAnimated(true)
                        return
                    }
                }
                DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
                self.navigationController?.popToRootViewControllerAnimated(true)
            }
        }
    }

    func makeTransparentScreenColor() {
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
    }
    func normalizeTheLabelsColor() {
        self.firstNameTFOutlet.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.lastNameTFOutlet.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.ICNoTFOutlet.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.onsiteDateTimeButtonOutlet.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.ageTextFieldOutlet.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
    }
    //TODO : Use this commom func
    func addPickerContainerView() {
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    override func initialSetUp(bgImage: String) {
        self.setTapGestureForView()
        self.loadCitizenship()
        setNavigationBackButtonImage()
        if(patientInfo?.gender == "0") {
            self.femaleButtonOutlet.selected = true
        } else {
            self.maleButtonOutlet.selected = true
            patientInfo?.gender = "1"
        }
            if(patientInfo?.caseStatus == status.Diagnosed.rawValue) {
                handleUserInteractionForFields(false)
                maxAttemptsLabel.hidden = true
                onsiteDateTimeLineButton.hidden = true
            self.nextButton.setTitle("Next", forState: UIControlState.Normal)
            self.nextButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 38, bottom: 0, right: 0)
            } else {
             handleUserInteractionForFields(true)
                maxAttemptsLabel.hidden = false
                onsiteDateTimeLineButton.hidden = false
        }
    }

    func handleUserInteractionForFields(enabled: Bool) {
       ICNoTFOutlet.userInteractionEnabled = enabled
        firstNameTFOutlet.userInteractionEnabled = enabled
        middleNameTFOutlet.userInteractionEnabled = enabled
        lastNameTFOutlet.userInteractionEnabled = enabled
        ageTextFieldOutlet.userInteractionEnabled = enabled
        onsiteDateTimeLineButton.userInteractionEnabled = enabled
        citizenshipButtonOutlet.userInteractionEnabled = enabled
        maleButtonOutlet.userInteractionEnabled = enabled
        femaleButtonOutlet.userInteractionEnabled = enabled
    }
    func performNavigation() {
        cameFromViewSummary = true
        if let viewControllers = navigationController?.viewControllers {
            var count = 0
            for viewController in viewControllers {
                count += 1
                if viewController.isKindOfClass( MEDViewSummaryViewController) {
                    self.navigationController?.popViewControllerAnimated(true)
                    return
                }
            }

        }
    }
    func changeStatusOfDoorInTimeButton(count: String) {
        let numberFromString = Int(count)
        if numberFromString > 3 {
            disableOnsetDateTimeButon()
        } else {
            enableOnsetDateTimeButon()
        }
    }
    func disableOnsetDateTimeButon() {
        self.onsiteDateTimeButtonOutlet.enabled = false
        self.onsiteDateTimeButtonOutlet.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
    }

    func enableOnsetDateTimeButon() {
        self.onsiteDateTimeButtonOutlet.enabled = true
        self.onsiteDateTimeButtonOutlet.setTitleColor(ColorPicker.lightBlackColor(), forState: .Normal)
    }

    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func initializePickerContainerView() {
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
    }

    func saveData() {
        patientInfo?.firstName = self.firstNameTFOutlet.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        patientInfo?.lastName = self.lastNameTFOutlet.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        patientInfo?.middleName = self.middleNameTFOutlet.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        patientInfo?.icOrPassport = self.ICNoTFOutlet.text
        patientInfo?.age = self.ageTextFieldOutlet.text
        let count = patientInfo?.timeLine?.onsetTime
        let numberFromString  = Int(count!)
        if numberFromString < 4 {
            if self.onsiteDateTimeButtonOutlet.titleLabel?.text != nil {
                let dateString = String(format: "%@", (self.onsiteDateTimeButtonOutlet.titleLabel?.text)!)
                patientInfo?.timeLine?.onsetTime = DateUtility.convertStringToDate(dateString)
            }
        }
        if(self.citizenshipTextLabel.text?.isEmpty == false) {
            patientInfo?.citizenshipType = self.citizenshipTextLabel.text
        }
        PatientManager.updateAllInfo(patientInfo!)
    }

    func loadCitizenship() {
        let metaDataPList: NSDictionary!
        if let path = NSBundle.mainBundle().pathForResource("MEDMetaData", ofType: "plist") {
            metaDataPList = NSDictionary(contentsOfFile: path)

            self.citizenshipTypeArray = self.setCountryCodes((metaDataPList.objectForKey("CountryCodes") as? NSArray)!)
        }
    }


    func setCountryCodes(countryCodeArray: NSArray) -> NSMutableArray {
        self.countryNamesArray = NSMutableArray()

        for i in 0..<countryCodeArray.count {
            let dict = countryCodeArray[i] as! NSMutableDictionary
            let countryName =    dict.objectForKey("CountryName") as! String

            countryNamesArray.addObject(countryName)
        }
        self.countryNamesArray.insertObject("None", atIndex: 0)
        return self.countryNamesArray
    }



}
//MARK: - Keyboard Notification Handling
extension MEDPatientGeneralInfoViewController {
    // MARK: - Keyboard Notification Handling
    override func keyboardWillShow(notification: NSNotification) {
        self.scrollOffset = self.generalInfoScrollView.contentOffset
        let info : NSDictionary = notification.userInfo!
        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.CGRectValue().size
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        self.generalInfoScrollView.contentInset = contentInsets
        self.generalInfoScrollView.scrollRectToVisible(self.activeTextField.frame, animated: true)
        
    }
    override func keyboardWillHide(notification: NSNotification) {
        self.generalInfoScrollView.contentInset = UIEdgeInsetsZero
    }

}
// MARK: - Picker Delegates
extension MEDPatientGeneralInfoViewController: pickerViewProtocol {
    //Picker View delegates
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        switch pickerViewtag {
        case 0:
            self.onsiteDateTimeButtonOutlet.setTitle(selectedDate+" "+selectedTime, forState: .Normal)
            let dateString = String(format: "%@ %@", selectedDate, selectedTime)
            patientInfo?.timeLine?.onsetTime = DateUtility.convertStringToDate(dateString)
        case 1:
            self.doorInButtonOutlet.setTitle(selectedDate+" "+selectedTime, forState: .Normal)
            let dateString = String(format: "%@ %@", selectedDate, selectedTime)
            patientInfo?.timeLine?.fmcDoorInTime = DateUtility.convertStringToDate(dateString)
        default:
            break
        }
    }

    func pickerViewDoneButtonTapped(selectedString: String!, index: Int) {
        switch self.pickerViewIdentifierString.rawValue {
        case PickerViewIdentifiers.PaymentType.rawValue:
            if(selectedString == "None") {
                self.citizenshipTextLabel.text = "None"
            } else if selectedString != "" {
                self.citizenshipTextLabel.text = selectedString
                patientInfo?.citizenshipTypeID = index
                patientInfo?.citizenshipType = self.citizenshipTextLabel.text
            } else if selectedString == "" && (self.citizenshipTextLabel.text == nil || self.citizenshipTextLabel.text == "") {
                self.citizenshipTextLabel.text = MEDPatientGeneralInfoViewController.defaultCountryName
                self.patientInfo?.citizenshipTypeID = self.citizenshipTypeArray.indexOfObject(MEDPatientGeneralInfoViewController.defaultCountryName)
            }
        default:
            return
        }
    }
}

// MARK: - UITextFieldDelegate
extension MEDPatientGeneralInfoViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        self.currentTextFieldTag = textField.tag
        if textField == self.firstNameTFOutlet || textField == self.lastNameTFOutlet  || textField == self.middleNameTFOutlet {
            textField.autocorrectionType = UITextAutocorrectionType.No
            textField.autocapitalizationType = UITextAutocapitalizationType.Sentences
        }
        self.activeTextField = textField as! MEDBorderedTextField
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let customTextField = textField as! MEDBorderedTextField
        let updatedString = (customTextField.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: string)
        if(customTextField == self.ICNoTFOutlet ) {
            if updatedString?.characters.count > 15 {
            return false
            }
        }
        if customTextField == self.firstNameTFOutlet || customTextField == self.lastNameTFOutlet || customTextField == self.middleNameTFOutlet {
            if MEDPatientValidations.validateFirstORLastName(updatedString!) == false {
                return false
            }
            if (customTextField.text == "" && updatedString == " " ) {
                return false
            }
        } else if customTextField == self.ageTextFieldOutlet {
                if updatedString! == "" {
                return true
                }
            if MEDPatientValidations.isValidAge(updatedString!) == false {
                return false
                }
            }
        if customTextField == self.ICNoTFOutlet {
            if MEDPatientValidations.isValidPassportORIc(updatedString!) == false {
                return false
            }}
        return true
    }

    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        textField.inputAccessoryView = self.inputToolbar
        updateKeyboardToolbar(textField)
        return true
    }
}
// MARK: - @IBAction Actions
extension MEDPatientGeneralInfoViewController {
    
    @IBAction func doorInTimeBtnAction(sender: AnyObject) {
        self.addPickerForFmcDoorIn(sender.tag)
    }
    @IBAction func onsetDateButtonAction(sender: AnyObject) {
        addPickerForOnsetDate(sender.tag)
    }
    
    @IBAction func nextButtonAction(sender: AnyObject) {
        if(patientInfo?.caseStatus == status.Diagnosed.rawValue) {
            self.navigateToStep2View()
        } else {
            // Validate the Fields
            self.normalizeTheLabelsColor()
            self.view.endEditing(true)
            let isValid = self.validateFields()
            if isValid == true {
                //Server Call
                saveData()
                postPatientGeneralInfoDetails()
                //navigateToStep2View()
            }
        }
    }

    @IBAction func citizenshipButtonAction(sender: AnyObject) {
        self.view.endEditing(true)
        var selectedIndex: Int = 0
        if self.citizenshipTextLabel.text?.characters.count > 0 {
            for i in 0..<self.citizenshipTypeArray.count {
                if self.citizenshipTextLabel.text! == self.citizenshipTypeArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.initializePickerContainerView()
        self.pickerContainerDelegate.index = selectedIndex
        self.pickerContainerView =
            self.pickerContainerDelegate.customPickerView(self.citizenshipTypeArray)
        self.makeTransparentScreenColor()
        self.pickerViewIdentifierString = PickerViewIdentifiers.PaymentType
        if(self.citizenshipTextLabel.text == nil || self.citizenshipTextLabel.text == "") {
            self.pickerContainerDelegate.pickerView.selectRow(self.citizenshipTypeArray.indexOfObject(MEDPatientGeneralInfoViewController.defaultCountryName), inComponent: 0, animated: true)

        } else {
              self.pickerContainerDelegate.pickerView.selectRow(self.citizenshipTypeArray.indexOfObject(self.citizenshipTextLabel.text!), inComponent: 0, animated: true)
        }
        self.addPickerContainerView()
    }
    @IBAction func onsiteDateTimeButtonAction(sender: AnyObject) {
        addPickerForOnsetDate(sender.tag)
    }
    @IBAction func genderButtonAction(sender: AnyObject) {
        let buttonTag = sender.tag
        switch buttonTag {
        case GenderButtonTag.Male.rawValue:
            self.maleButtonOutlet.selected = true
            patientInfo!.gender = "1"
            self.femaleButtonOutlet.selected = !self.maleButtonOutlet.selected
        case GenderButtonTag.Female.rawValue:
            self.femaleButtonOutlet.selected = true
            patientInfo!.gender = "0"
            self.maleButtonOutlet.selected = !self.femaleButtonOutlet.selected
        default:
            break
        }
    }


}

// MARK: - Validations
extension MEDPatientGeneralInfoViewController {
    func validateFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        if self.firstNameTFOutlet.text?.characters.count == 0 {
            self.firstNameTFOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if self.lastNameTFOutlet.text?.characters.count == 0 {
            self.lastNameTFOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if MEDPatientValidations.validateFirstORLastName(self.lastNameTFOutlet.text!) == false {
            self.firstNameTFOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if MEDPatientValidations.validateFirstORLastName(self.lastNameTFOutlet.text!) == false {
            self.lastNameTFOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if MEDPatientValidations.isValidPassportORIc(self.ICNoTFOutlet.text!) == false {
            self.ICNoTFOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }

        if self.ageTextFieldOutlet.text?.characters.count == 0||(self.ageTextFieldOutlet.text! as NSString).integerValue > 110 {
            self.ageTextFieldOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if self.onsiteDateTimeButtonOutlet.currentTitle == nil || self.onsiteDateTimeButtonOutlet.currentTitle == ""
        {
            self.onsiteDateTimeButtonOutlet.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        
        return isValid
    }
}
