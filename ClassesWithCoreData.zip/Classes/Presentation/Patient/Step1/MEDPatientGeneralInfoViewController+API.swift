//  MEDPatientGeneralInfoViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
extension MEDPatientGeneralInfoViewController {


    func postPatientGeneralInfoDetails() {
        checkInternet()
        let dict:NSDictionary
        if(patientInfo?.caseID != nil){
            dict = [PatientInfoKey.CaseID.rawValue:patientInfo?.caseID as! AnyObject]
        }
        else{
            dict = [PatientInfoKey.TempCaseID.rawValue:patientInfo?.tempCaseID as! AnyObject]
        }
        APIRequest.sharedAPI.updatePatientGeneralDetails(dictionary:dict, patientInfo: patientInfo!, completion: {
            (jsonString, successful, error, response) in
                if successful {
                    PatientManager.managePatientData(jsonString!)
                    dispatch_async(dispatch_get_main_queue(), {
                    self.handleResponse()
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    })
                } else {
                    super.handleError(error)
                }

        })
    }

}
