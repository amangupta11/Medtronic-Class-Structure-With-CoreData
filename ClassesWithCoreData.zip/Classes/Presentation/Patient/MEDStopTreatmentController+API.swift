//  MEDStopTreatmentController+API.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import Foundation
extension MEDStopTreatmentController {
    func requestToCancelTreatment(requestDict: NSMutableDictionary?) {
        checkInternet()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.cancelTreatment(requestDict!, completion: { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToHome()
                } else {
                    var errorMessage = StringConstants.ErrorTitle
                    let title = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    if(response?.statusCode == 403) {
                        // Present custom alert
                        self.showCustomAlertWithOneButton(title, message: errorMessage, alertTag:stopTreatmentAlertTags.AlreadyTransfered)
                    } else {
                        super.showAlert(title, alertMsg:errorMessage)
                    }

                }
            })
        })
}
}
