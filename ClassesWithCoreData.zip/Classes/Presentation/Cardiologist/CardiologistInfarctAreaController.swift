//  CardiologistInfarctAreaControllerViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class CardiologistInfarctAreaController: MEDBaseViewController, AlertViewControllerProtocol {
    
    @IBOutlet weak var infarctAreaView: UIView!
    @IBOutlet weak var infractAreaTableView: UITableView!
    @IBOutlet weak var imageViewShadowImageView: UIImageView!
    @IBOutlet weak var ecgReportImageView: UIImageView!
    @IBOutlet weak var imageCaptureContainerView: UIView!
    @IBOutlet weak var viewECGButtonOutlet: UIButton!
    @IBOutlet weak var infarctAreaTableViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var infarctAreaViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var imageViewHeightConstraint: NSLayoutConstraint!
    var otherCommentsPlaceholderLabel:UILabel!
    var doneButton = UIBarButtonItem()
    var ecgImage: UIImage? = nil
    var infractAreaArray: NSMutableArray? = nil
    var isNavigateToCardiologistScreen: Bool = false
    var isTextViewMarkedRed = false
    var otherCommentsTextView: UITextView? = nil
    enum CardilogistInfarctAreaStringConstants: String {
        case otherCommentsCellIdentifier = "CardiologistInfarctAreaOtherCommentsCell"
        case infarctAreaCellIdentifier = "InfarctAreaCell"
    }
    enum AlertViewTags: Int {
        case AlreadyReviewdTag = 1001
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp("")
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        if !isCaseExist()
        {
            showReviewedAlert()
            return
        }
        super.viewWillAppear(animated)
        updateUI()
    }
    override func viewDidAppear(animated: Bool) {
        addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func isCaseExist()-> Bool {
        return patientInfo != nil && patientInfo!.patientHistory != nil
    }
    
    private func showReviewedAlert(){
        let alertClass = AlertController()
        alertClass.delegate = self
        let message = NSLocalizedString(NotificationConstants.AlreadyReviewed, comment: "")
        let alertController = alertClass.showSimpleAlert(StringConstants.ErrorTitle, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
        alertController.view.tag = AlertViewTags.AlreadyReviewdTag.rawValue
    }
    
    func OKButtonAction(alertController: UIAlertController) {
        
    }
    
    func cancelButtonAction(alertController: UIAlertController) {
        
    }
    
    func defaultButtonAction(alertController: UIAlertController) {
        if alertController.view.tag == AlertViewTags.AlreadyReviewdTag.rawValue {
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
    
}


// MARK: - Custom Actions
extension CardiologistInfarctAreaController {
    override func initialSetUp(bgImage: String) {
        self.setTapGestureForView()
        setNavigationBackButtonImage()
        loadInfractAreas()
        checkUserRole()
    }
    func checkUserRole(){
        let user = LoginManager.getLoggedInUser()
        if (user != nil) {
            print(user?.roleID)
            switch (user?.roleID)! as String {
            case "3":
                self.navigationItem.rightBarButtonItem = nil// chatIcon
                 handleScreenUIForCardio()
            case "7":
                self.navigationItem.rightBarButtonItem = nil// chatIcon
                handleScreenUIForOnCallCardio()
            default: break
            }
        }
    }
    func handleScreenUIForOnCallCardio(){
        imageViewHeightConstraint.constant = 0
        infarctAreaViewHeightConstraint.constant = 0
        infarctAreaTableViewTopConstraint.constant = 0
        self.title = "Edit Infarct Area"
        infarctAreaView.hidden = true
        imageViewShadowImageView.hidden = true
        isNavigateToCardiologistScreen = true
    }
    
    func handleScreenUIForCardio(){
        setTapActionOnImageView()
        self.title = "ECG"
    }
    func getNavigationRightBarButtonItem() {
        doneButton = UIBarButtonItem(title: "Done", style: .Plain, target: self, action: nil)
        let color : UIColor = UIColor.whiteColor()
        let titleFont : UIFont = UIFont(name: "effra-regular", size: 17.0)!
        let attributes = [
            NSForegroundColorAttributeName : color,
            NSFontAttributeName : titleFont
        ]
        doneButton.setTitleTextAttributes(attributes, forState: UIControlState.Normal)
        self.navigationItem.rightBarButtonItem = doneButton
    }
    override func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        tapGesture.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tapGesture)
    }
    // Handling tap on Main ui view
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func updateUI() {
        //Take values from here and update the UI
        var infractKeys = [patientInfo?.patientHistory?.anteroseptal, patientInfo?.patientHistory!.anterior, patientInfo?.patientHistory!.lateral, patientInfo?.patientHistory!.extensiveanterolateral, patientInfo?.patientHistory!.inferior, patientInfo?.patientHistory!.posterior, patientInfo?.patientHistory!.rightsided, patientInfo?.patientHistory!.leftmainstem, patientInfo?.patientHistory!.others]
        
        for i in 0..<self.infractAreaArray!.count {
            let dict = self.infractAreaArray!.objectAtIndex(i).mutableCopy()
            dict.setValue(infractKeys[i]?.boolValue, forKey: StringConstants.IsChecked)
            self.infractAreaArray!.replaceObjectAtIndex(i, withObject: dict as! NSDictionary)
            
        }
        
        // storing the textview Comments
        if let _ = self.patientInfo?.patientHistory?.otherscomments {
            let otherCommentsDict = self.infractAreaArray!.objectAtIndex(self.infractAreaArray!.count-1).mutableCopy()
            otherCommentsDict.setValue(patientInfo!.patientHistory!.otherscomments, forKey: StringConstants.OtherCommentsText)
            self.infractAreaArray!.replaceObjectAtIndex(self.infractAreaArray!.count-1, withObject: otherCommentsDict as! NSDictionary)
        } else {
            let otherCommentsDict = self.infractAreaArray!.objectAtIndex(self.infractAreaArray!.count-1).mutableCopy()
            otherCommentsDict.setValue(nil, forKey: StringConstants.OtherCommentsText)
            self.infractAreaArray!.replaceObjectAtIndex(self.infractAreaArray!.count-1, withObject: otherCommentsDict as! NSDictionary)
        }
        
        // image presentation
        
        if let _ = ecgImage {
            self.setImageToImageView(ecgImage!)
        }
        // Reload the infract area table view
        self.infractAreaTableView.reloadData()
    }
    func setImageToImageView(image: UIImage) {
        self.ecgReportImageView.image = image
    }
    func configureCellData(cell: MEDPatientInfractAreaTableViewCell, indexpath: NSIndexPath) {
        let infractDict = infractAreaArray![indexpath.section] as? NSMutableDictionary
        cell.checkMarkButtonOutlet.tag = indexpath.section
        cell.checkMarkButtonOutlet.selected = false
        let dict = self.infractAreaArray!.objectAtIndex(cell.checkMarkButtonOutlet.tag).mutableCopy() as? NSMutableDictionary
        if(dict![StringConstants.IsChecked]?.boolValue == true) {
            cell.checkMarkButtonOutlet.selected = true
        }
        cell.infractAreaLabel.text = infractDict?.valueForKey(StringConstants.InfractAreaNameKey) as? String
        cell.stElevationLabel.text = infractDict?.valueForKey(StringConstants.StElevationNameKey) as? String
    }
    
    
    func configureOtherCommentsCell(cell: MEDPatientInfractAreaTableViewCell, indexPath: NSIndexPath) {
        cell.otherCommentsCheckedButton.tag = indexPath.section
        let dict = infractAreaArray!.objectAtIndex(self.infractAreaArray!.count - 1) as? NSMutableDictionary
        if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == false {
            // Other comments is not selected
            cell.otherCommentsTextView.hidden = true
            cell.otherCommentsCheckedButton.selected = false
            cell.otherCommentsCellBgImage.image = UIImage(named: "shadowImageBackground")
            self.isTextViewMarkedRed = false
        } else {
            // Other comments is selected
            cell.otherCommentsTextView.hidden = false
            cell.otherCommentsCheckedButton.selected = true
            cell.otherCommentsCellBgImage.image = UIImage(named: StringConstants.otherCommentsCellBGImageKey)
            let otherCommentsDict = self.infractAreaArray!.objectAtIndex(self.infractAreaArray!.count - 1).mutableCopy()
            if let _ = otherCommentsDict.valueForKey(StringConstants.OtherCommentsText) {
                if (otherCommentsDict.valueForKey(StringConstants.OtherCommentsText)  as! String) != "" {
                    cell.otherCommentsTextView.text = (otherCommentsDict.valueForKey(StringConstants.OtherCommentsText) as! String)
                    cell.otherCommentsTextView.textColor = ColorPicker.lightBlackColor()
                } else {
                    // No comments in the text view. Show the default string
                    cell.otherCommentsPlaceholderLabel.hidden = false
                }
            } else {
                cell.otherCommentsPlaceholderLabel.hidden = false
            }
            
            if(cell.otherCommentsTextView.text == nil) {
                cell.otherCommentsPlaceholderLabel.hidden = false
                
            }
        }
        self.otherCommentsTextView = cell.otherCommentsTextView
        self.otherCommentsPlaceholderLabel = cell.otherCommentsPlaceholderLabel
        handleTextViewUI(cell.otherCommentsTextView)
    }
    func handleTextViewUI(textView: UITextView) {
        if self.isTextViewMarkedRed == false {
            self.normalizeOtherCommentsTextView(textView)
        } else {
            self.highlightOtherCommentsTextView(textView)
        }
    }
    
    func highlightOtherCommentsTextView(textView: UITextView) {
        textView.layer.borderColor = UIColor.redColor().CGColor
        textView.layer.borderWidth = 0.5
        
    }
    func normalizeOtherCommentsTextView(textView: UITextView) {
        textView.layer.borderColor = ColorPicker.lightBlueGray2().CGColor
        textView.layer.borderWidth = 1
    }
    
    func otherCommentsCheckMarkButtonTapped(sender: UIButton) {
        self.updateDataSource(sender)
        UIView.performWithoutAnimation {
            self.infractAreaTableView.reloadRowsAtIndexPaths([ NSIndexPath(forRow: 0, inSection: self.infractAreaArray!.count-1)], withRowAnimation: UITableViewRowAnimation.Top)
        }
        let indexPath = NSIndexPath(forRow: 0, inSection: sender.tag)
        self.infractAreaTableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: UITableViewScrollPosition.Bottom, animated: true)
        
        // Hide and show the text view
        
    }
    
    func updateDataSource(sender: UIButton) {
        var isChecked = false
        switch sender.selected {
        case false:
            
            isChecked = true
            sender.selected = true
            
        case true:
            isChecked = false
            sender.selected = false
            
        }
        let dict = self.infractAreaArray!.objectAtIndex(sender.tag).mutableCopy()
        dict.setValue(isChecked, forKey: StringConstants.IsChecked)
        print(self.infractAreaArray!.objectAtIndex(sender.tag).valueForKey(StringConstants.IsChecked)?.boolValue)
        print(dict.valueForKey(StringConstants.IsChecked)?.boolValue)
        self.infractAreaArray!.replaceObjectAtIndex(sender.tag, withObject: dict as! NSDictionary)
    }
    func loadInfractAreas() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.infractAreaArray = metaDataPList.objectForKey("InfractAreaDetails")?.mutableCopy() as? NSMutableArray
        }
    }
    
    func setTapActionOnImageView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(CardiologistInfarctAreaController.imageTapped(_:)))
        self.ecgReportImageView.userInteractionEnabled = true
        self.ecgReportImageView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func imageTapped(img: AnyObject) {
        //Present ecg preview controller screen to zoom in and out
        self.presenetECGImagePreviewScreen()
        
    }
    
    func presenetECGImagePreviewScreen() {
        let ecgPreviewScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgPreviewScreenSBID) as? MEDPatientECGPreviewViewController
        ecgPreviewScreen?.ecgImage = ecgImage
        ecgPreviewScreen?.hidesBottomBarWhenPushed = true
        ecgPreviewScreen?.title = "ECG"
        self.navigationController?.pushViewController(ecgPreviewScreen!, animated: true)
    }
    
    func getSelectedInfarctAreas() -> NSMutableArray {
        var i = 0
        let updatedArray = NSMutableArray()
        while i < self.infractAreaArray?.count {
            let dict = self.infractAreaArray?.objectAtIndex(i) as! NSDictionary
            if dict.valueForKey(StringConstants.IsChecked)?.boolValue == true {
                updatedArray.addObject(dict)
            } else {
                // Infarct area not selected . Do not update it
            }
            i += 1
        }
        return updatedArray
    }
    override func backButtonAction(button: UIButton) {
        if validateFields() {
            if(isNavigateToCardiologistScreen == true){
                navigateToOnCallCardiologistScreen()
            }else{
                navigateToCardiologistScreen()
            }
        }
    }
    func navigateToCardiologistScreen(){
        let vc = self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2] as! MEDCardiologistECGViewController
        if(patientInfo != nil && patientInfo?.patientHistory != nil)
        {
            updateTimeLineInfo()
            vc.loadInfractAreas()
            vc.infractAreaTableView.reloadData()
            vc.view.layoutIfNeeded()
            self.navigationController?.popViewControllerAnimated(true)
            return
        }
    }
    
    func navigateToOnCallCardiologistScreen(){
        let vc = self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2] as! MEDOnCallCardioDiagnosisVC
        if(patientInfo != nil && patientInfo?.patientHistory != nil)
        {
            updateTimeLineInfo()
            vc.loadInfractAreas()
            vc.infractAreaTableView.reloadData()
            vc.view.layoutIfNeeded()
            self.navigationController?.popViewControllerAnimated(true)
            return
        }
    }

    
    func updateTimeLineInfo() {
        for i in 0..<infractAreaArray!.count {
            let dict = self.infractAreaArray!.objectAtIndex(i).mutableCopy()
            let isChecked = dict.valueForKey(StringConstants.IsChecked) as! Bool
            switch i {
            case InfractAreaTag.anteroseptal.rawValue:
                patientInfo?.patientHistory!.anteroseptal = isChecked
                
            case InfractAreaTag.anterior.rawValue:
                patientInfo?.patientHistory!.anterior = isChecked
                
            case InfractAreaTag.lateral.rawValue:
                patientInfo?.patientHistory!.lateral = isChecked
                
            case InfractAreaTag.extensiveanterolateral.rawValue:
                patientInfo?.patientHistory!.extensiveanterolateral = isChecked
                
            case InfractAreaTag.inferior.rawValue:
                patientInfo?.patientHistory!.inferior = isChecked
                
            case InfractAreaTag.posterior.rawValue:
                patientInfo?.patientHistory!.posterior = isChecked
                
            case InfractAreaTag.rightsided.rawValue:
                patientInfo?.patientHistory!.rightsided = isChecked
                
            case InfractAreaTag.leftmainstem.rawValue:
                patientInfo?.patientHistory?.leftmainstem = isChecked
                
            case InfractAreaTag.otherComments.rawValue:
                
                if (isChecked) {
                    patientInfo?.patientHistory!.others = isChecked
                } else {
                    patientInfo?.patientHistory!.otherscomments = ""
                }
                
            case InfractAreaTag.other.rawValue:
                patientInfo?.patientHistory?.others = isChecked
                
            default:
                break
            }
        }
        // Updating textview data
        if self.otherCommentsTextView?.text != nil {
            self.patientInfo!.patientHistory!.otherscomments = self.otherCommentsTextView!.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
            if(self.patientInfo?.patientHistory?.otherscomments == "") {
                self.patientInfo?.patientHistory?.otherscomments = nil
                
            }
        }
    }
    
    func validateFields() -> Bool {
        var isValid = true
        let dict = infractAreaArray!.objectAtIndex(self.infractAreaArray!.count - 1) as? NSMutableDictionary
        if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == true {
            if self.otherCommentsTextView?.text == ""{
                let indexPath = NSIndexPath(forRow: 0, inSection: self.infractAreaArray!.count - 1)
                self.infractAreaTableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: UITableViewScrollPosition.Bottom, animated: true)
                self.highlightOtherCommentsTextView(self.otherCommentsTextView!)
                isValid = false
                self.isTextViewMarkedRed = true
            } else {
                if let _ = self.otherCommentsTextView {
                    normalizeOtherCommentsTextView(self.otherCommentsTextView!)
                }
            }
        }
        return isValid
    }
    
    // MARK: - Keyboard Notification Handling
    override func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(1.0, delay: 0.10, options: [], animations: { () -> Void in
                self.view.frame.origin.y = -keyboardSize.height+150
                }, completion: nil)
        }
    }
    override func keyboardWillHide(notification: NSNotification) {
        UIView.performWithoutAnimation {
            self.view.frame.origin.y = 64
        }
    }
    
    // MARK: - Handling Obervers
    override func addKeyboardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    override func removeKeyBoardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    
    
    
}

//MARK:- Text view delegates
extension CardiologistInfarctAreaController: UITextViewDelegate {
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        textView.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textView)
        return true
        
    }
    func textViewDidBeginEditing(textView: UITextView) {
        if self.otherCommentsPlaceholderLabel.hidden == false {
            textView.text = ""
            self.otherCommentsPlaceholderLabel.hidden = true
            textView.textColor = ColorPicker.lightBlackColor()
        }
    }
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text == ""{
            
            patientInfo?.patientHistory?.otherscomments = nil
            self.otherCommentsPlaceholderLabel.hidden = false
        }
    }
    func textViewDidChange(textView: UITextView) {
        let dict = self.infractAreaArray!.objectAtIndex(self.infractAreaArray!.count - 1).mutableCopy()
        if textView.text == "" {
            dict.setValue(nil, forKey:StringConstants.OtherCommentsText)
        } else {
            dict.setValue(textView.text, forKey: StringConstants.OtherCommentsText)
        }
        self.infractAreaArray!.replaceObjectAtIndex(self.infractAreaArray!.count-1, withObject: dict as! NSDictionary)
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        // Checking if the entered character is new line character
        // returning false if yes
        let charSet =  NSCharacterSet.newlineCharacterSet()
        if let _ = updatedString!.rangeOfCharacterFromSet(charSet) {
            return false
        }
        if (updatedString?.characters.count)! > 140 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}

// MARK: - tableView Delegate methods
extension CardiologistInfarctAreaController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.infractAreaArray!.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.section == 8 {
            let dict = infractAreaArray!.objectAtIndex(self.infractAreaArray!.count - 1) as? NSMutableDictionary
            if dict?.valueForKey(StringConstants.IsChecked)?.boolValue == false {
                return 50
            }
            return 127
        }
        return 50
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! MEDPatientInfractAreaTableViewCell
        if cell.reuseIdentifier == CardilogistInfarctAreaStringConstants.infarctAreaCellIdentifier.rawValue
        {
            self.updateDataSource(cell.checkMarkButtonOutlet)
        }
        else if cell.reuseIdentifier == CardilogistInfarctAreaStringConstants.otherCommentsCellIdentifier.rawValue
        {
            otherCommentsCheckMarkButtonTapped(cell.otherCommentsCheckedButton)
        }
    }
    
}

// MARK: - TableView Datasourse methods

extension  CardiologistInfarctAreaController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if indexPath.section == 8 {
            let cell = tableView.dequeueReusableCellWithIdentifier(CardilogistInfarctAreaStringConstants.otherCommentsCellIdentifier.rawValue, forIndexPath: indexPath) as! MEDPatientInfractAreaTableViewCell
            
            configureOtherCommentsCell(cell, indexPath: indexPath)
            return cell
        }
        
        let cell = tableView.dequeueReusableCellWithIdentifier(CardilogistInfarctAreaStringConstants.infarctAreaCellIdentifier.rawValue, forIndexPath: indexPath) as! MEDPatientInfractAreaTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }
    
}
