//  MEDTreatmentViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDTreatmentViewController: MEDBaseViewController {
    @IBOutlet var cathLabAcceptedDateLabel: UILabel!
    @IBOutlet var cathLabAcceptedSepLabel: UILabel!
    @IBOutlet var cathLabAcceptedButton: MEDSelectionCustomButton!
    @IBOutlet var cathLabAcceptedMaxAttempt: UILabel!
    @IBOutlet var cathLabAcceptedStrikeTime: UILabel!
    @IBOutlet var cathLabAcceptedPickerButton: MEDSelectionCustomButton!
    @IBOutlet var cathLabAcceptedDateOutlet: UIButton!
    @IBOutlet var cathLabExitDateOutlet: UIButton!
    @IBOutlet var deviceCrossTimeDateOutlet: UIButton!
    @IBOutlet var cathLabAcceptedTimeLabel: UILabel!
    @IBOutlet var cathLabAcceptedLineLabel: UILabel!
    @IBOutlet var cathLabExitLineLabel: UILabel!
    @IBOutlet var dctLineLabel: UILabel!
    @IBOutlet var dalButton: MEDSelectionCustomButton!
    @IBOutlet var dalLabel: UILabel!
    @IBOutlet var dalTimeLabel: UILabel!
    @IBOutlet var dalDateLabel: UILabel!
    @IBOutlet var dalMaxAttempt: UILabel!
    @IBOutlet var dalStrikeTime: UILabel!
    @IBOutlet var dalPickerButton: MEDSelectionCustomButton!
    @IBOutlet var treatmentCompleteButton: UIButton!
    @IBOutlet var cathLabExitButton: MEDSelectionCustomButton!
    @IBOutlet var cathLabExitStrikeTime: UILabel!
    @IBOutlet var cathLabExitPickerButton: MEDSelectionCustomButton!
    @IBOutlet var cathLabExitMaxAttempt: UILabel!
    @IBOutlet var cathLabExitTimeLabel: UILabel!
    @IBOutlet var cathLabExitDateLabel: UILabel!
    @IBOutlet weak var treatmentTimeView: UIView!
    @IBOutlet weak var cathLabReadyView: UIStackView!
    @IBOutlet weak var treatmentOverlayView: UIView!
    
    @IBOutlet weak var cathLabReadyInsideView: UIView!
    @IBOutlet weak var treatmentOverlayTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var treatmentViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var cathLabReadyTopConstraint: NSLayoutConstraint!
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    var pickerContainerView: UIView!
    struct CathLabTreatmentConstants {
        static var ConfirmationAlertTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static var SuccessfullAlertMsg = NSLocalizedString("TREATMENT_HAS_BEEN_COMPLETED", comment: "")
        static var CathLabAcceptedAlertMsg   = NSLocalizedString("ARE_SURE_YOU_WANT_TO_MARK_THIS_CASE_AS_CATH_LAB_ACCEPTED", comment: "")
        static var DeviceAcrossTimeAlertMsg   = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_MARK_THIS_CASE_AS_DEVICE_CROSS_TIME", comment: "")
        static var CathLabExitAlertMsg   =  NSLocalizedString("ARE_YOU_WANT_TO_MARK_THIS_CASE_AS_CATH_LAB_EXIT", comment: "")
        static var TreatmentCompleteAlertMsg   =   NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_MARK_THIS_CASE_AS_TREATMENT_COMPLETE", comment: "")
        static var CathLabReadyAlertMsg   =   NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_MARK_CATH_LAB_READY_FOR_THIS_CASE", comment: "")
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
        static  var StemiAlertMessage = NSLocalizedString("THE_CASE_HAS_NOT_BEEN_TRANSFERRED_TO_YOUR_DEPARTMENT", comment: "")
    }
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var thirdView: UIView!
    enum AlertViewTag: Int {
        case CathLabAccepted = 101
        case DeviceAcrossTime = 102
        case CathLabExit = 103
        case TreatmentCompleted = 104
        case CathLabReady = 105
    }
    let user = LoginManager.getLoggedInUser()
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()

    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            updateUI()
            checkUserRole()
            startTimer()
        }
    }
}
// MARK: -  @IBActions
extension MEDTreatmentViewController {
    
    @IBAction func cathLabAcceptedButtonAction(sender: AnyObject) {
        addPickerView(AlertViewTag.CathLabAccepted.rawValue)
    }
    @IBAction func deviceCrossTimeButtonAction(sender: AnyObject) {
        addPickerView(AlertViewTag.DeviceAcrossTime.rawValue)
    }
    @IBAction func cathLabExitButtonAction(sender: AnyObject) {
        addPickerView(AlertViewTag.CathLabExit.rawValue)
    }
    
    @IBAction func cathLabAcceptedButtonTapped(sender: AnyObject) {
        if(cathLabAcceptedButton.selected == false) {
            showConfirmationAlert(CathLabTreatmentConstants.ConfirmationAlertTitle, alertMsg: CathLabTreatmentConstants.CathLabAcceptedAlertMsg, tag:AlertViewTag.CathLabAccepted.rawValue)
        }
    }
    @IBAction func dalButtonTapped(sender: AnyObject) {
        if(cathLabAcceptedButton.selected == true && dalButton.selected == false) {
            showConfirmationAlert(CathLabTreatmentConstants.ConfirmationAlertTitle, alertMsg: CathLabTreatmentConstants.DeviceAcrossTimeAlertMsg, tag:AlertViewTag.DeviceAcrossTime.rawValue)
        }
    }
    @IBAction func cathLabExitButtonTapped(sender: AnyObject) {
        if(cathLabAcceptedButton.selected == true && dalButton.selected == true && cathLabExitButton.selected == false) {
            showConfirmationAlert(CathLabTreatmentConstants.ConfirmationAlertTitle, alertMsg: CathLabTreatmentConstants.CathLabExitAlertMsg, tag:AlertViewTag.CathLabExit.rawValue)
        }
    }
    @IBAction func cathLabAcceptedPickerButtonTapped(sender: AnyObject) {
        addPickerView(AlertViewTag.CathLabAccepted.rawValue)
    }

    @IBAction func dalPickerButtonTapped(sender: AnyObject) {
        addPickerView(AlertViewTag.DeviceAcrossTime.rawValue)
    }

    @IBAction func cathLabExitPickerButtonTapped(sender: AnyObject) {
        addPickerView(AlertViewTag.CathLabExit.rawValue)
    }
    @IBAction func treatmentButtonTapped(sender: AnyObject) {
        showConfirmationAlert(CathLabTreatmentConstants.ConfirmationAlertTitle, alertMsg: CathLabTreatmentConstants.TreatmentCompleteAlertMsg, tag:AlertViewTag.TreatmentCompleted.rawValue)
    }
    @IBAction func cathLabReadyButtonAction(sender: AnyObject) {
        showConfirmationAlert(CathLabTreatmentConstants.ConfirmationAlertTitle, alertMsg: CathLabTreatmentConstants.CathLabReadyAlertMsg, tag:AlertViewTag.CathLabReady.rawValue)
    }
}
// MARK: -  Custom Actions
extension MEDTreatmentViewController {
    func initialSetUp() {
        setNavigationBackButtonImage()
        addShadowToView()
    }
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    func addPickerView(tag: Int) {
        self.view.endEditing(true)
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        var date: NSDate
        date = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.spokeTransferTime as! Double)
        self.pickerContainerDelegate.datePicker.minimumDate = date
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
        self.pickerContainerView.tag = tag
        pickerViewValidation(tag)
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    func checkUserRole() {

        if (user != nil) {
            switch (user?.roleID)! as String {
            case UserRoles.GeneralPractitioner.rawValue:
                updateCathLabReadyUI()
                enableScreenToReadOnlyMode()
            case UserRoles.CATHLABPractitioner.rawValue:
                hideCathLabReadyView()
                if self.patientInfo?.caseStatus == status.Completed.rawValue {
                    enableScreenToReadOnlyMode()
                }
            default: break
            }
        }
    }
    func addShadowToView(){
        cathLabReadyInsideView.layer.masksToBounds = false
        cathLabReadyInsideView.layer.borderWidth = 1
        cathLabReadyInsideView.layer.borderColor = ColorPicker.warmGrey15().CGColor
        cathLabReadyInsideView.layer.shadowColor = ColorPicker.Black22().CGColor
        cathLabReadyInsideView.layer.shadowOffset = CGSizeMake(0.5, 0.5)
        cathLabReadyInsideView.layer.shadowOpacity = 1
        cathLabReadyInsideView.layer.shadowRadius = 1
    }
    func hideCathLabReadyView(){
        if (self.patientInfo?.caseStatus != status.STEMI.rawValue && self.patientInfo?.caseStatus != status.InTransit.rawValue && self.patientInfo?.caseStatus != status.InternalTransfer.rawValue) {
                updateCathLabReadyUI()
      }
        if (self.patientInfo?.caseStatus == status.STEMI.rawValue || self.patientInfo?.caseStatus == status.InTransit.rawValue || self.patientInfo?.caseStatus == status.InternalTransfer.rawValue) {
            if(self.patientInfo?.isCathLabReady == true){
                updateCathLabReadyUI()}
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        if(self.patientInfo?.caseStatus == status.STEMI.rawValue){
            alertView = alertController.showSimpleAlert(CathLabTreatmentConstants.AlertTitle, message:CathLabTreatmentConstants.StemiAlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        }
        else{
            alertView = alertController.showSimpleAlert(CathLabTreatmentConstants.AlertTitle, message:CathLabTreatmentConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)}
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func updateCathLabReadyUI(){
        self.cathLabReadyTopConstraint.constant = -cathLabReadyView.frame.size.height
        self.treatmentViewTopConstraint.constant = 0
        self.treatmentOverlayTopConstraint.constant = 0
        self.treatmentOverlayView.hidden = true
    }
    func animateCathLabready(){
        let yPosition = cathLabReadyView.frame.origin.y - cathLabReadyView.frame.size.height-10
        let height = cathLabReadyView.frame.size.height
        let width = cathLabReadyView.frame.size.width
        UIView.animateWithDuration(1.0, animations: {
            self.cathLabReadyView.frame = CGRectMake(10, yPosition, height, width)
            self.treatmentTimeView.frame = CGRectMake(0, 0, self.treatmentTimeView.frame.size.height+40, self.treatmentTimeView.frame.size.width+80)
            self.treatmentOverlayView.frame = CGRectMake(0, 0, self.treatmentOverlayView.frame.size.height, self.treatmentOverlayView.frame.size.width)
            self.cathLabReadyTopConstraint.constant = yPosition
            self.treatmentViewTopConstraint.constant = 0
            self.treatmentOverlayTopConstraint.constant = 0
        })
    }
    func navigateToHomeListScreen() {
        showSuccessfulAlert()
    }
    func pickerViewValidation(tag: Int) {
        switch tag {
        case AlertViewTag.CathLabAccepted.rawValue:
            validateCathLabAcceptedDateAndTime()
        case AlertViewTag.DeviceAcrossTime.rawValue:
            validateDATDateAndTime()
        case AlertViewTag.CathLabExit.rawValue:
            validateCathLabExitDateAndTime()
        default:
            break
        }
    }
    func updateUI() {
        enableCathLabAcceptedButton()
        enableDeviceCrossTimeButton()
        enableCathLabExitButton()
    }

    func enableScreenToReadOnlyMode() {
        cathLabAcceptedButton.userInteractionEnabled = false
        cathLabAcceptedDateOutlet.userInteractionEnabled = false
        deviceCrossTimeDateOutlet.userInteractionEnabled = false
        cathLabExitDateOutlet.userInteractionEnabled = false
        dalButton.userInteractionEnabled = false
        cathLabExitButton.userInteractionEnabled = false
        cathLabAcceptedPickerButton.hidden = true
        dalPickerButton.hidden = true
        cathLabExitPickerButton.hidden = true
        treatmentCompleteButton.hidden = true
        cathLabAcceptedMaxAttempt.hidden = true
        cathLabExitMaxAttempt.hidden = true
        dalMaxAttempt.hidden = true
        cathLabAcceptedDateLabel.textColor = ColorPicker.steelGreyColor()
        cathLabAcceptedTimeLabel.textColor = ColorPicker.steelGreyColor()
        dalDateLabel.textColor = ColorPicker.steelGreyColor()
        dalTimeLabel.textColor = ColorPicker.steelGreyColor()
        cathLabExitDateLabel.textColor = ColorPicker.steelGreyColor()
        cathLabExitTimeLabel.textColor = ColorPicker.steelGreyColor()
        cathLabAcceptedLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        dctLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        cathLabExitLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()

    }
    func enableCathLabAcceptedButton() {
        var cathLabAcceptedTime: Double
        if(patientInfo?.timeLine?.cathLabAcceptedTime != nil && patientInfo?.timeLine?.cathLabAcceptedTime != 0) {
            cathLabAcceptedTime =  (patientInfo?.timeLine?.cathLabAcceptedTime as? Double)!
            let cathLabAcceptedTimeString = DateUtility.convertGMTtoTime(cathLabAcceptedTime)
            let cathLabAcceptedDateString = DateUtility.convertGMTtoShortDate(cathLabAcceptedTime)
            cathLabAcceptedDateLabel.text = cathLabAcceptedDateString
            cathLabAcceptedTimeLabel.text = cathLabAcceptedTimeString
            cathLabAcceptedButton.selected = true
            cathLabAcceptedSepLabel.backgroundColor = ColorPicker.peaGreenColor()
            cathLabAcceptedDateLabel.textColor = ColorPicker.charcoalGrey()
            cathLabAcceptedTimeLabel.textColor = ColorPicker.charcoalGrey()
            cathLabAcceptedPickerButton.hidden = false
            self.cathLabAcceptedDateOutlet.userInteractionEnabled = true
            
            self.cathLabAcceptedMaxAttempt.text =  ButtonTitles.attemptRemainingString
            if Int((patientInfo?.timeLine?.cathLabAcceptedEditCount)!) == 3 {
                self.cathLabAcceptedMaxAttempt.hidden = true
                self.cathLabAcceptedPickerButton.hidden = true
                self.cathLabAcceptedDateOutlet.userInteractionEnabled = false
                changeStatusOfCADateAndTimeLabel((self.patientInfo?.timeLine?.cathLabAcceptedEditCount)!)
            }
            else{
                self.cathLabAcceptedMaxAttempt.text =  "\(3 - Int((patientInfo?.timeLine?.cathLabAcceptedEditCount)!)!)" + ButtonTitles.attemptsRemainingString
            }
            let editedText  = patientInfo?.timeLine?.cathLabAcceptedEditedText
            if let _ = editedText {
                self.cathLabAcceptedStrikeTime.attributedText = StringUtility.strikeText(editedText!)
            } else {
                self.cathLabAcceptedStrikeTime.text = ""
            }
        } else {
            if (user?.roleID)! as String == UserRoles.GeneralPractitioner.rawValue {
                firstView.hidden=true
                cathLabAcceptedButton.hidden=true
                secondView.hidden=true
                cathLabExitButton.hidden=true
                dalButton.hidden=true
                thirdView.hidden=true
                dalLabel.hidden=true
                cathLabAcceptedSepLabel.hidden=true
            }

        }
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func enableDeviceCrossTimeButton() {
        var datTime: Double
        if(patientInfo?.timeLine?.deviceCrossTime != nil && patientInfo?.timeLine?.deviceCrossTime != 0) {
            datTime = (patientInfo?.timeLine?.deviceCrossTime as? Double)!
            let datTimeString = DateUtility.convertGMTtoTime(datTime)
            let datDateString = DateUtility.convertGMTtoShortDate(datTime)
            dalDateLabel.text = datDateString
            dalTimeLabel.text = datTimeString
            dalButton.selected = true
            dalLabel.backgroundColor = ColorPicker.peaGreenColor()
            dalDateLabel.textColor = ColorPicker.charcoalGrey()
            dalTimeLabel.textColor = ColorPicker.charcoalGrey()
            dalPickerButton.hidden = false
            self.deviceCrossTimeDateOutlet.userInteractionEnabled = true
            
            self.dalMaxAttempt.text =  ButtonTitles.attemptRemainingString
            if Int((patientInfo?.timeLine?.deviceCrossTimeEditCount)!) == 3 {
                self.dalMaxAttempt.hidden = true
                self.dalPickerButton.hidden = true
                self.deviceCrossTimeDateOutlet.userInteractionEnabled = false
                changeStatusOfDATDateAndTimeLabel((self.patientInfo?.timeLine?.deviceCrossTimeEditCount)!)
            }
            else{
                self.dalMaxAttempt.text =  "\(3 - Int((patientInfo?.timeLine?.deviceCrossTimeEditCount)!)!)" + ButtonTitles.attemptsRemainingString
            }
            
            let editedText  = patientInfo?.timeLine?.deviceCrossTimeEditedText
            if let _ = editedText {
                self.dalStrikeTime.attributedText = StringUtility.strikeText(editedText!)
            } else {
                self.dalStrikeTime.text = ""
            }
        } else {
            if (user?.roleID)! as String == UserRoles.GeneralPractitioner.rawValue {
                secondView.hidden=true
                cathLabExitButton.hidden=true
                dalButton.hidden=true
                thirdView.hidden=true
                dalLabel.hidden=true
                cathLabAcceptedSepLabel.hidden=true

            }

        }
    }
    func enableCathLabExitButton() {
        var cathLabExitTime: Double
        if(patientInfo?.timeLine?.cathLabExitTime != nil && patientInfo?.timeLine?.cathLabExitTime != 0) {
            cathLabExitTime = (patientInfo?.timeLine?.cathLabExitTime as? Double)!
            let cathLabExitTimeString = DateUtility.convertGMTtoTime(cathLabExitTime)
            let cathLabExitDateString = DateUtility.convertGMTtoShortDate(cathLabExitTime)
            cathLabExitDateLabel.text = cathLabExitDateString
            cathLabExitTimeLabel.text = cathLabExitTimeString
            cathLabExitButton.selected = true
            cathLabExitDateLabel.textColor = ColorPicker.charcoalGrey()
            cathLabExitTimeLabel.textColor = ColorPicker.charcoalGrey()
            cathLabExitPickerButton.hidden = false
            treatmentCompleteButton.hidden = false
            self.cathLabExitDateOutlet.userInteractionEnabled = true
            self.cathLabExitMaxAttempt.text =  ButtonTitles.attemptRemainingString
            if Int((patientInfo?.timeLine?.cathLabExitEditCount)!) == 3 {
                self.cathLabExitMaxAttempt.hidden = true
                self.cathLabExitPickerButton.hidden = true
                self.cathLabExitDateOutlet.userInteractionEnabled = false
                changeStatusOfCEDateAndTimeLabel((self.patientInfo?.timeLine?.cathLabExitEditCount)!)
            }
            else{
                self.cathLabExitMaxAttempt.text =  "\(3 - Int((patientInfo?.timeLine?.cathLabExitEditCount)!)!)" + ButtonTitles.attemptsRemainingString
            }

            let editedText  = patientInfo?.timeLine?.cathLabExitEditedText
            if let _ = editedText {
                self.cathLabExitStrikeTime.attributedText = StringUtility.strikeText(editedText!)
            } else {
                self.cathLabExitStrikeTime.text = ""
            }
        } else {
            if (user?.roleID)! as String == UserRoles.GeneralPractitioner.rawValue {

                cathLabExitButton.hidden=true
                dalLabel.hidden=true
                thirdView.hidden=true
            }

        }

    }
    func changeStatusOfCADateAndTimeLabel(count: String) {
        let numberFromString = Int(count)
        if numberFromString >= 3 {
            self.cathLabAcceptedDateLabel.textColor = ColorPicker.steelGreyColor()
            self.cathLabAcceptedTimeLabel.textColor = ColorPicker.steelGreyColor()
            cathLabAcceptedLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        } else {
            self.cathLabAcceptedDateLabel.textColor = ColorPicker.charcoalGrey()
            self.cathLabAcceptedTimeLabel.textColor = ColorPicker.charcoalGrey()
            cathLabAcceptedLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
    }
    func changeStatusOfDATDateAndTimeLabel(count: String) {
        let numberFromString = Int(count)
        if numberFromString >= 3 {
            self.dalDateLabel.textColor = ColorPicker.steelGreyColor()
            self.dalTimeLabel.textColor = ColorPicker.steelGreyColor()
            dctLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        } else {
            self.dalDateLabel.textColor = ColorPicker.charcoalGrey()
            self.dalTimeLabel.textColor = ColorPicker.charcoalGrey()
            dctLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
    }
    func changeStatusOfCEDateAndTimeLabel(count: String) {
        let numberFromString = Int(count)
        if numberFromString >= 3 {
            self.cathLabExitDateLabel.textColor = ColorPicker.steelGreyColor()
            self.cathLabExitTimeLabel.textColor = ColorPicker.steelGreyColor()
            cathLabExitLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        } else {
            self.cathLabExitDateLabel.textColor = ColorPicker.charcoalGrey()
            self.cathLabExitTimeLabel.textColor = ColorPicker.charcoalGrey()
            cathLabExitLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
    }
    func showConfirmationAlert(alertTile: String, alertMsg: String, tag: Int) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: "NO", cancelTitle: "YES", prefereredStyle: UIAlertControllerStyle.Alert, tag:tag)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func showSuccessfulAlert() {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showSimpleAlert("", message:CathLabTreatmentConstants.SuccessfullAlertMsg, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
}
//MARK: - Alert view delegates
extension MEDTreatmentViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        let alertTag =  alertController.view.tag
        switch alertTag {
        case AlertViewTag.CathLabAccepted.rawValue:
            patientInfo?.timeLine?.cathLabAcceptedTime  = DateUtility.getCurrentTimeInGMT()
            performCathLabAcceptedCall()
        case AlertViewTag.DeviceAcrossTime.rawValue:
            patientInfo?.timeLine?.deviceCrossTime  = DateUtility.getCurrentTimeInGMT()
            patientInfo?.timeLine?.stoppedTime = DateUtility.getCurrentTimeInGMT()
            performDeviceCrossTimeCall()
        case AlertViewTag.CathLabExit.rawValue:
            patientInfo?.timeLine?.cathLabExitTime  = DateUtility.getCurrentTimeInGMT()
            performCathLabExitCall()
        case AlertViewTag.TreatmentCompleted.rawValue:
            patientInfo?.timeLine?.treatmentCompletedTime  = DateUtility.getCurrentTimeInGMT()
            performTreatmentCompleteCall()
        case AlertViewTag.CathLabReady.rawValue:
            performCathLabReady()
        default:
            break
        }
    }
    func OKButtonAction(alertController: UIAlertController) {
        ActivityIndicatorView.sharedActivityView.hideOverlayView()
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        self.navigateToHome()
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}
// MARK: - Picker Delegates
extension MEDTreatmentViewController: pickerViewProtocol {
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        let pickerViewTag =  self.pickerContainerView.tag
        switch pickerViewTag {
        case AlertViewTag.CathLabAccepted.rawValue:
            self.cathLabAcceptedDateLabel.text = selectedDate
            self.cathLabAcceptedTimeLabel.text = selectedTime
            let dateString = String(format: "%@ %@", self.cathLabAcceptedDateLabel.text!, self.cathLabAcceptedTimeLabel.text!)
            patientInfo?.timeLine?.cathLabAcceptedTime = DateUtility.convertStringToDate(dateString)
            performCathLabAcceptedCall()
        case AlertViewTag.DeviceAcrossTime.rawValue:
            self.dalDateLabel.text = selectedDate
            self.dalTimeLabel.text = selectedTime
            let dateString = String(format: "%@ %@", self.dalDateLabel.text!, self.dalTimeLabel.text!)
            patientInfo?.timeLine?.deviceCrossTime = DateUtility.convertStringToDate(dateString)
            performDeviceCrossTimeCall()
        case AlertViewTag.CathLabExit.rawValue:
            self.cathLabExitDateLabel.text = selectedDate
            self.cathLabExitTimeLabel.text = selectedTime
            let dateString = String(format: "%@ %@", self.cathLabExitDateLabel.text!, self.cathLabExitTimeLabel.text!)
            patientInfo?.timeLine?.cathLabExitTime = DateUtility.convertStringToDate(dateString)
            performCathLabExitCall()
        default:
            break
        }
    }
}
// MARK: - Picker Validation
extension MEDTreatmentViewController {
    func validateCathLabAcceptedDateAndTime() {
        var minDate: NSDate
        var maxDate: NSDate
        if(dalButton.selected == false) {
            if (patientInfo?.timeLine?.hubInternalTransferTime != nil && patientInfo?.timeLine?.hubInternalTransferTime != 0 ) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.hubInternalTransferTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }
            else if(patientInfo?.timeLine?.hubDoorInTime != nil && patientInfo?.timeLine?.hubDoorInTime != 0) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.hubDoorInTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }else if(patientInfo?.timeLine?.fmcDoorOutTime != nil && patientInfo?.timeLine?.fmcDoorOutTime != 0) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.fmcDoorOutTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }
            maxDate = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
            self.pickerContainerDelegate.datePicker.maximumDate = maxDate
        } else {
            if (patientInfo?.timeLine?.hubInternalTransferTime != nil && patientInfo?.timeLine?.hubInternalTransferTime != 0 && patientInfo?.timeLine?.deviceCrossTime != nil) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.hubInternalTransferTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }else if(patientInfo?.timeLine?.hubDoorInTime != nil && patientInfo?.timeLine?.hubDoorInTime != 0 && patientInfo?.timeLine?.deviceCrossTime != nil) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.hubDoorInTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }else if(patientInfo?.timeLine?.fmcDoorOutTime != nil && patientInfo?.timeLine?.fmcDoorOutTime != 0 && patientInfo?.timeLine?.deviceCrossTime != nil) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.fmcDoorOutTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
            }
            maxDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.deviceCrossTime as! Double)
            self.pickerContainerDelegate.datePicker.maximumDate = maxDate
        }
    }
    func validateDATDateAndTime() {
        var minDate: NSDate
        var maxDate: NSDate
        if(cathLabExitButton.selected == false) {
            if patientInfo?.timeLine?.cathLabAcceptedTime != nil {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.cathLabAcceptedTime as! Double)
                maxDate = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
                self.pickerContainerDelegate.datePicker.maximumDate = maxDate
            }
        } else {
            if (patientInfo?.timeLine?.cathLabAcceptedTime != nil && patientInfo?.timeLine?.cathLabExitTime != nil) {
                minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.cathLabAcceptedTime as! Double)
                maxDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.cathLabExitTime as! Double)
                self.pickerContainerDelegate.datePicker.minimumDate = minDate
                self.pickerContainerDelegate.datePicker.maximumDate = maxDate
            }
        }
    }
    func validateCathLabExitDateAndTime() {
        var minDate: NSDate
        var maxDate: NSDate
        if patientInfo?.timeLine?.deviceCrossTime != nil {
            minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.deviceCrossTime as! Double)
            maxDate = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
            self.pickerContainerDelegate.datePicker.minimumDate = minDate
            self.pickerContainerDelegate.datePicker.maximumDate = maxDate
        }
    }
}
