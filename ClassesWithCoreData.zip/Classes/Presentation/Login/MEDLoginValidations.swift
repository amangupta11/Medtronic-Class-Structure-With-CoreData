//  MEDLoginValidations.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit
// MARK: - RegixExpression Methods
class MEDLoginValidations: NSObject {
        class  func isValidUserName(userNameStr: String) -> Bool {
            let userNameRegex = "[A-Z0-9a-z]{5,15}"
            let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
            return UserNameTest.evaluateWithObject(userNameStr)
        }
        class  func isValidPassword(passwordStr: String) -> Bool {
            let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[#?!@$%_{},.<>;:/|\"()~^&*])[A-Za-z\\d#?!@$%_{},.<>;:/|\"()~^&*]{6,8}"
            let PasswordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegex)
            return PasswordTest.evaluateWithObject(passwordStr)
        }
}
