//  MEDLoginViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDLoginViewController {
    func getUserDetails() {
        checkInternet()
            let user = LoginManager.getLoggedInUser()
            if (user != nil) {
                APIRequest.sharedAPI.getUserDetails(usertoken:user?.userID as! String, completion: { (jsonString, successful, error, response) in
                    dispatch_async(dispatch_get_main_queue(), {
                        self.performNavigation()
                    })
                })
            }

    }
    
    func performLogin() {
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.requestLogin(username: userEmailTextField.text!, password:passwordTextField.text!,chanelId: NotificationManager.chanelId()) { (data, successful, error, response)in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                     self.getUserDetails()
                } else {
                    var errorMessage = " "
                    var title = StringConstants.ErrorTitle

                    if let error = error {
                        errorMessage = error.localizedDescription
                        if( error.localizedFailureReason?.isEmpty == false ) {
                            title = error.localizedFailureReason!
                        }
                    }
                    self.clearPasswordTextField(nil)
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    super.showAlert(title, alertMsg:errorMessage)
                }
            })
        }
    }
}
