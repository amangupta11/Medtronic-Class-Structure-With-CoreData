//
//  MEDSettingsViewController+API.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 15/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
extension MEDSettingsViewController {

    func performLogout() {
        checkInternet()
        var user = LoginManager.getLoggedInUser()
        if user != nil {
        let userID = (user?.userID!)! as! String
        APIRequest.sharedAPI.requestLogout(userid:  userID, chanelId: NotificationManager.chanelId(), completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Success
                    self.handleLogoutSuccess()

                } else {
                    super.handleError(error)
                }
            })
        })
        }

    }

}
