//  MEDSettingsViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDSettingsViewController: MEDBaseViewController {
    

    @IBOutlet weak var versionLbl: UILabel!
    @IBOutlet weak var phoneLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var hospitalLbl: UILabel!
    @IBOutlet weak var designationLabel: UILabel!
    @IBOutlet weak var personNameLabel: UILabel!
    let contentArr = ["My Account","Feedback","About and Help","Logout"]
    let imgArr = ["myAccount","feedback","about","logout"]
        struct RoleNameConstants {
        static var NurseOrPractioner = "Nurse/Practitioner"
        static var CathLabPractioner = "Cath Lab Assistant"
        static var Cardiologist = "Cardiologist"
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    enum PersonGender: String {
        case Male = "0"
        case Female = "1"
    }
    // MARK: - UIView Life Cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp(nil)
    }
    override func viewDidAppear(animated: Bool) {
        dispatch_async(dispatch_get_main_queue(), {
            self.updateUI()
        })

    }
}
// MARK: - Custom Actions
extension MEDSettingsViewController {
    override func initialSetUp(bgImage: String?) {
        setBuildVersion()
    }
    func setBuildVersion() {
        versionLbl.text = getBuildVersion()
        hospitalLbl.hidden = false
    }
    func updateUI() {
        let user = LoginManager.getLoggedInUser()
        print(user?.hospitalName)
        print(user?.emailAddress)
        print(user?.designation)
        print(user?.hospitalName)
        print(user?.phoneNumber)
        if (user != nil) {
            self.personNameLabel.text = ((user?.title)!) + " " + ((user?.firstName)! as! String) + " " + ((user?.lastName)! as! String)
            self.phoneLbl.text = ((user?.countryCode)! as! String) + " " + ((user?.phoneNumber)! as! String)
            self.emailLbl.text = user?.emailAddress as? String
            self.hospitalLbl.text = (user?.hospitalName)! as String
            self.designationLabel.text = user?.designation
            print(user?.roleID)
            if (user?.roleID == "3") {
            self.setUserRole(user!)
            }
            //setUserImage(user!)
        }
    }
    func setUserRole(user: UserInfo) {
        let userRole: String = (user.roleID)! as String
        switch userRole {
        case "1": break
           // self.designationLabel.text = user.hospitalName! + " - " + RoleNameConstants.NurseOrPractioner
        case "2": break
           // self.designationLabel.text = user.hospitalName! + " - " + RoleNameConstants.CathLabPractioner
        case "3":
            //self.designationLabel.text = /*user.hospitalName! + " - " +*/ RoleNameConstants.Cardiologist
            self.hospitalLbl.hidden = true
        default:
            break
        }
    }
    func setUserImage(user: UserInfo) {
        if(user.gender == PersonGender.Male.rawValue) {
           // personImage.image = UIImage(named: "personImage")
        } else {
           // personImage.image = UIImage(named: "personImage")
        }
    }
    func handleLogoutSuccess() {
        dispatch_async(dispatch_get_main_queue(), {
            let notificationManager = NotificationManager()
            notificationManager.stop()
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            let sessionManager = UIApplication.sharedApplication() as! SessionManager
            sessionManager.navigateToLogin()
        }) }

}

// MARK: - tableView Delegate methods
extension MEDSettingsViewController: UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = UIView()
        view.backgroundColor = UIColor.clearColor()
        return view
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 7
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.contentArr.count
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 52
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.row == 3{
            ActivityIndicatorView.sharedActivityView.showOverlay()
            PatientManager.clearCache { (successful) in
                self.performLogout()
            }
        }
    }
}

// MARK: - TableView Datasourse method
extension  MEDSettingsViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        tableView.scrollEnabled = false
        tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        let cell = tableView.dequeueReusableCellWithIdentifier("settingsCellIdentifier", forIndexPath: indexPath) as! MEDSettingsCustomCell
        cell.descriptionLbl.text = self.contentArr[indexPath.row]
        cell.iconImgView.image = UIImage(named: (imgArr[indexPath.row]))
        return cell
    }
}

// MARK: -  IBActions methods
extension MEDSettingsViewController {
    @IBAction func logoutButtonAction(sender: AnyObject) {
        // Moving the user to login screen
        ActivityIndicatorView.sharedActivityView.showOverlay()
        PatientManager.clearCache { (successful) in
            self.performLogout()
        }
    }
}
