//  MEDNotificationViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import CoreData

private let CellId = "MEDNotificationCell"

class MEDNotificationViewController: MEDBaseViewController, UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate {
    
    @IBOutlet weak var noNetworkHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var noNetworkView: UIStackView!
    @IBOutlet weak var notificationTableView: UITableView!
    var refreshControl: UIRefreshControl!
    var notifications = [Notification]()
    var emptyView: UIView!
    var refreshScreen: Bool = false
    var emptyListLabel: UILabel!
    
    struct NotificationStringConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
        loadData()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarItem.badgeValue = String(UIApplication.sharedApplication().applicationIconBadgeNumber)
        refreshControl.endRefreshing()
        updateNoNetworkView()
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        if(appDelegate!.refreshScreen == true){
            self.onPullToRefresh()
        }
    }
    
    func loadData()
    {
        ActivityIndicatorView.sharedActivityView.showOverlay()
        getNotifications()
    }
    
    func scrollToTop()
    {
        if notificationTableView != nil && notificationTableView.numberOfRowsInSection(0) > 0
        {
            notificationTableView.scrollToRowAtIndexPath(NSIndexPath.init(forRow: 0, inSection: 0), atScrollPosition: .Top, animated: true)
        }
    }
    
    private func configureUI() {
        notificationTableView.tableFooterView = UIView(frame:CGRect.zero)
        notificationTableView.contentInset = UIEdgeInsetsMake(5, 0, 5, 0);

        refreshControl = UIRefreshControl()
        refreshControl!.addTarget(self, action: #selector(MEDNotificationViewController.onPullToRefresh), forControlEvents: UIControlEvents.ValueChanged)
        notificationTableView.insertSubview(self.refreshControl!, atIndex: 0)
        createEmptyView()
    }
    
    func onPullToRefresh()
    {
        getNotifications()
    }
    
    func updateData(notifs: [Notification]) {
        notifications = notifs
        notificationTableView.hidden = false
        refreshControl.endRefreshing()
        notificationTableView.reloadData()
        emptyView!.hidden = notifications.count > 0
        updateNoNetworkView()
        updateBadge()
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notifications.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(
            CellId, forIndexPath: indexPath) as! MEDNotificationCell
        if notifications.count > indexPath.row
        {
            let notification = notifications[indexPath.row]
            cell.hospitalCaseIdLabel.text = notification.hospitalCaseID
            cell.messageLabel.text = notification.message
            cell.timestampLabel.text = notification.timeAgo
            cell.read(notification.isRead)
        }
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if !NetworkUtil.isConnected(){
            self.showAlert(NetworkStringConstants.NetworkConnectionAlertTitle, alertMsg: NSLocalizedString(NetworkStringConstants.NetworkConnectionAlertMsg, comment: ""))
            updateNoNetworkView()
            return
        }
        let caseId = read(indexPath)
        showCaseDetails(caseId)
    }
    
    private func showCaseDetails(caseId: String)
    {
        if fetchCaseDetails(caseId)
        {
            return
        }
        getAllCases({ (isSuccessful) in
            if isSuccessful
            {
                if !self.fetchCaseDetails(caseId)
                {
                    self.showAlert(StringConstants.ErrorTitle, alertMsg: NSLocalizedString(NotificationConstants.AlreadyReviewed, comment: ""))
                }
            }
        })
    }
    
    private func read(indexPath: NSIndexPath) -> String
    {
        let cell = notificationTableView.cellForRowAtIndexPath(indexPath) as! MEDNotificationCell
        cell.read(true)
        let notification: Notification = notifications[indexPath.row]
        notification.isRead = true
        updateBadge()
        self.markAsRead(notification)
        return notification.caseID
    }
    
    private func badgeCount() -> Int
    {
        return notifications.filter{$0.isRead == false}.count
    }
    
    private func updateBadge()
    {
        let tabBarController = self.tabBarController as! MEDTabBarController
        tabBarController.updateBadge(badgeCount())
    }
    
    private func fetchCaseDetails(caseId : String) ->Bool {
        if let patient = PatientInfo.getPatientForCaseID(caseId)
        {
            let user = LoginManager.getLoggedInUser()
            let roleID = (user?.roleID!)! as String
            if roleID == UserRoles.Cardiologist.rawValue {
                getUndiagnosedCaseDetails(patient)
            }
            else if(roleID == UserRoles.OnCallCardiologist.rawValue){
                checkOncallCardioStatus(patient)}
            else {
                getCaseDetails(patient)
            }
            return true
        }
        return false
    }
    func checkOncallCardioStatus(patient:PatientInfo){
        if(patient.caseStatus == status.Undiagnosed.rawValue){
            getUndiagnosedCaseDetails(patient)
        }
        else{
            getCaseDetails(patient)
        }
    }
    
    func navigateToCardiologist() {
        let vc: MEDCardiologistECGViewController = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.cardiologistDignoseViewControllerSBID) as! MEDCardiologistECGViewController
        vc.patientInfo = self.patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func navigateToOnCallCardiologist() {
        let vc: MEDOnCallCardioDiagnosisVC = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.OnCallCardiologistSBID) as! MEDOnCallCardioDiagnosisVC
        vc.patientInfo = self.patientInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func navigateToHome() {
        if let navigationController = self.tabBarController!.viewControllers!.first as? UINavigationController
        {
            (navigationController.viewControllers.first as! MEDHomeViewController).shouldTableViewRefresh = true
            navigationController.popToRootViewControllerAnimated(true)
            self.tabBarController?.selectedIndex = 0

        }
    }
    
    func navigateToSummary(patient: PatientInfo) {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let summaryVC = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.viewSummaryScreenSBID) as! MEDViewSummaryViewController
        summaryVC.patientInfo = patient
        self.navigationController?.pushViewController(summaryVC, animated: true)
    }
    
    func navigateToPatient(patient: PatientInfo) {
        let storyBoard = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle:nil)
        let patientVC = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.patientBaseViewControllerSBID) as! MEDPatientBaseContainerView
        patientVC.patientInfo = patient
        self.navigationController?.pushViewController(patientVC, animated: true)
    }
    
    func navigateToDiagnosis() {
        let storyboard = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil)
        let cardioVC = storyboard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.cardiologistDignoseViewControllerSBID) as! MEDCardiologistECGViewController
        cardioVC.patientInfo = self.patientInfo
        self.navigationController?.pushViewController(cardioVC, animated: true)
    }
    
    private func updateNoNetworkView()
    {
        if NetworkUtil.isConnected() {
            noNetworkHeightConstraint.constant = 0
            noNetworkView.hidden = true
        }
        else{
            noNetworkHeightConstraint.constant = 28
            noNetworkView.hidden = false
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(NotificationStringConstants.AlertTitle, message:NotificationStringConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    
    private func createEmptyView()
    {
        let totalHeight : CGFloat = 95
        let totalWidth = self.view.frame.size.width
        var originY = (self.view.frame.size.height - totalHeight)/3
        self.emptyView = UIView()
        emptyView!.frame = CGRectMake(0, originY, totalWidth, totalHeight)
        emptyView.backgroundColor = UIColor.clearColor()
        notificationTableView.addSubview(emptyView!)
        notificationTableView.sendSubviewToBack(emptyView!)
        
        let bellSize : CGFloat = 62
        let originX = (totalWidth - bellSize)/2
        let bellImageView = UIImageView()
        bellImageView.frame = CGRectMake(originX, 0, bellSize, bellSize)
        bellImageView.image = UIImage.init(named : "BellIcon")
        bellImageView.contentMode = .ScaleAspectFit
        emptyView!.addSubview(bellImageView)
        
        originY = bellImageView.frame.size.height + 10
        emptyListLabel = UILabel()
        emptyListLabel!.font = UIFont.init(name: "effra-regular", size: 18)
        emptyListLabel!.textAlignment = .Center
        emptyListLabel!.textColor = ColorPicker.ligthGrey()
        emptyListLabel!.frame = CGRectMake(10, originY, totalWidth - 20, 23)
        emptyListLabel!.text = NSLocalizedString(NotificationConstants.NoRecords, comment: "")
        emptyView!.addSubview(emptyListLabel!)
    }
    
}
//MARK: - Alert view delegates
extension MEDNotificationViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
        // Moving the user to home listing screen
        self.navigateToHome()
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}
