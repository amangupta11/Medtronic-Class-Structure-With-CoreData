//  MEDSpokeNurseTimeLineViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDSpokeNurseTimeLineViewController {
func pushFMCDoorOutForPatient() {
   checkInternet()
    var dict: NSDictionary? = nil


    var fmcDoorOutTime: [String:AnyObject] = [:]
    fmcDoorOutTime[TimeLineKey.Comment.rawValue] = nil
    fmcDoorOutTime[TimeLineKey.Location.rawValue] = nil
    fmcDoorOutTime[TimeLineKey.Time.rawValue] = patientInfo?.timeLine?.fmcDoorOutTime?.stringValue

    dict = [PatientInfoKey.CaseID.rawValue:(patientInfo?.caseID)!, TimeLineKey.FmcDoorOutTime.rawValue:fmcDoorOutTime]

    APIRequest.sharedAPI.pushFMCDetails(dict, completion: {
        (jsonString, successful, error, response) in
        dispatch_async(dispatch_get_main_queue(), {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            if successful {
                self.navigateToHome()
            } else {
                if(response?.statusCode == 403){
                    self.showUnauthorizationAlert()
                }
                else{
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                }
            }
        })
    })
}
}
