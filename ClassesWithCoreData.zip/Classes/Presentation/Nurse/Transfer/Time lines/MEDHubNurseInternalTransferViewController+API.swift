//  MEDHubNurseInternalTransferViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import Foundation
// MARK: -  Server Interaction
extension MEDHubNurseInternalTransferViewController {
    func checkPatientStatus(completion:(successful: Bool) -> Void) {
        checkInternet()
        let dict = [PatientInfoKey.CaseID.rawValue:patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.checkPatientStatus(dictionary:dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    completion(successful: successful)
                } else {
                    super.handleError(error)
                }
            })
        })
    }
    func performHubNurseInternalTransfer() {
         checkInternet()
        patientInfo?.timeLine?.hubInternalTransferTime  = DateUtility.getCurrentTimeInGMT()
        var dict: NSDictionary? = nil

        var hubInternalTransferTime: [String:AnyObject] = [:]
        hubInternalTransferTime[TimeLineKey.Comment.rawValue] = nil
        hubInternalTransferTime[TimeLineKey.Location.rawValue] = nil
        hubInternalTransferTime[TimeLineKey.Time.rawValue] = patientInfo?.timeLine?.hubInternalTransferTime?.stringValue


        dict = [PatientInfoKey.CaseID.rawValue:(patientInfo?.caseID)!, "internalTransferTime":hubInternalTransferTime]

        APIRequest.sharedAPI.performHubNurseInternalTransfer(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToHomeListScreen()
                    //Save Patient info
                } else {
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    if(response?.statusCode == 425) {
                        // Present custom alert
                        self.showAttentionAlert()
                    } else {
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
}
