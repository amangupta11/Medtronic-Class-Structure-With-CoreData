//  MEDHubNurseTimeLineViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDHubNurseTimeLineViewController {

    func editHubDoorInTime() {
        checkInternet()
        var dict: NSDictionary? = nil

        var hubDoorInTime: [String:AnyObject] = [:]
        hubDoorInTime[TimeLineKey.Comment.rawValue] = nil
        hubDoorInTime[TimeLineKey.Location.rawValue] = nil
        hubDoorInTime[TimeLineKey.Time.rawValue] = patientInfo?.timeLine?.hubDoorInTime?.stringValue

        dict = [PatientInfoKey.CaseID.rawValue:(patientInfo?.caseID)!, TimeLineKey.HubDoorInTime.rawValue:hubDoorInTime ]
        APIRequest.sharedAPI.udpateHubDooInTime(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Success
                    self.updateUIAfterEditingHubDoorInTime()
                    self.updateUI()
                } else {
                    super.handleError(error)

                }
            })
        })

    }
    func performHubNurseInternalTransfer() {
        checkInternet()
        patientInfo?.timeLine?.hubInternalTransferTime  = DateUtility.getCurrentTimeInGMT()
        var dict: NSDictionary? = nil
        var hubInternalTransferTime: [String:AnyObject] = [:]
        hubInternalTransferTime[TimeLineKey.Comment.rawValue] = nil
        hubInternalTransferTime[TimeLineKey.Location.rawValue] = nil
        hubInternalTransferTime[TimeLineKey.Time.rawValue] = patientInfo?.timeLine?.hubInternalTransferTime?.stringValue

        dict = [PatientInfoKey.CaseID.rawValue:(patientInfo?.caseID)!, "internalTransferTime":hubInternalTransferTime]
        APIRequest.sharedAPI.performHubNurseInternalTransfer(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToHomeListScreen()
                    //Save Patient info
                } else {
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    if(response?.statusCode == 425) {
                        // Present custom alert
                        self.showCustomAlertWithOneButton(HubNurseTimeLineConstants.AttentionTitle, message: errorMessage, alertTag: hubDoorInCustomAlertTags.AlreadyTransfered)
                    } else {
                         super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }


                }
            })
        })
    }

}
