//  MEDSpokeNurseTimeLineViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.
import UIKit

class MEDSpokeNurseTimeLineViewController: MEDBaseViewController {
    @IBOutlet weak var maxAttemptsLabel: UILabel!
    @IBOutlet var callButton: UIButton!
    @IBOutlet weak var doorOutTimeContainerView: UIView!
    @IBOutlet weak var hospitalContainerView: UIView!
    @IBOutlet weak var doorOutButtonOutlet: UIButton!
    @IBOutlet weak var doorOutDateLabel: UILabel!
    @IBOutlet weak var doorOutTimeLabel: UILabel!
    @IBOutlet weak var hospitalNameLabel: UILabel!
    @IBOutlet var doorOutAtFmcOutlet: UIButton!
    @IBOutlet var doorOutAtFmcLineLable: UILabel!
    @IBOutlet weak var fmcDoorOutEditedTextLabel: UILabel!
    
    @IBOutlet weak var checkMarkButtonOutlet: MEDSelectionCustomButton!
    @IBOutlet weak var fmcDoorOutLineSepLabel: UILabel!
    @IBOutlet weak var fmcDoorOutButtonOutlet: MEDSelectionCustomButton!
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    var pickerContainerView: UIView!
    struct SpokeNurseStringConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            startTimer()
        }
    }
}

// MARK: - @IBAction Actions
extension MEDSpokeNurseTimeLineViewController: pickerViewProtocol {
    
    @IBAction func checkButtonMarked(sender: AnyObject) {
        if(checkMarkButtonOutlet.selected == false) {
         addPickerForDoorOutAtHub()
        }
    }
    @IBAction func doorOutButtonAction(sender: AnyObject) {
        addPickerForDoorOutAtHub()
    }
    
    @IBAction func doorOutButtonTapped(sender: AnyObject) {
        addPickerForDoorOutAtHub()
    }
    @IBAction func callButtonAction(sender: AnyObject) {
        if(self.callButton.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((callButton.titleLabel?.text)!)
        }
    }
}

// MARK: - Custom Actions
extension MEDSpokeNurseTimeLineViewController {
    override func backButtonAction(button: UIButton) {
      let secondTopViewController = self.navigationController?.viewControllers[((self.navigationController?.viewControllers.count)! - 2)]
        if let _ = secondTopViewController as? MEDViewSummaryViewController {
            self.navigationController?.popViewControllerAnimated(true)
        } else {
            // Came from hospital listing screen
            // Moving to Home Listing screen
            navigateToHome()
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(SpokeNurseStringConstants.AlertTitle, message:SpokeNurseStringConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }

    func addPickerForDoorOutAtHub(){
        self.view.endEditing(true)
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        var minDate: NSDate
        var maxDate: NSDate
        minDate = NSDate(timeIntervalSince1970: patientInfo?.timeLine?.spokeTransferTime as! Double)
        maxDate = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
        self.pickerContainerDelegate.datePicker.minimumDate = minDate
        self.pickerContainerDelegate.datePicker.maximumDate = maxDate
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    override func initialSetUp(bgImage: String) {
        self.setNavigationBackButtonImage()
        updateUI()
    }
    func changeStatusOfDoorOutTimeButton(count: String) {
        let numberFromString = Int(count)
        if numberFromString >= 3 {
            self.doorOutTimeLabel.textColor = ColorPicker.steelGreyColor()
            self.doorOutDateLabel.textColor = ColorPicker.steelGreyColor()
            self.doorOutAtFmcLineLable.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        } else {
            self.doorOutTimeLabel.textColor = ColorPicker.charcoalGrey()
            self.doorOutDateLabel.textColor = ColorPicker.charcoalGrey()
            self.doorOutAtFmcLineLable.backgroundColor = ColorPicker.warmGreyColor()
        }
    }

        func updateUI() {
        if let _ = self.patientInfo?.treatmentInfo {
            self.hospitalNameLabel.text = self.patientInfo?.treatmentInfo?.hospitalName?.uppercaseString
            }
        if(patientInfo?.timeLine?.fmcDoorOutTime != nil && patientInfo?.timeLine?.fmcDoorOutTime != 0){
        let fmcDoorOutTime = patientInfo?.timeLine?.fmcDoorOutTime as? Double
        let doorOutTimeString = DateUtility.convertGMTtoTime(fmcDoorOutTime!)
        self.doorOutTimeLabel.text = doorOutTimeString
        let fmcDoorOutDate = patientInfo?.timeLine?.fmcDoorOutTime as? Double
        let fmcDoorOutDateString = DateUtility.convertGMTtoShortDate(fmcDoorOutDate!)
        self.doorOutDateLabel.text = fmcDoorOutDateString
        self.fmcDoorOutButtonOutlet.selected = true
        self.fmcDoorOutLineSepLabel.backgroundColor = ColorPicker.peaGreenColor()
        self.doorOutTimeLabel.textColor = ColorPicker.charcoalGrey()
        self.doorOutDateLabel.textColor = ColorPicker.charcoalGrey()
            }
        let countryCode =  patientInfo?.treatmentInfo?.countryCode
        let mobileNumber = patientInfo?.treatmentInfo?.phoneNumber
            if(mobileNumber != nil) {
                if(countryCode != nil && mobileNumber!.isEmpty == false) {
                    self.callButton.setTitle((countryCode)! +  (mobileNumber)! as String, forState: .Normal)
                }
            }
            self.doorOutAtFmcOutlet.userInteractionEnabled = true
            self.maxAttemptsLabel.text =  ButtonTitles.attemptRemainingString
            if Int((patientInfo?.timeLine?.fmcDoorOutEditCount)!) == 3 {
                self.maxAttemptsLabel.hidden = true
                self.doorOutButtonOutlet.hidden = true
                self.doorOutAtFmcOutlet.userInteractionEnabled = false
                self.changeStatusOfDoorOutTimeButton((self.patientInfo?.timeLine?.fmcDoorOutEditCount)!)
            }
            else{
                self.maxAttemptsLabel.text =  "\(3 - Int((patientInfo?.timeLine?.fmcDoorOutEditCount)!)!)" + ButtonTitles.attemptsRemainingString
            }
        let editedText  = patientInfo?.timeLine?.fmcDoorOutEditedText
        if let _ = editedText {
        self.fmcDoorOutEditedTextLabel.attributedText = StringUtility.strikeText(editedText!)
        } else {
            self.fmcDoorOutEditedTextLabel.text = ""
        }
            // Putting validation for fmc door out
            // Disabling the fmc door out button when hub door in set
            if patientInfo?.timeLine?.hubDoorInTime != nil {
                self.maxAttemptsLabel.hidden = true
                self.doorOutButtonOutlet.hidden = true
                self.doorOutAtFmcOutlet.userInteractionEnabled = false
                self.doorOutTimeLabel.textColor = ColorPicker.steelGreyColor()
                self.doorOutDateLabel.textColor = ColorPicker.steelGreyColor()
                self.doorOutAtFmcLineLable.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
            }
    }
}

// MARK: - Picker Delegates
extension MEDSpokeNurseTimeLineViewController {
     func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        self.doorOutDateLabel.text = selectedDate
        self.doorOutTimeLabel.text = selectedTime
        let dateString = String(format: "%@ %@", self.doorOutDateLabel.text!, self.doorOutTimeLabel.text!)
        patientInfo?.timeLine?.fmcDoorOutTime = DateUtility.convertStringToDate(dateString)
        pushFMCDoorOutForPatient()
    }
}
//MARK: - Alert view delegates
extension MEDSpokeNurseTimeLineViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
        // Moving the user to home listing screen
        self.navigateToHome()
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}
