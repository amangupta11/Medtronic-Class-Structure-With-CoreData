//  MEDHubNurseInternalTransferViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit

class MEDHubNurseInternalTransferViewController: MEDBaseViewController {
    @IBOutlet weak var cathLabReadyCallButton: UIButton!
    @IBOutlet weak var cathLabReadyLabel: UILabel!
    @IBOutlet weak var cathLabReadyView: UIView!
    struct InternalTransferConstants {
        static var AttentionAlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static var AttentionAlertMsg   =  NSLocalizedString("THIS_CASE_HAS_ALREADY_BEEN_TRANSFERED", comment: "")
        static var ConfirmationAlertTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static var ConfirmationAlertMsg   =  NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_TRANSFER_THIS_CASE_TO_CATH_LAB", comment: "")
        static var cathLabReady = NSLocalizedString("CATH_LAB_IS_READY", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            updateUI()
            startTimer()
        }
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
    }
}
// MARK: -  Custom Actions
extension MEDHubNurseInternalTransferViewController {
    override func initialSetUp(bgImage: String) {
        self.setNavigationBackButtonImage()
    }
    override func backButtonAction(button: UIButton) {
        DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popViewControllerAnimated(true)
    }
    func navigateToHomeListScreen() {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func CheckPatientCaseStatus() {
        self.showConfirmationAlert(InternalTransferConstants.ConfirmationAlertTitle, alertMsg:InternalTransferConstants.ConfirmationAlertMsg)
    }
    func updateUI(){
        if(patientInfo?.isCathLabReady == true){
            self.cathLabReadyView.backgroundColor = ColorPicker.peaGreenColor()
            self.cathLabReadyLabel.text = InternalTransferConstants.cathLabReady
        }
        let countryCode = patientInfo?.treatmentInfo?.countryCode as String!
        let mobileNumber = patientInfo?.treatmentInfo?.phoneNumber as String!
        if(mobileNumber != nil) {
            if(countryCode != nil && mobileNumber.isEmpty == false) {
                self.cathLabReadyCallButton.titleLabel?.text = countryCode + mobileNumber
            }
        }
    }
    func showAttentionAlert() {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showSimpleAlert(InternalTransferConstants.AttentionAlertTitle, message: InternalTransferConstants.AttentionAlertMsg, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func showConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTile, message: alertMsg, okTitle:NSLocalizedString("NO", comment: ""), cancelTitle: NSLocalizedString("YES", comment: ""), prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
}
// MARK: - @IBAction Actions
extension MEDHubNurseInternalTransferViewController {
    @IBAction func transferToCathlabButtonTapped(sender: AnyObject) {
        CheckPatientCaseStatus()
    }
    @IBAction func cathLabReadyCallAction(sender: AnyObject) {
        if(self.cathLabReadyCallButton.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((cathLabReadyCallButton.titleLabel?.text)!)
        }
    }
}

// MARK: - AlertView delegates
extension MEDHubNurseInternalTransferViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        performHubNurseInternalTransfer()
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
}
