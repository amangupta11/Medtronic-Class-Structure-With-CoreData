//  MEDHospitalListViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import SwiftyJSON
class MEDHospitalListViewController: MEDBaseViewController {
    @IBOutlet var hospitalListTable: UITableView!
    var hospitalListArray: [JSON] = []
    var cellBgView: UIView!
    var selectedPath: NSIndexPath!
    var hospitalNameValue: String!
    var hospitalID: String!
    var currentAlertViewTag: customAlertTags!
    enum cellBgImage: String {
        case UnSelected = "hospitalListBgImage"
        case Selected = "hospitalListSelectedBgImage"
    }
    enum customAlertTags: Int {
        case AlreadyTransfered = 101
    }
    struct HospitalListStringConstants {
        static  var CellIdentifier = "HospitalListCell"
    }
    struct HospitalListConstants {
        static var ConfirmationAlertTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static var TransferAlertMsg   = NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_TRANSFER_THE_CASE", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            startTimer()
        }
    }
}
// MARK: -  Custom Actions
extension MEDHospitalListViewController {
    func deselectCell() {
        let cell = self.hospitalListTable.cellForRowAtIndexPath(self.selectedPath) as! MEDHospitalListTableViewCell
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) {
            dispatch_async(dispatch_get_main_queue()) {
                cell.hospitalListBgImage.image = UIImage(named:cellBgImage.UnSelected.rawValue)
            }
        }
    }
    func initialSetUp() {
        setNavigationBackButtonImage()
    }
    func configureCellData(cell: MEDHospitalListTableViewCell, indexpath: NSIndexPath) {
        let json = hospitalListArray[indexpath.row]
        let countryCode = json["countryCode"].stringValue
        let mobileNumber = json["phoneNumber"].stringValue
        cell.hospitalName.text = json["name"].stringValue.uppercaseString
        cell.callButton.titleLabel?.text = countryCode + mobileNumber
        cell.hospitalListBgImage.tintColor = UIColor.whiteColor()
    }
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    func showTransferConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertMsg = alertMsg + "  \n" + (hospitalNameValue.uppercaseString)  + "?"
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: "NO", cancelTitle: "YES", prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func navigateToSpokeNurseTimeLine() {
        let spokeNurseTimelineController: MEDSpokeNurseTimeLineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.spokeNurseTimelineScreenSBID) as! MEDSpokeNurseTimeLineViewController
        spokeNurseTimelineController.patientInfo = patientInfo
        self.navigationController?.pushViewController(spokeNurseTimelineController, animated: true)
    }

    //MARK: - Custom alert view
    func showCustomAlertWithOneButton(alertTitle: String, message: String, alertTag: customAlertTags) {

        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        currentAlertViewTag = alertTag
        alertView = alertController.showSimpleAlert(alertTitle, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)

    }


  }
// MARK: -  @IBAction Methods
extension MEDHospitalListViewController {
}
// MARK: - tableView Delegate methods
extension MEDHospitalListViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 6
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hospitalListArray.count
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
}
// MARK: - tableView DataSource methods
extension  MEDHospitalListViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(HospitalListStringConstants.CellIdentifier, forIndexPath: indexPath) as! MEDHospitalListTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! MEDHospitalListTableViewCell
        cell.hospitalListBgImage.image = UIImage(named:cellBgImage.Selected.rawValue)
        let json = hospitalListArray[indexPath.row]
        let id = json["hospitalID"].stringValue
        hospitalNameValue = cell.hospitalName.text
        selectedPath = indexPath
        hospitalID =  id
        showTransferConfirmationAlert(HospitalListConstants.ConfirmationAlertTitle, alertMsg:HospitalListConstants.TransferAlertMsg)
    }
}


//MARK: - Alert view delegates
extension MEDHospitalListViewController: AlertViewControllerProtocol {
     func cancelButtonAction(alertController: UIAlertController) {
        deselectCell()
        performSpokeTransfer()
    }
     func OKButtonAction(alertController: UIAlertController) {
        deselectCell()
        alertController.dismissViewControllerAnimated(true, completion: nil)
      }
    func defaultButtonAction(alertController: UIAlertController) {
        switch self.currentAlertViewTag.rawValue {
        case 101:
            alertController.dismissViewControllerAnimated(true, completion: nil)
            // Moving the user to home listing screen
            self.navigationController?.popToRootViewControllerAnimated(true)
        default:
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }

    }

}
