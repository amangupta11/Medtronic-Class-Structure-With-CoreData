//  MEDHospitalListTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit

class MEDHospitalListTableViewCell: UITableViewCell {
    @IBOutlet var mapIconButton: UIButton!
    @IBOutlet var hospitalListView: UIView!
    @IBOutlet var hospitalListBgImage: UIImageView!
    @IBOutlet var callButton: UIButton!
    @IBOutlet var hospitalName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    // MARK: - @IBAction Methods
    @IBAction func callButtonAction(sender: AnyObject) {
        if(self.callButton.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((callButton.titleLabel?.text)!)
        }
    }
}
