//
//  APIRequest+PatientHistory.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 28/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
import SwiftyJSON
extension APIRequest {

    func convertNSDataToDictionary(data: NSData) -> [String: AnyObject]? {
        do {
            return try NSJSONSerialization.JSONObjectWithData(data, options: .MutableContainers) as? [String: AnyObject]
        } catch let myJSONError {
            print(myJSONError)
        }
        return nil
    }

    
// MARK: - getMedicalConditions
func getMedicalConditions(patientInfo: PatientInfo, completion: (jsonString: [String:AnyObject]?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
    let request = postJSONRequest(getConditionsInfo, isCookieTobeAdded:true)
    let params = [PatientInfoKey.CaseID.rawValue:(patientInfo.caseID)!, PatientInfoKey.RsaPublicKey.rawValue:CryptoUtility.publicKeyForJava()]
    do {
        print("*********Request JSON********: \(params):")
        request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params,
                                                                      options: NSJSONWritingOptions.PrettyPrinted)
    } catch {
        print("HTTPBody error:\n \(error)")
    }
    sendRequest(request) { (innerData, innerSuccessful, error, response) in
        if let loginError = error {
            completion(jsonString:nil, successful:false, error:loginError, response: response)
        } else {
            let json = self.convertNSDataToDictionary(innerData!)  //JSON(data:innerData!)
            if (json![ExceptionConstants.ExpnCode] != nil) {
                // Failure
                let logError = self.handleErrorForDict(json!)
                completion(jsonString:nil, successful:false, error:logError, response: response)
            } else {
                // Success
                completion(jsonString:json!, successful:true, error:nil, response: response)
            }
        }
    }
}
    // MARK: - getMedicalHistory
    func getMedicalHistory(patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getMedicalHistoryInfo, isCookieTobeAdded:true)
        let params = [PatientInfoKey.CaseID.rawValue:(patientInfo.caseID)!, PatientInfoKey.RsaPublicKey.rawValue:CryptoUtility.publicKeyForJava()]
        do {
            print("*********Request JSON********: \(params):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }
    
    // MARK: - getClinicalExamination
    func getClinicalExamination(patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getClinicalExaminationInfo, isCookieTobeAdded:true)
        let params = [PatientInfoKey.CaseID.rawValue:(patientInfo.caseID)!, PatientInfoKey.RsaPublicKey.rawValue:CryptoUtility.publicKeyForJava()]
        do {
            print("*********Request JSON********: \(params):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }

        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }
    // MARK: - saveMedicalHistory
    func saveMedicalHistory(requestDict: NSMutableDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(setMedicalHistoryInfo, isCookieTobeAdded:true)
        do {
//            let patientJson = requestDict
            print("*********Request JSON********: \(requestDict):")
          let jsonData =    try NSJSONSerialization.dataWithJSONObject(requestDict, options: NSJSONWritingOptions.PrettyPrinted)
            request.HTTPBody = jsonData
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }
    
    // MARK: - saveClinicalExamination
    func saveClinicalExamination(requestDict: NSMutableDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(setClinicalExaminationInfo, isCookieTobeAdded:true)
        do {
            //            let patientJson = requestDict
            print("*********Request JSON********: \(requestDict):")
            let jsonData =    try NSJSONSerialization.dataWithJSONObject(requestDict, options: NSJSONWritingOptions.PrettyPrinted)
            request.HTTPBody = jsonData
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }

}
