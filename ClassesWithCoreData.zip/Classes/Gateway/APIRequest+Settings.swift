//
//  APIRequest+Settings.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 15/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
import SwiftyJSON
extension APIRequest {
    // MARK: - Logout Functions
    func requestLogout(userid userid: String, chanelId: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(userLogout, isCookieTobeAdded:true)
       request.setValue(chanelId, forHTTPHeaderField: StringConstants.ChannelID)
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
}
