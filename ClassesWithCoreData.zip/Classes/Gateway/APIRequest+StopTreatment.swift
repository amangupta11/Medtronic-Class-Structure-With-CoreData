//
//  APIRequest+StopTreatment.swift
//  Medtronic
//
//  Created by Aman Gupta on 3/13/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import Foundation
import SwiftyJSON
extension APIRequest {
    
    // MARK: - ECG Tab Functions
    func cancelTreatment(requestDict: NSMutableDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        
        let request = postJSONRequest(cancelTreatments, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(requestDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
}