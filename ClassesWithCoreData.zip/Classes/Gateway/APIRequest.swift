//  APIRequest.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Foundation
import SwiftyJSON
struct ExceptionConstants {
    static var ExpnCode = "expnCode"//"error"//
    static var ExpnCause = "expnCause"//"error_description"//
}
struct APIRequestsConstants {
    static var InternalServerError = "Internal Server Error"
    static var Couldnotconnecttoserver = "Could not connect to server"
    static var TokenExpired = "Token Expired"
    static var InvalidUsernameorPasswordTitle = "Invalid Username or Password"
    static var InvalidUsernameorPasswordMsg = "The username or password you entered is incorrect. Please try again."
    static var AccessTokenExpired = "Your request could not be compeleted right now, please try again after sometime."
    static var Attention = "Attention!"
    static var Forbidden = "Forbidden"
    static var InvalidTokenTitle = "Token Expired"
    static var InvalidTokenMessage = "Invalid Access Token, Please login again"
    static var SessionExpMessage = "Your session has expired. Please login again."
    static var InactiveUserMessage = "Your account is inactive. Please contact the system administrator."
    static var UnauthorizeAccessMessage = "There has been an update on this case. Your request could not be completed."

}
enum APIError: Int {
    case incomplete    = -2
    case unknown_error = -1
    case invalid_grant = 0
    case UnableToLocateUser
    case MobileVerificationCodeSendError
    case MobileVerificationErrorInvalidCode
    case PasswordChangeErrorInvalidResetCode
    case MobileVerificationErrorInvalidPhoneID
    case MobileVerificationError
    case NoContactInfo
    case PasswordResetCodeSendError
    static func enumFromString(string: String) -> APIError {
        var i = 0
        while let item = APIError(rawValue: i) {
            if String(item) == string { return item }
            i += 1
        }
        return .unknown_error
    }
}
//protocol AlertControllerProtocol {
//    func defaultButtonAction(alertController: UIAlertController)
//}
class APIRequest: NSObject, NSURLSessionDelegate {
    let testingApiBaseURL: String = baseURL
    // MARK: - Shared Instance
    class var sharedAPI: APIRequest {
        struct Singleton {
            static let instance = APIRequest()
        }
        return Singleton.instance
    }
    
    // MARK: - Generic HTTP API Requests
    func getRequest(apiFunction: String, httpMethod: String = "GET") -> NSMutableURLRequest {
        let url = NSURL(string: "\(testingApiBaseURL)\(apiFunction)")!
        let request = NSMutableURLRequest(URL: url)
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.HTTPMethod = httpMethod
        request.timeoutInterval = 60
        return request
    }
    func getJSONRequest(apiFunction: String, httpMethod: String = "GET", isCookieTobeAdded: Bool) -> NSMutableURLRequest {
        let request = getRequest(apiFunction, httpMethod: httpMethod)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("0.0", forHTTPHeaderField: "Protocol-Version")
        if(isCookieTobeAdded == true) {
            let user = LoginManager.getLoggedInUser()
            let token = user?.token as! String
            if (token != "") {
                request.addValue(token, forHTTPHeaderField: "Authorization")}
        }
        return request
    }
    func postRequest(apiFunction: String, httpMethod: String = "POST") -> NSMutableURLRequest {
        let url = NSURL(string: "\(testingApiBaseURL)\(apiFunction)")!
        let request = NSMutableURLRequest(URL: url)
        //        request.addValue("", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.HTTPMethod = httpMethod
         request.timeoutInterval = 60
        return request
    }
    func postJSONRequest(apiFunction: String, httpMethod: String = "POST", isCookieTobeAdded: Bool) -> NSMutableURLRequest {
        let request = postRequest(apiFunction, httpMethod: httpMethod)
        //        request.addValue("", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("0.0", forHTTPHeaderField: "Protocol-Version")
        if(isCookieTobeAdded == true) {
            let user = LoginManager.getLoggedInUser()
            if((user) != nil) {
            let token = user?.token as! String
            if (token != "" ) {
                request.addValue(token, forHTTPHeaderField: "Authorization")}
        }
        }

        return request
    }
 
    func setCookies(response: NSURLResponse) {
        if let httpResponse = response as? NSHTTPURLResponse {
            if let headerFields = httpResponse.allHeaderFields as? [String: String] {
                let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(headerFields, forURL: response.URL!)
                NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookies(cookies, forURL: response.URL!, mainDocumentURL: nil)
                NSHTTPCookieStorage.sharedHTTPCookieStorage().cookieAcceptPolicy = NSHTTPCookieAcceptPolicy.Always
                print(cookies)
            }
        }
    }
    func URLSession(session: NSURLSession,
                    task: NSURLSessionTask,
                    didReceiveChallenge challenge: NSURLAuthenticationChallenge,
                                        completionHandler: (NSURLSessionAuthChallengeDisposition, NSURLCredential?)
        -> Void) {
        completionHandler(NSURLSessionAuthChallengeDisposition.UseCredential, NSURLCredential(forTrust: challenge.protectionSpace.serverTrust!))
    }

    func sendRequest(request: NSURLRequest, completion:(data: NSData?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) -> NSURLSessionDataTask {
        let session = NSURLSession(configuration: NSURLSessionConfiguration.defaultSessionConfiguration(), delegate: self, delegateQueue: nil)
        let task = session.dataTaskWithRequest(request, completionHandler: { (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            print(request)
            print(request.allHTTPHeaderFields)
            if request.HTTPBody != nil{
                let requestString = NSString(data:request.HTTPBody!, encoding: NSUTF8StringEncoding)
                print(requestString)
            }
            print("*********Request********: \(request):")
            print("*********Request Headers*********: \(request.allHTTPHeaderFields):")
            //            print("*********Request Json String*********: \(requestString):")
            if let response = response as? NSHTTPURLResponse {
                let json = JSON(data: data!)
                let datastring = NSString(data: data!, encoding: NSUTF8StringEncoding)
                print("*********Response*********: \(response):")
                print("*********Response Headers*********: \(response.allHeaderFields):")
                print("*********Response Json String*********: \(datastring):")
                if response.statusCode != 200 {
                    if let error = error {
                        completion(data: nil, successful:false, error: error, response: response)
                    } else {
                        let sessionManager = UIApplication.sharedApplication() as! SessionManager
                        var message = APIRequestsConstants.InternalServerError
                        var title = StringConstants.ErrorTitle
                        message = json[ExceptionConstants.ExpnCause].stringValue
                        title = json[ExceptionConstants.ExpnCode].stringValue
                        if response.statusCode == 555 {
                            title = APIRequestsConstants.Attention
                            message = APIRequestsConstants.InactiveUserMessage
                        }
                        if response.statusCode == 403 {
                            title = APIRequestsConstants.Attention
                            message = APIRequestsConstants.UnauthorizeAccessMessage
                        }
                        if response.statusCode == 404 {
                            title = NetworkStringConstants.NoServerConnectAlertTitle
                            message = NetworkStringConstants.NoServerConnectAlertMsg
                        }
                        if response.statusCode == 498 {
                            message = APIRequestsConstants.TokenExpired
                        }
                        if response.statusCode == 553 {
                            title = APIRequestsConstants.InvalidUsernameorPasswordTitle
                            message = APIRequestsConstants.InvalidUsernameorPasswordMsg
                        }
                        if response.statusCode == 554
                        {
                            ActivityIndicatorView.sharedActivityView.hideOverlayView()
                            sessionManager.timedOut()
                            return
                        }
                        if response.statusCode == 401 {
                            sessionManager.extendAccessToken()
                            title = APIRequestsConstants.Attention
                            message = APIRequestsConstants.AccessTokenExpired
                        }
                        if response.statusCode == 425 || response.statusCode == 427{
                            title = APIRequestsConstants.Attention
                        }
                        let newError = NSError(domain: ErrorDomain.APIError, code: json[ExceptionConstants.ExpnCode].intValue, userInfo: [NSLocalizedDescriptionKey: message, NSLocalizedFailureReasonErrorKey: title])
                        completion(data: nil, successful:false, error: newError, response: response)
                    }
                } else {
                        completion(data: data, successful:true, error: nil, response: response)
                }
            } else {
                if error?.code == -1005 || error?.code == -1004 || error?.code == -1001 {
                var newError = NSError(domain: ErrorDomain.APIError, code: (error?.code)!, userInfo: [NSLocalizedDescriptionKey: NetworkStringConstants.NetworkConnectionAlertMsg, NSLocalizedFailureReasonErrorKey: NetworkStringConstants.NetworkConnectionAlertTitle])
                    if error?.code == -1004 {
                     newError = NSError(domain: ErrorDomain.APIError, code: (error?.code)!, userInfo: [NSLocalizedDescriptionKey: NetworkStringConstants.NoServerConnectAlertMsg, NSLocalizedFailureReasonErrorKey: NetworkStringConstants.NoServerConnectAlertTitle])
                    }
                    else if error?.code == -1001{
                        newError = NSError(domain: ErrorDomain.APIError, code: (error?.code)!, userInfo: [NSLocalizedDescriptionKey: NetworkStringConstants.NetworkConnectionSlowIntMsg, NSLocalizedFailureReasonErrorKey: NetworkStringConstants.NetworkConnectionAttentionTitle])
                    }
                    completion(data: data, successful:false, error: newError, response: nil)
                } else {
                    completion(data: data, successful:true, error: error, response: nil)
                }
            }
        })
        task.resume()
        return task
    }
    
    // MARK: - Helper FunctionsVersion f
    func getDeviceDictionary() -> [String:String] {
        let dictionary = NSBundle.mainBundle().infoDictionary!
        let version = dictionary["CFBundleShortVersionString"] as? String
        let build = dictionary[bundleConstants.BundleVersion] as? String

        var deviceDictionary: [String:String] = [
            "platform": "1",
            "name": UIDevice.currentDevice().name,
            "model": UIDevice.currentDevice().model,
            "systemName": UIDevice.currentDevice().systemName,
            "osVersion": UIDevice.currentDevice().systemVersion,
            "deviceID": UIDevice.currentDevice().identifierForVendor!.UUIDString,
            "appVersion": version!,
            "appBuild": build!
        ]
        if let appVersionNum = NSBundle.mainBundle().infoDictionary?["CFBundleShortVersionString"] as? String {
            deviceDictionary["appVersion"] = appVersionNum
        }
        if let appBuildNum = NSBundle.mainBundle().infoDictionary?["CFBundleVersion"] as? String {
            deviceDictionary["appBuild"] = appBuildNum
        }
        return deviceDictionary
    }
    func handleError(json: JSON?) -> NSError {
        // Failure
        let logError = NSError(domain: ErrorDomain.APIError, code: APIError.enumFromString(json![ExceptionConstants.ExpnCode].stringValue).rawValue, userInfo: [NSLocalizedDescriptionKey: json![ExceptionConstants.ExpnCause].stringValue])
        return logError
    }
    
    func handleErrorForDict(json: [String: AnyObject]) -> NSError {
        // Failure
        let logError = NSError(domain: ErrorDomain.APIError, code: APIError.enumFromString(json[ExceptionConstants.ExpnCode]!.stringValue).rawValue, userInfo: [NSLocalizedDescriptionKey: json[ExceptionConstants.ExpnCause]!.stringValue])
        return logError
    }
    

}
