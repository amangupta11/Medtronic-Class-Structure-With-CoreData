//  APIRequest+Patient.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON
extension APIRequest {
    // MARK: - activateSTEMI
    func activateSTEMI(patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(activateStemi, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.json
            print("*********Request JSON********: \(patientJson):")

            request.HTTPBody = try patientJson.rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    PatientManager.managePatientData(json)
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }

    // MARK: - updatePatientGeneralDetails
    func updatePatientGeneralDetails(dictionary dictionary: NSDictionary, patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let params = dictionary.mutableCopy()
        params.setValue(CryptoUtility.publicKeyForJava(), forKey: PatientInfoKey.RsaPublicKey.rawValue)
        let request = postJSONRequest(updatePatientGeneralInfo, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.json
          var jsondict =   patientJson.dictionary
            jsondict![PatientInfoKey.RsaPublicKey.rawValue] = JSON(CryptoUtility.publicKeyForJava())
            print(patientJson)
            print("*********Request JSON********: \(JSON(jsondict!)):")
            request.HTTPBody = try JSON(jsondict!).rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
//                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(json)
//                    PatientManager.updateAllInfo(patientInfo)
                }
            }
        }
    }

    // MARK: - updatePatientECGInfo
    func updatePatientECGInfo(patientInfo patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(updatePatientInfarctArea, isCookieTobeAdded:true)
        var data: NSData?
        let patientJson = patientInfo.patientHistory!.infactAreaJson
        do {
        var  string = String(data: try patientJson.rawData(), encoding: NSUTF8StringEncoding)
        string = string?.stringByReplacingOccurrencesOfString("\\", withString: "")
            print("*********Request JSON********: \(string):")
        data = string?.dataUsingEncoding(NSUTF8StringEncoding)
        request.HTTPBody =  data
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                    PatientManager.updateAllInfo(patientInfo)
                }

            }
        }
    }
    // MARK: - getAWSBucketInfo
    func getAWSBucketInfo(patientInfo patientInfo: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = getJSONRequest(getCredential, isCookieTobeAdded:true)
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }

    // MARK: - updatePatientHistory
    func updatePatientHistory(patientInfo patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(updatePatientVitalSignInfo, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.patientHistory!.vitalSignsJson
            print("*********Request JSON********: \(patientJson):")
            request.HTTPBody = try patientJson.rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
//                    PatientManager.updateAllInfo(patientInfo)
                }
            }
        }
    }
    // MARK: - postCASEDetails
    func postCASEDetails(patientInfo patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(postCaseDetails, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.json
            print("*********Request JSON********: \(patientJson):")
            request.HTTPBody = try patientJson.rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                    PatientManager.updateAllInfo(patientInfo)
                }
                }
            }
        }
    // MARK: - editCaseGeneralInfo
    func editCaseGeneralInfo(dictionary dictionary: NSDictionary, patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let params = dictionary.mutableCopy()
        params.setValue(CryptoUtility.publicKeyForJava(), forKey: PatientInfoKey.RsaPublicKey.rawValue)
        let request = postJSONRequest(updatePatientGeneralInfo, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.json
            var jsondict =   patientJson.dictionary
            jsondict![PatientInfoKey.RsaPublicKey.rawValue] = JSON(CryptoUtility.publicKeyForJava())
            print(patientJson)
            print("*********Request JSON********: \(JSON(jsondict!)):")
            request.HTTPBody = try JSON(jsondict!).rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                print("HTTPBody error:\n \(error)")
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                    PatientManager.updateAllInfo(patientInfo)
                }
            }
        }
    }

    // MARK: - getCASEDetails
    func getCASEDetails(dictionary dictionary: NSDictionary, patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let params = dictionary.mutableCopy()
        params.setValue(CryptoUtility.publicKeyForJava(), forKey: PatientInfoKey.RsaPublicKey.rawValue)
        let request = postJSONRequest(getCaseDetails, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }

    func getUndiagnosedCaseDetails(dictionary dictionary: NSDictionary, patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let params = dictionary.mutableCopy()
        params.setValue(CryptoUtility.publicKeyForJava(), forKey: PatientInfoKey.RsaPublicKey.rawValue)
        let request = postJSONRequest(getUndiagnoseCaseDetails, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }

    // MARK: - getCASEList
    func getCASEList(dictionary dictionary: NSDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let params = dictionary.mutableCopy()
        params.setValue(CryptoUtility.publicKeyForJava(), forKey: PatientInfoKey.RsaPublicKey.rawValue)
        let request = postJSONRequest(getCaseList, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    if json.arrayValue.count == 0 {
                        completion(jsonString:json, successful:true, error:nil, response: response)
                        
                    } else {
                        var i = 0
                        for cases in json.arrayValue {
                            PatientManager.insertNewPatient(cases, completion: { (successful) in
                                if successful {
                                    i += 1
                                    if i == json.arrayValue.count {
                                        completion(jsonString:json, successful:true, error:nil, response: response)
                                    }
                                }
                            })
                        }
                    }
                }
            }
        }
    }
    // MARK: - checkPatientStatus
    func checkPatientStatus(dictionary dictionary: NSDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(checkStatus, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(dictionary,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }

        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:nil, response: response)

                }
            }
        }
    }
}
