//  APIRequest+Treatment.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON
extension APIRequest {
    // MARK: - activateSTEMI
    func getTreatmentInfo(patientInfo: PatientInfo, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(activateStemi, isCookieTobeAdded:true)
        do {
            let patientJson = patientInfo.json
            print("*********Request JSON********: \(patientJson):")

            request.HTTPBody = try patientJson.rawData()
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                }
            }
        }
    }
    // MARK: - performCathLabAccepted
    func performCathLabAccepted(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(cathLabAccepted, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - performDeviceCrossTime
    func performDeviceCrossTime(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(deviceCrossTime, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }

    // MARK: - performCathLabExit
    func performCathLabExit(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(cathLabExit, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - performTreatmentCompleted
    func performTreatmentCompleted(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(treatmentCompleted, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    //PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - performTreatmentCompleted
    func performCathLabReady(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(cathLabReady, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }

}
