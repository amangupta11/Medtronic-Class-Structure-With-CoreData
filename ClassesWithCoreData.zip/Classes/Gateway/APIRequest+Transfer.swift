//  APIRequest+Transfer.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON
extension APIRequest {
    // MARK: - getHospitalListing
    func getHospitalListing(patientInfo: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getHospitals, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfo):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfo,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - performSpokeTransfer
    func performSpokeTransfer(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(performSpokeInternalTransfer, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    //PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - getFMCDetails
    func getFMCDetails(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getFMCDoorOut, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - getFMCDetails
    func pushFMCDetails(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(pushFMCDoorOut, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    // PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }
    // MARK: - performSpokeTransfer
    func performHubNurseInternalTransfer(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(performHubInternalTransfer, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
                }
            }
        }
    }

    func udpateHubDooInTime(patientInfoDict: NSDictionary!, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(updateHubDooInTime, isCookieTobeAdded:true)
        do {
            print("*********Request JSON********: \(patientInfoDict):")
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(patientInfoDict,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let error = error {
                completion(jsonString:nil, successful:false, error:error, response: response)
            } else {
                let json = JSON(data:innerData!)
//                if json[ExceptionConstants.ExpnCode].isExists() == true {
//                    // Failure
//                    let logError = self.handleError(json)
//                    completion(jsonString:nil, successful:false, error:logError, response: response)
//                } else {
                    // Success
                      PatientManager.managePatientDataWithCaseID(json)
                    completion(jsonString:json, successful:true, error:error, response: response)
//                }
            }
        }

    }
}
