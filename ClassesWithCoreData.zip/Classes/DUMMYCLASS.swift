//
//  DUMMYCLASS.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 06/08/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

//        MEDAESWrapper.encryptTheText("1234",key:"12345678901234567890123456789012")
//        MEDAESWrapper.decryptTheText("PwVl7PYPDavdLSqeb3FQBA==",key: "12345678901234567890123456789012")
//        MEDAESWrapper.decryptTheText("/NQ0CPduJmT340u95NowDA==",key:"1234567890123456")
"${PODS_ROOT}/Fabric/run" 33c79e0a34df92d41df085cebd4cb4bc9ad91ad7 cd49d8d9fba87f575699c2775abec58a8e62a465d66f23b135c1f5c7a8d17fc7

//
//        self.identityProvider = BYOIProvider()
//
//        let credentialsProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, unauthRoleArn: nil, authRoleArn: nil, identityProvider: self.identityProvider!)
//        credentialsProvider.invalidateCachedTemporaryCredentials()
//        let configuration = AWSServiceConfiguration(region: .USEast1, credentialsProvider: credentialsProvider)
//        AWSServiceManager.defaultServiceManager().defaultServiceConfiguration = configuration
//


/*let jar = NSHTTPCookieStorage.sharedHTTPCookieStorage()
 let cookieHeaderField = ["Set-Cookie": "key=value"] // Or ["Set-Cookie": "key=value, key2=value2"] for multiple cookies
 let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(cookieHeaderField, forURL: request.URL!)
 jar.setCookies(cookies, forURL: request.URL, mainDocumentURL: request.URL)
 request  = NSMutableURLRequest(URL: request.URL!)*/


import UIKit
//        let  loginStoryboard: UIStoryboard = UIStoryboard(name:
//            StroryBoardNameConstants.SBNameLogin, bundle:nil)
//        let loginViewController = loginStoryboard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.loginSBID) as! MEDLoginViewController
//
//        let  splashStoryboard: UIStoryboard = UIStoryboard(name:
//            StroryBoardNameConstants.SBNameSplash, bundle:nil)
//        let splashViewController = splashStoryboard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.splashSBID) as! MEDSplashViewController
//        (UIApplication.sharedApplication().delegate?.window!!.rootViewController as! UINavigationController).viewControllers = [splashViewController, loginViewController]
//
### keyboard restriction
//        else if(textField.tag == 3)
//        {
//            if(string=="")
//            {
//                newString=""
//                return true
//                }
//            else{
//
//                newString = newString+string
//                let textValue = Double(newString)
//                let numbers:[Int] = [0,1,2,6,7,8,9]
//                if(newString.characters.count==1)
//                {
//                    for  index in 0 ..< numbers.count {
//
//                        if(textValue == Double(numbers[index]))
//                        {
//
//                            newString = ""
//                             return false
//                        }
//
//                    }
//                                }
//                 if(newString.characters.count>=2)
//                {
//
//                    print("Atmaja",textValue)
//                if(textValue!<30.0 || textValue!>50.0)
//                {
//                  return false
//                 }
//            }
//            }
//        }

if which swiftlint >/dev/null; then
swiftlint
else
echo "warning: SwiftLint not installed, download from https://github.com/realm/SwiftLint"
fi
class DUMMYCLASS: NSObject {

}
//        setToken(response) // NOT REQUIRED AS OF NOW
else {

    let dict = homelistArray[indexpath.row] as! NSDictionary
    let status = dict["Status"] as? String
    let patientCaseID = dict["CaseID"] as? String
    let patientName = dict["PatientName"] as? String
    cell.patientCaseID.text = patientCaseID! + ":" + patientName!
    cell.drName.text = dict["DrName"] as? String
    cell.status.text = status
    cell.fmcDate.text = dict["FMCDate"] as? String
    let (image, color) = getStatusImage(status!, cell:cell)
    cell.status.textColor = color
    cell.statusImage.image = image
    if(cell.treatmentCenter.text != nil) {
        cell.treatmentCenter.text = dict["TreatmentCenter"] as? String
        cell.treatmentCenterLineLabel.hidden = true
    } else {
        cell.treatmentCenterLineLabel.hidden = false}
    }
- (void)testCreateNew {
        Invoice *newInvoice = [NSEntityDescription insertNewObjectForEntityForName:@"Invoice" inManagedObjectContext:self.moc]
        newInvoice.dueDate = [NSDate date]
        NSString* title = [[NSString alloc] initWithFormat:@"Invoice %@", @112]
        newInvoice.title = title
        // Save the context.
        NSError *error = nil
        if (![self.moc save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            XCTFail(@"Error saving in \"%s\" : %@, %@", __PRETTY_FUNCTION__, error, [error userInfo])
        }
        XCTAssertFalse(self.moc.hasChanges, "All the changes should be saved")
}

class func setToken(response: NSHTTPURLResponse?) {
    let dict = response!.allHeaderFields as NSDictionary
    let cookie = dict["Set-Cookie"] as! String
    let array = cookie.characters.split {$0 == " "}.map(String.init)
    var JSESSIONID = array[0]
    JSESSIONID = JSESSIONID.stringByReplacingOccurrencesOfString(";", withString: ",")

    var USERClaim = array[3]
    USERClaim = USERClaim.stringByReplacingOccurrencesOfString(";", withString: "")
    let cookieValue = JSESSIONID.stringByAppendingString(USERClaim)

    let userID = MEDLoginManager.getUserDefault(StringConstants.UserID) as! String
    let user = UserInfo.getUserForUserId(userID)
    UserInfo.updateToken(user!, token: cookieValue)
}

    func  performLogin1() {
        let request = NSMutableURLRequest(URL: NSURL(string: BaseURL)!)
        request.HTTPMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let dictionary = [StringConstants.Username:"1234", StringConstants.Password:"1234"]
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(dictionary,
                                                                          options: NSJSONWritingOptions.PrettyPrinted) } catch {
        }
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
            guard error == nil && data != nil else {
                // check for fundamental networking error
                print("error=\(error)")
                return
            }
            if let httpStatus = response as? NSHTTPURLResponse where httpStatus.statusCode != 200 {
                // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
                let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
        }
        task.resume()
}
    func test () {
        MEDAPIRequest.sharedAPI.requestLogin(username:"", password:"") { (data, successful, error)
            in
            if successful {
                    } else {
                    }
        }
    }

}
    extension String {
        public var isEmail: Bool {
            let dataDetector = try? NSDataDetector(types: NSTextCheckingType.Link.rawValue)
            let firstMatch = dataDetector?.firstMatchInString(self, options: NSMatchingOptions.ReportCompletion, range: NSRange(location: 0, length: length))
            return (firstMatch?.range.location != NSNotFound && firstMatch?.URL?.scheme == "mailto")
        }
        public var length: Int {
            return self.characters.count
        }
}
/*
 let path = NSBundle.mainBundle().pathForResource("images", ofType: "jpg")
 let image = UIImage(contentsOfFile: path!)
 let imageData: NSData = UIImageJPEGRepresentation(image!, 0.5)!
 let encryptedData = AESWrapper.encryptTheData(imageData, key: "1234567890123456")
 do{
 let path1 = "/Users/chandrika.bhat/Desktop/encImg1.jpg"
 let result = try Bool(encryptedData.writeToFile(path1, options: NSDataWritingOptions.DataWritingAtomic))
 do{
 let imageData1 = try NSData(contentsOfFile: path1, options: .DataReadingMapped)
 let decryptedData = AESWrapper.decryptTheData(imageData1, key: "1234567890123456")
 let path2 = "/Users/chandrika.bhat/Desktop/decImg.jpg"
 do{
 let result = try Bool(decryptedData.writeToFile(path2, options: NSDataWritingOptions.DataWritingAtomic))
 }
 catch let error as NSError {
 print(error.localizedDescription)
 }
 }
 catch let error as NSError {
 print(error.localizedDescription)
 }
 }
 catch let error as NSError {
 print(error.localizedDescription)
 }
 */

//sendRequest(request) { (data, error) in
//    if let error
//    {
//        completion(data:data,successful:true, error:nil)
//    } else {
//        let json = JSON(data: data!)
//        if json["error"].isExists() {
//            let loginError = NSError(domain: ErrorDomain.MEDAPIError, code: MEDAPIError.enumFromString(json["error"].stringValue).rawValue, userInfo: [NSLocalizedDescriptionKey: json["error_description"].stringValue])
//            completion(data:nil,successful:false, error:loginError)
//        } else {
//            completion(data:data,successful:true, error:nil)
//        }
//}


//SMS

//    func sendText(phoneNumber:String) {
//        if (MFMessageComposeViewController.canSendText()) {
//            let controller = MFMessageComposeViewController()
//            controller.body = "Message Body"
//            controller.recipients = phoneNumber
//            controller.messageComposeDelegate = self
//            self.presentViewController(controller, animated: true, completion: nil)
//        }
//    }
//
//    func messageComposeViewController(controller: MFMessageComposeViewController!, didFinishWithResult result: MessageComposeResult) {
//        //... handle sms screen actions
//        self.dismissViewControllerAnimated(true, completion: nil)
//    }
//    class func sendEmail(email:String){
//
//
//    }

//MAIL
//    func sendEmailButtonTapped(sender: AnyObject) {
//        let mailComposeViewController = configuredMailComposeViewController()
//        if MFMailComposeViewController.canSendMail() {
//            self.presentViewController(mailComposeViewController, animated: true, completion: nil)
//        } else {
//            self.showSendMailErrorAlert()
//        }
//    }
//
//    func configuredMailComposeViewController() -> MFMailComposeViewController {
//        let mailComposerVC = MFMailComposeViewController()
//        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
//
//        mailComposerVC.setToRecipients(["nurdin@gmail.com"])
//        mailComposerVC.setSubject("Sending you an in-app e-mail...")
//        mailComposerVC.setMessageBody("Sending e-mail in-app is not so bad!", isHTML: false)
//
//        return mailComposerVC
//    }
//
//    func showSendMailErrorAlert() {
//        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
//        sendMailErrorAlert.show()
//    }
//
//    // MARK: MFMailComposeViewControllerDelegate
//
//    func mailComposeController(controller: MFMailComposeViewController!, didFinishWithResult result: MFMailComposeResult, error: NSError!) {
//        controller.dismissViewControllerAnimated(true, completion: nil)
//
//    }


// MARK: - Fetch Results- Core Data Part
class func encryptTheText(string: String, key: String) -> String {
    let data: NSData = string.dataUsingEncoding(NSUTF8StringEncoding)!
    let ciphertext = RNCryptor.encryptData(data, password: key)
    let encryptedString = String(data: ciphertext, encoding: NSUTF8StringEncoding)
    return encryptedString!
}


class func decryptTheText(string: String, key: String) -> String {
    let data: NSData = string.dataUsingEncoding(NSUTF8StringEncoding)!
    let dectryptedString: String
    do {
        let originalData = try RNCryptor.decryptData(data, password: key)
        dectryptedString = String(data: originalData, encoding: NSUTF8StringEncoding)!
        return dectryptedString
    } catch {
        print(error)
    }
    return ""
}

do {
    try fetchedResultsController.performFetch()
} catch {
    print("An error occurred")
}
//    func doneBtnAction()
//    {
////        self.stopTreatmentTV.reloadData()
////        if self.commentsTV.isFirstResponder(){
////            self.commentsTV.resignFirstResponder()
////        }
//        if self.getTreatmentName(self.getSelectedDict()) == "Others" {
//            if self.commentsTV.text.utf16.count == 0{
//                isTextViewMarkedRed = true
//                self.handleTextViewUI(self.commentsTV)
//            }
//            else{
//                isTextViewMarkedRed = false
//                self.selectedDataDict .setValue(self.getCommentText(), forKey: StringConstants.Comment)
//
//                let indexPath = NSIndexPath(forRow: commonArr.count - 1, inSection: 0)
//                let commentCell = self.stopTreatmentTV.cellForRowAtIndexPath(indexPath) as! OtherCustomCell
//                self.normalizeOtherCommentsTextView(commentCell.commentsTV)
//
//
//                self.showAlertWithTwoButtons("Confirmation", alertMsg: "Are your sure you want to Stop Treatment for this case?")
//
//            }
//        }
//        else{
//            let indexPath = NSIndexPath(forRow: commonArr.count - 1, inSection: 0)
//            let commentCell = self.stopTreatmentTV.cellForRowAtIndexPath(indexPath) as! OtherCustomCell
//            commentCell.commentsTV.text = ""
//
//            isTextViewMarkedRed = false
//            self.showAlertWithTwoButtons("Confirmation", alertMsg: "Are your sure you want to Stop Treatment for this case?")
//
//        }
//        //self.stopTreatmentTV.reloadData()
//    }

//        do{
//            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(dictionary,
//                                                                          options: NSJSONWritingOptions.PrettyPrinted)
//        }
//        catch{
//            print("HTTPBody error:\n \(error)")
//        }


//
//                    if let items = json["cases"].array {
//                        for item in items {
//                            if let title = item["title"].string {
//                                println(title)
//                            }
//                        }
//
//                    }
//                    for cases in json["cases"].arrayValue {
//                        MEDPatientManager.managePatientData(json)
//                    }


var fetchedResultsController: NSFetchedResultsController = {
}()
func fetchResults() -> NSArray {
    let predicate = NSPredicate(format: "caseStatus %@", "New")
    homelistArray = MEDDataOperation.sharedDataOperation.fetchObjectForEntity("PatientInfo", predicate: predicate) as! NSArray
    return homelistArray

}
//    override  func imagePickerController(
//        picker: UIImagePickerController,
//        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
//        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
//        capturedECGImage = info[UIImagePickerControllerOriginalImage] as? UIImage
//        self.performSegueWithIdentifier(SegueIdentifierConstants.loginToPreviewSegueIdentifier, sender: self)
//    }
var fetchedResultsController: NSFetchedResultsController = {
    // Initialize Fetch Request
    let fetchRequest = NSFetchRequest(entityName: "PatientInfo")

    // Add Sort Descriptors
    let sortDescriptor = NSSortDescriptor(key: "firstName", ascending: true)
    fetchRequest.sortDescriptors = [sortDescriptor]

    // Initialize Fetched Results Controller
    let fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: MEDDataOperation.sharedDataOperation.mainThreadContext, sectionNameKeyPath: nil, cacheName: nil)

    // Configure Fetched Results Controller
    fetchedResultsController.delegate = self

    return fetchedResultsController
}()

// MARK: Fetched Results Controller Delegate Methods
func controllerWillChangeContent(controller: NSFetchedResultsController) {
    //        tableView.beginUpdates()
}

func controllerDidChangeContent(controller: NSFetchedResultsController) {
    //        tableView.endUpdates()
}


func controller(controller: NSFetchedResultsController, didChangeObject anObject: AnyObject, atIndexPath indexPath: NSIndexPath?, forChangeType type: NSFetchedResultsChangeType, newIndexPath: NSIndexPath?) {
    switch (type) {
    case .Insert: break
        //            if let indexPath = newIndexPath {
        //                tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        //            }

    case .Delete:
        //            if let indexPath = indexPath {
        //                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        //            }
        break
    case .Update:
        //            if let indexPath = indexPath {
        //                let cell = tableView.cellForRowAtIndexPath(indexPath) as! ToDoCell
        //                configureCell(cell, atIndexPath: indexPath)
        //            }
        break
    case .Move:
        //            if let indexPath = indexPath {
        //                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        //            }
        //            if let newIndexPath = newIndexPath {
        //                tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Fade)
        //            }
        break
    }
}



//        let alertController = UIAlertController(title: "Destructive", message: "Simple alertView demo with Destructive and Ok.", preferredStyle: UIAlertControllerStyle.Alert) //Replace UIAlertControllerStyle.Alert by UIAlertControllerStyle.alert
//        let DestructiveAction = UIAlertAction(title: AlertViewButtonTitle.NoButtonTitle, style: UIAlertActionStyle.Default) {
//            (result : UIAlertAction) -> Void in
//            self.OKButtonAction(alertController)
//
//        }
//        let okAction = UIAlertAction(title: AlertViewButtonTitle.YesButtonTitle, style: UIAlertActionStyle.Default) {
//            (result : UIAlertAction) -> Void in
//            self.cancelButtonAction(alertController)
//        }
//        alertController.addAction(DestructiveAction)
//        alertController.addAction(okAction)
//        self.presentViewController(alertController, animated: true, completion: nil)

Get Case Details
url : http://localhost:8080/macs-communication/services/rest/patient/fetch/getCaseDetails
Request: {
    "caseID":"asdas", "patientID":"sdfsd"
}
Response: {
    "caseID": null,
    "patientID": null,
    "caseStatus": null,
    "firstName": null,
    "lastName": null,
    "gender": null,
    "age": null,
    "countryCode": null,
    "mobileNumber": null,
    "paymentID": null,
    "paymentType": {
        "id": null,
        "value": null
    },
    "fmcDoorInTime": {
        TimeLineKey.FirstEdit.rawValue: null,
        TimeLineKey.SecondEdit.rawValue: null,
        TimeLineKey.ThirdEdit.rawValue: null,
        TimeLineKey.Actual.rawValue: null,
        TimeLineKey.EditCount.rawValue: null
    }
}

// Initialize Fetch Request
let fetchRequest = NSFetchRequest(entityName: "PaientInfo")
// Add Sort Descriptors
let sortDescriptor = NSSortDescriptor(key: PatientInfoKey.CaseID.rawValue, ascending: true)
fetchRequest.sortDescriptors = [sortDescriptor]
// Initialize Fetched Results Controller
var fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: MEDCoreData.sharedCoreData.mainThreadContext, sectionNameKeyPath: nil, cacheName: nil)

Get Case List
url: http://localhost:8080/macs-communication/services/rest/patient/fetch/getCaseList
Request: {
    "userID":"dfgdfhdfh", "roleID": 1, "hospitalID":"sfsdf", "hospitalTypeID":2
}
Response:
[ {
"caseID": null,
"caseStatus": null,
"firstName": null,
"lastName": null,
"gender": null,
"fmcDoorInTime": null,
"fmcCenter": {
"hospitalID": null,
"hospitalTypeID": null,
"abbreviation": null,
"hospitalName": null
},
"treatmentCenter": {
"hospitalID": null,
"hospitalTypeID": null,
"abbreviation": null,
"hospitalName": null
}
}, {
"caseID": null,
"caseStatus": null,
"firstName": null,
"lastName": null,
"gender": null,
"fmcDoorInTime": null,
"fmcCenter": {
"hospitalID": null,
"hospitalTypeID": null,
"abbreviation": null,
"hospitalName": null
},
"treatmentCenter": {
"hospitalID": null,
"hospitalTypeID": null,
"abbreviation": null,
"hospitalName": null
}
}]


Create Case
url : http://localhost:8080/macs-communication/services/rest/patient/push/createCase
Request: {
    "caseID":"sfsdfdsg", "caseStatus":0, "firstName":"gsdgfsd", "lastName":"sfsdfd", "gender":0, "fmcDoorInTime":"dfgdfg", "activateStemiTime":"dfhffhfgh", "firstEcgCaptureTime":"fgjfgj"
}
Response: {
    "caseID": null
    "tempCaseID": null
    "patientID": null
}

Update Case Details
url : http://localhost:8080/macs-communication/services/rest/patient/push/updateCaseDetails
Request: {
    "caseID":"sfsdfdsg", "patientID":"ewrwetert", "caseStatus":0, "firstName":"gsdgfsd", "lastName":"sfsdfd", "gender":0, "age":25, "countryCode":"+91", "mobileNumber":"4732856342", "paymentID":"sfsdgf2432sff", "paymentType": {
        "id":1, "value":"wrwerwetg"
    }, "fmcDoorInTime":"dfgdfg", "activateStemiTime":"dfhffhfgh", "firstEcgCaptureTime":"fgjfgj"
}
Response:
200 OK





//ThumbNail code


@IBOutlet weak var img: UIImageView!
@IBOutlet weak var thumbnailImage: UIImageView!
var modifiedImage: UIImage!
var originalImage: UIImage!
override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
}
@IBAction func buttonTapped(sender: AnyObject) {

    if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {

        let imag = UIImagePickerController()
        imag.delegate = self
        imag.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        //imag.mediaTypes = [kUTTypeImage];
        imag.allowsEditing = false
        self.presentViewController(imag, animated: true, completion: nil)
    }
}

func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!) {
    let selectedImage: UIImage = image
    //var tempImage:UIImage = editingInfo[UIImagePickerControllerOriginalImage] as UIImage
    img.image=selectedImage
    originalImage=img.image
    self.dismissViewControllerAnimated(true, completion: nil)
}

func ResizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
    let size = image.size

    let widthRatio  = targetSize.width  / image.size.width
    let heightRatio = targetSize.height / image.size.height

    // Figure out what our orientation is, and use that to form the rectangle
    var newSize: CGSize
    if(widthRatio > heightRatio) {
        newSize = CGSizeMake(size.width * heightRatio, size.height * heightRatio)
    } else {
        newSize = CGSizeMake(size.width * widthRatio, size.height * widthRatio)
    }

    // This is the rect that we've calculated out and this is what is actually used below
    let rect = CGRectMake(0, 0, newSize.width, newSize.height)

    // Actually do the resizing to the rect using the ImageContext stuff
    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    image.drawInRect(rect)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    return newImage
}


@IBAction func thumbnailTapped(sender: AnyObject) {
    if(!(originalImage==nil)) {
        self.modifiedImage=self.ResizeImage(img.image!, targetSize: CGSize(width: 15.0, height: 15.0))
        thumbnailImage.image=self.modifiedImage

    } else {

        print("Image is not captured")

    }
}
override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}


}








